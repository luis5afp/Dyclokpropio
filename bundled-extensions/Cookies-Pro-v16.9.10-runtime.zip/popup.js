'use strict';

const APP_VERSION = chrome.runtime.getManifest().version;
const EXPORT_FORMAT = 'cookies-pro-backup';
const EXPORT_SCHEMA_VERSION = 11;
const PRIVATE_EXPORT_FORMAT = 'cookies-pro-private-encrypted';
const PRIVATE_EXPORT_SCHEMA_VERSION = 1;
const PRIVATE_PBKDF2_ITERATIONS = 600000;
const MIN_EXPORT_PASSPHRASE_LENGTH = 12;
const MAX_EXPORT_PASSPHRASE_LENGTH = 256;
const MAX_IMPORT_PASSPHRASE_LENGTH = 1024;
const MAX_IMPORT_BYTES = 80 * 1024 * 1024;
const MAX_CREDENTIAL_IMPORT_BYTES = 25 * 1024 * 1024;
const MAX_MANUAL_CREDENTIALS = 20000;
const COOKIE_SET_RETRIES = 2;
const PERSISTENT_COOKIE_LIFETIME_DAYS = 399;
const PERSISTENT_COOKIE_LIFETIME_SECONDS = PERSISTENT_COOKIE_LIFETIME_DAYS * 24 * 60 * 60;
const ACCOUNT_REVEAL_MS = 30000;
const SECRET_DISPLAY_MS = 3000;
const DEFAULT_TOTP_PERIOD = 30;
const MAX_VALIDATION_FACTORS = 2;
const TOTP_ALGORITHMS = new Set(['SHA-1', 'SHA-256', 'SHA-512']);
const DEFAULT_PAGE = 'https://www.google.com/';
const VALID_STATUSES = new Set(['valid', 'invalid', 'unknown']);
const TOTP_LOCAL_STATUSES = new Set(['valid_format', 'invalid_format', 'metadata_match', 'metadata_warning', 'pending']);
const TOTP_SERVER_STATUSES = new Set(['unknown', 'pending', 'submitted', 'valid', 'invalid', 'credentials_invalid']);
const SENSITIVE_DOMAINS = [
  'google.com',
  'accounts.google.com',
  'gmail.com',
  'youtube.com',
  'microsoft.com',
  'outlook.com',
  'apple.com',
  'paypal.com'
];

let profiles = [];
let expandedProfiles = new Set();
let expandedPages = new Set();
let activeSearchQuery = '';
let revealedAccounts = new Set();
let accountRevealTimers = new Map();
let generatedTotpCodes = new Map();
let totpCountdownTimers = new Map();
let temporaryFactorValues = new Map();
let temporaryFactorTimers = new Map();
let recoveryCodeIndexes = new Map();
let activeModal = null;

const $ = (id) => document.getElementById(id);


function startBackgroundAction(type, payload = {}) {
  setStatus('La tarea seguirá ejecutándose aunque cierres la extensión…');
  chrome.runtime.sendMessage({ channel: 'cookies-pro-background', type, ...payload }, (response) => {
    const error = chrome.runtime.lastError && chrome.runtime.lastError.message;
    if (error || !response || !response.accepted) setStatus(`No se pudo iniciar la tarea: ${error || 'sin respuesta'}`, true);
  });
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.profiles && Array.isArray(changes.profiles.newValue)) {
    profiles = changes.profiles.newValue.map((profile, index) => normalizeProfile(profile, index));
    render();
  }
  if (changes.backgroundJob && changes.backgroundJob.newValue) {
    const job = changes.backgroundJob.newValue;
    setStatus(job.message || '', job.status === 'error');
  }
});

function setStatus(message, isError = false) {
  const node = $('status');
  node.textContent = message || '';
  node.style.color = isError ? 'var(--danger)' : '';
  node.title = message || '';
}

function getRuntimeError() {
  return chrome.runtime.lastError ? chrome.runtime.lastError.message : '';
}

function storageGet(defaults) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(defaults, (result) => {
      const error = getRuntimeError();
      if (error) reject(new Error(error));
      else resolve(result);
    });
  });
}

function storageSet(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      const error = getRuntimeError();
      if (error) reject(new Error(error));
      else resolve();
    });
  });
}

function storageClear() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.clear(() => {
      const error = getRuntimeError();
      if (error) reject(new Error(error));
      else resolve();
    });
  });
}

async function storageSetTrustedAccess() {
  if (!chrome.storage.local || typeof chrome.storage.local.setAccessLevel !== 'function') return;
  await chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
}

function cookiesGetAll(details = {}) {
  return new Promise((resolve, reject) => {
    chrome.cookies.getAll(details, (items) => {
      const error = getRuntimeError();
      if (error) reject(new Error(error));
      else resolve(items || []);
    });
  });
}

function cookiesGet(details) {
  return new Promise((resolve, reject) => {
    chrome.cookies.get(details, (item) => {
      const error = getRuntimeError();
      if (error) reject(new Error(error));
      else resolve(item || null);
    });
  });
}

function cookieStoresGetAll() {
  return new Promise((resolve, reject) => {
    if (!chrome.cookies || typeof chrome.cookies.getAllCookieStores !== 'function') {
      resolve([]);
      return;
    }
    chrome.cookies.getAllCookieStores((stores) => {
      const error = getRuntimeError();
      if (error) reject(new Error(error));
      else resolve(stores || []);
    });
  });
}

function cookiesSet(details) {
  return new Promise((resolve, reject) => {
    chrome.cookies.set(details, (cookie) => {
      const error = getRuntimeError();
      if (error || !cookie) reject(new Error(error || 'No se pudo guardar la cookie'));
      else resolve(cookie);
    });
  });
}

function cookiesRemove(details) {
  return new Promise((resolve) => {
    chrome.cookies.remove(details, (result) => resolve(Boolean(result)));
  });
}

function tabsQuery(query) {
  return new Promise((resolve, reject) => {
    chrome.tabs.query(query, (tabs) => {
      const error = getRuntimeError();
      if (error) reject(new Error(error));
      else resolve(tabs || []);
    });
  });
}

function tabsCreate(url) {
  return new Promise((resolve, reject) => {
    chrome.tabs.create({ url }, (tab) => {
      const error = getRuntimeError();
      if (error) reject(new Error(error));
      else resolve(tab);
    });
  });
}

function tabsReload(tabId) {
  return new Promise((resolve, reject) => {
    chrome.tabs.reload(tabId, { bypassCache: false }, () => {
      const error = getRuntimeError();
      if (error) reject(new Error(error));
      else resolve();
    });
  });
}

function scriptingExecuteScript(tabId, func, args = []) {
  return new Promise((resolve, reject) => {
    if (!chrome.scripting || typeof chrome.scripting.executeScript !== 'function') {
      reject(new Error('La API de inserción segura no está disponible'));
      return;
    }
    chrome.scripting.executeScript({
      target: { tabId },
      func,
      args
    }, (results) => {
      const error = getRuntimeError();
      if (error) reject(new Error(error));
      else resolve(results || []);
    });
  });
}

function safeUrl(value) {
  try {
    const url = new URL(value);
    if (!['http:', 'https:'].includes(url.protocol)) return null;
    if (url.username || url.password) return null;
    return url;
  } catch (_) {
    return null;
  }
}

function cookieDomain(cookie) {
  return String(cookie && cookie.domain ? cookie.domain : '').replace(/^\./, '').toLowerCase();
}

function isSensitive(domain) {
  const clean = String(domain || '').replace(/^\./, '').toLowerCase();
  return SENSITIVE_DOMAINS.some((item) => clean === item || clean.endsWith(`.${item}`));
}

function normalizePath(path) {
  const value = typeof path === 'string' && path ? path : '/';
  return value.startsWith('/') ? value : `/${value}`;
}

function cookieUrl(cookie) {
  const host = cookieDomain(cookie);
  if (!host) return null;
  return `${cookie && cookie.secure ? 'https' : 'http'}://${host}${normalizePath(cookie.path)}`;
}

function makeId(prefix = 'id') {
  if (globalThis.crypto && typeof globalThis.crypto.randomUUID === 'function') {
    return `${prefix}-${globalThis.crypto.randomUUID()}`;
  }
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

function titleFromDomain(domain) {
  const clean = String(domain || '').replace(/^www\./, '').toLowerCase();
  const known = [
    [/^(mail\.)?google\.com$|^gmail\.com$/, 'Gmail'],
    [/^(www\.)?youtube\.com$/, 'YouTube'],
    [/^(www\.)?facebook\.com$/, 'Facebook'],
    [/^accounts\.google\.com$/, 'Google Accounts'],
    [/^(www\.)?outlook\.com$|^login\.live\.com$/, 'Outlook'],
    [/^(www\.)?microsoft\.com$/, 'Microsoft'],
    [/^(www\.)?paypal\.com$/, 'PayPal']
  ];
  for (const [pattern, title] of known) {
    if (pattern.test(clean)) return title;
  }
  const first = clean.split('.')[0] || 'Página';
  return first.charAt(0).toUpperCase() + first.slice(1);
}

function optionalText(value, maxLength = 500) {
  if (value == null) return '';
  return String(value).trim().slice(0, maxLength);
}

function optionalSecretText(value, maxLength = 1000) {
  if (value == null) return '';
  return String(value).slice(0, maxLength);
}

function booleanValue(value, fallback = false) {
  if (value == null) return fallback;
  if (typeof value === 'string') {
    const normalized = value.trim().toLowerCase();
    if (['false', 'no', '0', 'off', 'disabled', 'desactivada', 'desactivado'].includes(normalized)) return false;
    if (['true', 'sí', 'si', '1', 'on', 'enabled', 'activada', 'activado'].includes(normalized)) return true;
  }
  return Boolean(value);
}


function normalizeTotpAlgorithm(value) {
  const normalized = String(value || 'SHA-1').trim().toUpperCase().replace(/^SHA(\d+)$/, 'SHA-$1');
  return TOTP_ALGORITHMS.has(normalized) ? normalized : 'SHA-1';
}

function normalizeTotpSecret(value) {
  const secret = String(value || '').replace(/[\s-]+/g, '').replace(/=+$/g, '').toUpperCase();
  if (!secret || /^\d{6,8}$/.test(secret)) return '';
  if (secret.length < 8 || !/^[A-Z2-7]+$/.test(secret)) return '';
  return secret.slice(0, 512);
}

function parseOtpAuthUri(value) {
  const text = String(value || '').trim();
  if (!/^otpauth:\/\/totp\//i.test(text)) return null;
  try {
    const parsed = new URL(text);
    const secret = normalizeTotpSecret(parsed.searchParams.get('secret'));
    if (!secret) return null;
    const digitsRaw = Number(parsed.searchParams.get('digits'));
    const periodRaw = Number(parsed.searchParams.get('period'));
    return {
      secret,
      period: Number.isInteger(periodRaw) && periodRaw >= 15 && periodRaw <= 120 ? periodRaw : DEFAULT_TOTP_PERIOD,
      digits: digitsRaw === 8 ? 8 : 6,
      algorithm: normalizeTotpAlgorithm(parsed.searchParams.get('algorithm')),
      issuer: optionalText(parsed.searchParams.get('issuer'), 160),
      label: optionalText(decodeURIComponent(parsed.pathname.replace(/^\//, '')), 240)
    };
  } catch (_) {
    return null;
  }
}

function normalizeTotpConfig(value) {
  if (!value) return null;
  if (typeof value === 'string') {
    const fromUri = parseOtpAuthUri(value);
    if (fromUri) return fromUri;
    const secret = normalizeTotpSecret(value);
    return secret ? {
      secret,
      period: DEFAULT_TOTP_PERIOD,
      digits: 6,
      algorithm: 'SHA-1',
      issuer: '',
      label: ''
    } : null;
  }
  if (typeof value !== 'object' || Array.isArray(value)) return null;
  const fromUri = parseOtpAuthUri(value.uri || value.otpauth || value.url || '');
  if (fromUri) return {
    ...fromUri,
    issuer: optionalText(value.issuer ?? fromUri.issuer, 160),
    label: optionalText(value.label ?? value.account ?? fromUri.label, 240)
  };
  const secret = normalizeTotpSecret(value.secret ?? value.seed ?? value.key ?? value.base32);
  if (!secret) return null;
  const periodRaw = Number(value.period ?? value.interval ?? value.step);
  const digitsRaw = Number(value.digits);
  return {
    secret,
    period: Number.isInteger(periodRaw) && periodRaw >= 15 && periodRaw <= 120 ? periodRaw : DEFAULT_TOTP_PERIOD,
    digits: digitsRaw === 8 ? 8 : 6,
    algorithm: normalizeTotpAlgorithm(value.algorithm ?? value.hash),
    issuer: optionalText(value.issuer, 160),
    label: optionalText(value.label ?? value.account, 240)
  };
}

function normalizeValidationMethodType(value) {
  const normalized = String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '');
  const aliases = new Map([
    ['sms', 'sms'], ['telefono', 'sms'], ['telefonico', 'sms'], ['textmessage', 'sms'],
    ['correo', 'email'], ['email', 'email'], ['mail', 'email'],
    ['totp', 'totp'], ['otp', 'totp'], ['aplicacionautenticadora', 'totp'], ['authenticatorapp', 'totp'],
    ['push', 'push'], ['notificacionpush', 'push'], ['notificacion', 'push'],
    ['passkey', 'passkey'], ['webauthn', 'passkey'], ['claveacceso', 'passkey'],
    ['llavefisica', 'security_key'], ['llavedeseguridad', 'security_key'], ['securitykey', 'security_key'], ['fido2', 'security_key'], ['u2f', 'security_key'],
    ['codigosderecuperacion', 'recovery_codes'], ['codigosrecuperacion', 'recovery_codes'], ['recoverycodes', 'recovery_codes'], ['backupcodes', 'recovery_codes'],
    ['preguntadeseguridad', 'security_question'], ['securityquestion', 'security_question'],
    ['validacionadicional', 'password_only'], ['usuarioycontrasena', 'password_only'], ['passwordonly', 'password_only'], ['sinvalidacionadicional', 'password_only'],
    ['desconocida', 'unknown'], ['desconocido', 'unknown'], ['unknown', 'unknown']
  ]);
  return aliases.get(normalized) || (normalized ? 'unknown' : '');
}

function validationMethodLabel(type, fallback = '') {
  const labels = {
    sms: 'SMS',
    email: 'Correo',
    totp: 'Aplicación autenticadora',
    push: 'Notificación push',
    passkey: 'Passkey',
    security_key: 'Llave física FIDO2/U2F',
    recovery_codes: 'Códigos de recuperación',
    security_question: 'Pregunta de seguridad',
    password_only: 'Usuario y contraseña',
    unknown: 'Desconocida'
  };
  return labels[type] || optionalText(fallback, 100) || 'Desconocida';
}

function normalizeStringList(value, maxItems = 50, maxLength = 500) {
  const input = Array.isArray(value)
    ? value
    : String(value || '').split(/\r?\n|[;,|]+/);
  return input.map((item) => optionalSecretText(item, maxLength).trim()).filter(Boolean).slice(0, maxItems);
}

function normalizeTotpVerification(value) {
  const raw = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const localStatus = TOTP_LOCAL_STATUSES.has(raw.localStatus) ? raw.localStatus : 'pending';
  const serverStatus = TOTP_SERVER_STATUSES.has(raw.serverStatus) ? raw.serverStatus : 'unknown';
  return {
    localStatus,
    serverStatus,
    reason: optionalText(raw.reason, 500),
    matchedBy: optionalText(raw.matchedBy, 120),
    checkedAt: raw.checkedAt || null,
    hostname: optionalText(raw.hostname, 255),
    credentialsSubmitted: Boolean(raw.credentialsSubmitted),
    otpSubmitted: Boolean(raw.otpSubmitted)
  };
}

function normalizeValidationFactor(value, index = 0) {
  if (!value) return null;
  const raw = typeof value === 'string' ? { type: value, label: value } : value;
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const originalType = raw.type ?? raw.kind ?? raw.method ?? raw.name ?? raw.label ?? '';
  const type = normalizeValidationMethodType(originalType) || 'unknown';
  const enabled = raw.enabled == null ? true : booleanValue(raw.enabled);
  const factor = {
    id: String(raw.id || makeId(`factor-${index}`)),
    type,
    label: optionalText(raw.label ?? raw.name, 120) || validationMethodLabel(type, originalType),
    enabled,
    status: optionalText(raw.status ?? raw.state, 160) || (enabled ? 'Configurada' : 'Desactivada'),
    detail: optionalText(raw.detail ?? raw.description ?? raw.notes, 500),
    provider: optionalText(raw.provider ?? raw.service, 160),
    destination: optionalText(raw.destination ?? raw.target, 320),
    phone: optionalText(raw.phone ?? raw.telephone ?? raw.telefono, 80),
    email: optionalText(raw.email ?? raw.correo, 254),
    app: optionalText(raw.app ?? raw.application ?? raw.aplicacion, 160),
    device: optionalText(raw.device ?? raw.dispositivo, 200),
    rpId: optionalText(raw.rpId ?? raw.rpid ?? raw.relyingPartyId, 255),
    credentialId: optionalSecretText(raw.credentialId ?? raw.credentialID ?? raw.idCredencial, 2000),
    transports: normalizeStringList(raw.transports ?? raw.transportes, 12, 80),
    vendor: optionalText(raw.vendor ?? raw.fabricante, 120),
    model: optionalText(raw.model ?? raw.modelo, 120),
    serial: optionalText(raw.serial ?? raw.serie, 160),
    backupEligible: booleanValue(raw.backupEligible ?? raw.elegibleRespaldo, false),
    backedUp: booleanValue(raw.backedUp ?? raw.respaldada, false),
    privateKeyExportable: false,
    recoveryCodes: normalizeStringList(raw.recoveryCodes ?? raw.codes ?? raw.codigosRecuperacion, 200, 500),
    question: optionalText(raw.question ?? raw.pregunta, 500),
    answer: optionalSecretText(raw.answer ?? raw.respuesta, 1000),
    manualSecret: ['sms', 'email', 'push', 'unknown'].includes(type)
      ? optionalSecretText(raw.manualSecret ?? raw.secretValue ?? raw.secretoManual ?? raw.secret ?? raw.seed ?? raw.semilla, 2000)
      : '',
    // Cookies Pro no impone vencimiento local a los métodos guardados. La validez real
    // sigue dependiendo del servicio: TOTP genera códigos nuevos, recuperación puede ser de un solo uso.
    retention: 'persistent',
    expiresAt: null,
    validityControlledBy: 'service',
    totp: null,
    totpVerification: normalizeTotpVerification(raw.totpVerification ?? raw.seedVerification)
  };

  if (type === 'totp') {
    factor.totp = normalizeTotpConfig(raw.totp ?? raw.otpAuth ?? raw.otpauth ?? raw.secret ?? raw.seed ?? raw.key ?? raw.manualSecret);
  } else if (raw.totp) {
    factor.totp = normalizeTotpConfig(raw.totp);
  }
  if (type === 'sms' && !factor.destination) factor.destination = factor.phone;
  if (type === 'email' && !factor.destination) factor.destination = factor.email;
  if (type === 'unknown' && !factor.manualSecret) {
    factor.manualSecret = optionalSecretText(raw.secret ?? raw.seed ?? raw.semilla, 2000);
  }
  return factor;
}

function normalizedIdentityHints(account) {
  const credentials = account && account.credentials ? account.credentials : {};
  return [credentials.email, credentials.username, account && account.name]
    .map((value) => optionalText(value, 320).toLowerCase())
    .filter((value) => value && value.length >= 3);
}

function auditTotpFactorAssociation(page, account, factor) {
  const normalized = normalizeValidationFactor(factor);
  if (!normalized || normalized.type !== 'totp') return normalized;
  const current = normalizeTotpVerification(normalized.totpVerification);
  const checkedAt = new Date().toISOString();
  if (!normalized.totp) {
    return {
      ...normalized,
      status: 'Semilla con formato inválido',
      totpVerification: {
        ...current,
        localStatus: 'invalid_format',
        serverStatus: 'pending',
        credentialsSubmitted: false,
        otpSubmitted: false,
        reason: 'La semilla no contiene Base32 TOTP válida o sus parámetros no son compatibles.',
        matchedBy: '',
        checkedAt,
        hostname: optionalText(page && page.domain, 255)
      }
    };
  }

  const domain = optionalText(page && page.domain, 255).toLowerCase();
  const domainRoot = domain.replace(/^www\./, '').split('.')[0];
  const issuer = optionalText(normalized.totp.issuer, 160).toLowerCase();
  const label = optionalText(normalized.totp.label, 240).toLowerCase();
  const metadata = `${issuer} ${label}`.trim();
  const identities = normalizedIdentityHints(account);
  const identityMatch = identities.find((identity) => metadata && metadata.includes(identity));
  const domainMatch = Boolean(metadata && (
    (domain && metadata.includes(domain))
    || (domainRoot && domainRoot.length >= 3 && metadata.includes(domainRoot))
  ));

  let localStatus = 'valid_format';
  let reason = 'La semilla tiene formato TOTP válido; falta comprobar que el servicio acepte un código.';
  let matchedBy = '';
  if (identityMatch) {
    localStatus = 'metadata_match';
    matchedBy = 'identidad de la cuenta';
    reason = 'La etiqueta TOTP coincide con el correo, usuario o nombre de la cuenta; falta la confirmación del servicio.';
  } else if (domainMatch) {
    localStatus = 'metadata_match';
    matchedBy = 'dominio o emisor';
    reason = 'El emisor o la etiqueta TOTP coincide con la página; falta la confirmación del servicio.';
  } else if (metadata) {
    localStatus = 'metadata_warning';
    reason = 'La semilla es válida, pero su emisor o etiqueta no coincide claramente con esta página o cuenta.';
  }

  return {
    ...normalized,
    status: current.serverStatus === 'valid' ? 'Verificada en el sitio' : 'Pendiente de comprobación manual',
    totpVerification: {
      ...current,
      localStatus,
      serverStatus: 'pending',
      credentialsSubmitted: false,
      otpSubmitted: false,
      reason,
      matchedBy,
      checkedAt,
      hostname: domain
    }
  };
}

function auditImportedTotpSeeds(pages) {
  const summary = {
    total: 0,
    formatValid: 0,
    invalidFormat: 0,
    metadataMatches: 0,
    metadataWarnings: 0,
    pendingOnline: 0
  };
  for (const page of pages || []) {
    for (const account of page.accounts || []) {
      const validation = normalizeValidationInfo(account);
      let hasTotp = false;
      validation.factors = validation.factors.map((factor) => {
        if (factor.type !== 'totp') return factor;
        hasTotp = true;
        summary.total += 1;
        const audited = auditTotpFactorAssociation(page, account, factor);
        const verification = normalizeTotpVerification(audited && audited.totpVerification);
        if (verification.localStatus === 'invalid_format') summary.invalidFormat += 1;
        else summary.formatValid += 1;
        if (verification.localStatus === 'metadata_match') summary.metadataMatches += 1;
        if (verification.localStatus === 'metadata_warning') summary.metadataWarnings += 1;
        if (verification.serverStatus !== 'valid' && verification.serverStatus !== 'invalid') summary.pendingOnline += 1;
        return audited;
      });
      if (!hasTotp) continue;
      const firstTotp = validation.factors.find((factor) => factor.type === 'totp' && factor.totp);
      validation.totp = firstTotp ? { ...firstTotp.totp } : null;
      if (validation.factors.some((factor) => factor.type === 'totp'
        && normalizeTotpVerification(factor.totpVerification).localStatus === 'invalid_format')) {
        validation.status = 'Semilla TOTP con formato inválido';
      } else if (validation.factors.some((factor) => factor.type === 'totp'
        && normalizeTotpVerification(factor.totpVerification).localStatus === 'metadata_warning')) {
        validation.status = 'TOTP importado; asociación por confirmar';
      } else {
        validation.status = 'TOTP importado; pendiente de validación en el sitio';
      }
      account.validation = validation;
    }
  }
  return summary;
}

function validationFactorForExport(factor, includeSecrets) {
  const normalized = normalizeValidationFactor(factor);
  if (!normalized) return null;
  const exported = {
    ...normalized,
    totp: normalized.totp ? {
      ...normalized.totp,
      secret: includeSecrets ? normalized.totp.secret : ''
    } : null,
    recoveryCodes: includeSecrets ? normalized.recoveryCodes.slice() : [],
    answer: includeSecrets ? normalized.answer : '',
    manualSecret: includeSecrets ? normalized.manualSecret : '',
    sensitiveDataIncluded: Boolean(includeSecrets && (
      (normalized.totp && normalized.totp.secret)
      || normalized.recoveryCodes.length
      || normalized.answer
      || normalized.manualSecret
    ))
  };
  return exported;
}

function validationForExport(validation, includeSecrets) {
  const normalized = normalizeValidationInfo({ validation });
  const factors = normalized.factors
    .map((factor) => validationFactorForExport(factor, includeSecrets))
    .filter(Boolean)
    .slice(0, MAX_VALIDATION_FACTORS);
  const firstTotp = factors.find((factor) => factor.type === 'totp' && factor.totp && factor.totp.secret);
  return {
    ...normalized,
    factors,
    methods: factors.map((factor) => factor.label),
    type: factors.map((factor) => factor.label).join(' + ') || normalized.type,
    totp: firstTotp ? { ...firstTotp.totp } : null,
    sensitiveFactorsIncluded: factors.some((factor) => factor.sensitiveDataIncluded)
  };
}

function normalizeValidationInfo(account) {
  const source = account && typeof account === 'object' ? account : {};
  let raw = source.validation ?? source.verification ?? source.authValidation
    ?? source.mfa ?? source.twoFactor ?? source.validacion ?? null;
  if (typeof raw === 'string') raw = { type: raw };
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) raw = {};

  const rawMethods = raw.methods ?? raw.method ?? source.validationMethods
    ?? source.metodosValidacion ?? source.metodoValidacion ?? [];
  const methodValues = (Array.isArray(rawMethods) ? rawMethods : [rawMethods])
    .map((item) => optionalText(item, 100))
    .filter(Boolean);
  const legacyType = optionalText(
    raw.type ?? raw.kind ?? source.validationType ?? source.tipoValidacion ?? methodValues[0],
    200
  );
  const rawFactors = raw.factors ?? raw.validationFactors ?? raw.factores ?? source.validationFactors ?? source.factoresValidacion ?? [];
  const factors = (Array.isArray(rawFactors) ? rawFactors : [rawFactors])
    .map((factor, index) => normalizeValidationFactor(factor, index))
    .filter(Boolean)
    .slice(0, MAX_VALIDATION_FACTORS);

  const legacyTotp = normalizeTotpConfig(
    raw.totp ?? raw.totpConfig ?? raw.otpAuth ?? source.totp ?? source.totpConfig ?? source.otpAuth
  );
  if (legacyTotp && !factors.some((factor) => factor.type === 'totp')) {
    factors.push(normalizeValidationFactor({
      type: 'totp',
      label: 'Aplicación autenticadora',
      totp: legacyTotp,
      status: raw.status || 'Configurada'
    }, factors.length));
  }

  if (!factors.length) {
    const legacyCandidates = methodValues.length
      ? methodValues
      : (legacyType ? legacyType.split(/[,;+|]+/).map((item) => item.trim()).filter(Boolean) : []);
    for (const method of legacyCandidates.slice(0, MAX_VALIDATION_FACTORS)) {
      const factor = normalizeValidationFactor({ type: method, label: method }, factors.length);
      if (factor) factors.push(factor);
    }
  }

  const enabledRaw = raw.enabled ?? raw.required ?? raw.hasValidation
    ?? source.hasValidation ?? source.validationEnabled ?? source.tieneValidacion;
  const enabled = enabledRaw == null
    ? Boolean(factors.length || legacyType || methodValues.length)
    : booleanValue(enabledRaw);
  const effectiveFactors = factors.slice(0, MAX_VALIDATION_FACTORS).map((factor) => ({
    ...factor,
    enabled: enabled ? factor.enabled : false
  }));
  const effectiveEnabled = enabled || effectiveFactors.some((factor) => factor.enabled);
  const detail = optionalText(
    raw.detail ?? raw.description ?? source.validationDetail ?? source.detalleValidacion,
    500
  );
  const status = optionalText(
    raw.status ?? source.validationStatus ?? source.estadoValidacion
      ?? (effectiveEnabled ? 'Configurada' : 'No registrada'),
    160
  );
  const methods = effectiveFactors.map((factor) => factor.label).filter(Boolean);
  const firstTotp = effectiveFactors.find((factor) => factor.type === 'totp' && factor.totp);

  return {
    enabled: effectiveEnabled,
    type: methods.join(' + ') || legacyType || (effectiveEnabled ? 'No especificada' : ''),
    methods,
    factors: effectiveFactors,
    factorCount: effectiveFactors.length,
    status,
    detail,
    lastVerified: raw.lastVerified ?? source.validationLastVerified ?? null,
    retention: 'persistent',
    expiresAt: null,
    validityControlledBy: 'service',
    totp: firstTotp ? { ...firstTotp.totp } : null,
    provided: Boolean(raw.provided ?? source.validationProvided ?? false)
  };
}

function normalizeAccount(account, index = 0, fallbackStatus = 'unknown') {
  const source = account && typeof account === 'object' ? account : {};
  const credentials = source.credentials && typeof source.credentials === 'object'
    ? source.credentials
    : {};
  const email = optionalText(
    credentials.email ?? source.email ?? source.correo ?? source.mail,
    254
  );
  const username = optionalText(
    credentials.username ?? source.username ?? source.user ?? source.usuario,
    160
  );
  const password = optionalSecretText(
    credentials.password ?? source.password ?? source.contrasena ?? source['contraseña'],
    1000
  );
  const validation = normalizeValidationInfo(source);
  const suppliedName = source.name || source.label || source.accountName || email || username;
  const status = VALID_STATUSES.has(source.status) ? source.status : fallbackStatus;
  const hasRegisteredData = Boolean(
    email || username || password || validation.provided || validation.enabled || validation.factors.length
  );
  return {
    id: String(source.id || makeId(`account-${index}`)),
    name: String(suppliedName || `Cuenta ${index + 1}`),
    displayName: optionalText(source.displayName ?? source.accountDisplayName, 240),
    status,
    cookieCount: Number.isFinite(Number(source.cookieCount)) ? Number(source.cookieCount) : 0,
    storeId: source.storeId == null ? '' : String(source.storeId),
    partitionKey: source.partitionKey && typeof source.partitionKey === 'object'
      ? { ...source.partitionKey }
      : null,
    protected: Boolean(source.protected),
    lastChecked: source.lastChecked || null,
    reason: String(source.reason || ''),
    sourceUrl: optionalText(source.sourceUrl ?? source.url ?? source.origin, 2048),
    dataSource: optionalText(source.dataSource ?? source.dataOrigin ?? source.originType, 80)
      || (hasRegisteredData ? 'profile' : 'cookies'),
    credentials: { email, username, password },
    validation,
    sessionCookies: Array.isArray(source.sessionCookies)
      ? source.sessionCookies.filter(Boolean).map((cookie) => ({ ...cookie }))
      : [],
    sessionCapturedAt: source.sessionCapturedAt || null
  };
}

function accountHasValidationData(account) {
  const validation = normalizeValidationInfo(account);
  return Boolean(
    validation.provided
    || validation.enabled
    || validation.factors.length
    || validation.detail
    || (validation.status && validation.status !== 'No registrada')
  );
}

function accountHasMeaningfulData(account) {
  return Boolean(accountHasCredentialData(account) || accountHasValidationData(account));
}

function accountDataScore(account) {
  const normalized = normalizeAccount(account);
  const credentials = normalized.credentials || {};
  const validation = normalizeValidationInfo(normalized);
  let score = 0;
  if (credentials.email) score += 8;
  if (credentials.username) score += 6;
  if (credentials.password) score += 12;
  if (validation.provided) score += 3;
  if (validation.enabled) score += 4;
  score += validation.factors.length * 5;
  if (validation.factors.some((factor) => factor.type === 'totp' && factor.totp && factor.totp.secret)) score += 12;
  if (validation.factors.some((factor) => factor.recoveryCodes && factor.recoveryCodes.length)) score += 8;
  if (validation.factors.some((factor) => factor.answer || factor.manualSecret)) score += 6;
  if (normalized.sourceUrl) score += 2;
  if (normalized.dataSource && normalized.dataSource !== 'cookies') score += 2;
  return score;
}

function accountSourceLabel(account) {
  const source = String(account && account.dataSource || '').toLowerCase();
  if (source === 'manual-import') return 'Archivo de cuentas importado manualmente';
  if (source === 'encrypted-backup') return 'Respaldo privado cifrado';
  if (source === 'profile') return 'Perfil local de Cookies Pro';
  if (source === 'cookies') return 'Sesión detectada únicamente por cookies';
  return source || 'Perfil local';
}

function normalizePage(page, index = 0) {
  const source = page && typeof page === 'object' ? page : {};
  const sourceUrl = source.url || source.page || source.href || (source.domain ? `https://${source.domain}/` : '');
  const parsed = safeUrl(sourceUrl);
  const domain = String(source.domain || (parsed ? parsed.hostname : '')).replace(/^\./, '').toLowerCase();
  const url = parsed ? parsed.href : (domain ? `https://${domain}/` : DEFAULT_PAGE);
  const status = VALID_STATUSES.has(source.status) ? source.status : 'unknown';
  const accounts = Array.isArray(source.accounts)
    ? source.accounts.map((account, accountIndex) => normalizeAccount(account, accountIndex, status))
    : [];
  return {
    id: String(source.id || makeId(`page-${index}`)),
    name: String(source.name || source.title || titleFromDomain(domain)),
    url,
    domain: domain || new URL(DEFAULT_PAGE).hostname,
    status,
    protected: Boolean(source.protected),
    cookieCount: Number.isFinite(Number(source.cookieCount)) ? Number(source.cookieCount) : 0,
    accounts,
    lastChecked: source.lastChecked || null,
    reason: String(source.reason || ''),
    validation: source.validation && typeof source.validation === 'object'
      ? { ...source.validation }
      : null
  };
}

function cookieBelongsToPage(cookie, page) {
  const domain = cookieDomain(cookie);
  const pageDomain = String(page && page.domain ? page.domain : '').replace(/^\./, '').toLowerCase();
  return Boolean(domain && pageDomain && (pageDomain === domain || pageDomain.endsWith(`.${domain}`)));
}

function cookieAccountMetadata(cookie) {
  const extensions = cookie && cookie.extensions && typeof cookie.extensions === 'object'
    ? cookie.extensions
    : {};
  const id = extensions.accountId || extensions.accountKey || extensions.profileAccountId || '';
  const name = extensions.accountName || extensions.accountLabel || extensions.profileAccountName || '';
  return {
    id: id == null ? '' : String(id),
    name: name == null ? '' : String(name)
  };
}

function accountSessionKey(cookie) {
  const storeId = cookie && cookie.storeId != null ? String(cookie.storeId) : 'default';
  const partition = cookie && cookie.partitionKey && typeof cookie.partitionKey === 'object'
    ? stableStringify(cookie.partitionKey)
    : '';
  const metadata = cookieAccountMetadata(cookie);
  return `${storeId}|${partition}|${metadata.id || metadata.name}`;
}

function deriveAccountsForPage(page, cookies, blocked) {
  const groups = new Map();
  const add = (cookie, protectedCookie) => {
    if (!cookieBelongsToPage(cookie, page)) return;
    const key = accountSessionKey(cookie);
    const current = groups.get(key) || {
      accepted: 0,
      blocked: 0,
      storeId: cookie && cookie.storeId != null ? String(cookie.storeId) : '',
      partitionKey: cookie && cookie.partitionKey && typeof cookie.partitionKey === 'object'
        ? { ...cookie.partitionKey }
        : null,
      explicitName: cookieAccountMetadata(cookie).name
    };
    if (!current.explicitName) current.explicitName = cookieAccountMetadata(cookie).name;
    if (protectedCookie) current.blocked += 1;
    else current.accepted += 1;
    groups.set(key, current);
  };

  cookies.forEach((cookie) => add(cookie, false));
  blocked.forEach((cookie) => add(cookie, true));

  const entries = Array.from(groups.values());
  return entries.map((group, index) => {
    const protectedOnly = group.accepted === 0 && group.blocked > 0;
    const fallbackName = group.explicitName || (entries.length === 1 ? 'Cuenta principal' : `Cuenta ${index + 1}`);
    return normalizeAccount({
      id: makeId('account'),
      name: fallbackName,
      status: protectedOnly ? 'invalid' : page.status,
      cookieCount: group.accepted + group.blocked,
      storeId: group.storeId,
      partitionKey: group.partitionKey,
      protected: protectedOnly,
      reason: protectedOnly ? 'Cookies protegidas' : page.reason,
      lastChecked: page.lastChecked,
      dataSource: 'cookies'
    }, index, page.status);
  });
}

function derivePages(cookies, blocked, legacyPage) {
  const grouped = new Map();

  const add = (cookie, protectedCookie) => {
    const domain = cookieDomain(cookie);
    if (!domain) return;
    const current = grouped.get(domain) || { accepted: 0, blocked: 0 };
    if (protectedCookie) current.blocked += 1;
    else current.accepted += 1;
    grouped.set(domain, current);
  };

  cookies.forEach((cookie) => add(cookie, false));
  blocked.forEach((cookie) => add(cookie, true));

  const pages = [];
  for (const [domain, counts] of grouped.entries()) {
    const protectedOnly = counts.accepted === 0 && counts.blocked > 0;
    pages.push(normalizePage({
      id: makeId('page'),
      name: titleFromDomain(domain),
      url: `https://${domain}/`,
      domain,
      status: protectedOnly ? 'invalid' : 'valid',
      protected: protectedOnly,
      cookieCount: counts.accepted + counts.blocked,
      reason: protectedOnly ? 'Cookies protegidas' : ''
    }));
  }

  const legacyUrl = safeUrl(legacyPage);
  if (legacyUrl && !pages.some((page) => page.domain === legacyUrl.hostname)) {
    pages.unshift(normalizePage({
      id: makeId('page'),
      name: titleFromDomain(legacyUrl.hostname),
      url: legacyUrl.href,
      domain: legacyUrl.hostname,
      status: cookies.length ? 'valid' : 'unknown',
      cookieCount: cookies.length
    }));
  }

  return pages;
}

function normalizeProfile(profile, index = 0) {
  const source = profile && typeof profile === 'object' ? profile : {};
  const cookies = Array.isArray(source.cookies) ? source.cookies.filter(Boolean) : [];
  const blocked = Array.isArray(source.blocked) ? source.blocked.filter(Boolean) : [];
  const suppliedPages = Array.isArray(source.pages) ? source.pages : [];
  const pages = suppliedPages.length
    ? suppliedPages.map((page, pageIndex) => normalizePage(page, pageIndex))
    : derivePages(cookies, blocked, source.page);

  for (const page of pages) {
    const relatedCookies = cookies.filter((cookie) => cookieBelongsToPage(cookie, page));
    const relatedBlocked = blocked.filter((cookie) => cookieBelongsToPage(cookie, page));
    if (!page.cookieCount) page.cookieCount = relatedCookies.length + relatedBlocked.length;
    if (!page.accounts.length) page.accounts = deriveAccountsForPage(page, relatedCookies, relatedBlocked);
  }

  return {
    id: String(source.id || makeId(`profile-${index}`)),
    name: String(source.name || `Perfil ${String(index + 1).padStart(2, '0')}`),
    page: String(source.page || (pages[0] ? pages[0].url : DEFAULT_PAGE)),
    cookies,
    blocked,
    pages,
    history: Array.isArray(source.history) ? source.history : [],
    createdAt: source.createdAt || new Date().toISOString(),
    updatedAt: source.updatedAt || new Date().toISOString()
  };
}

async function saveProfiles() {
  await storageSet({ profiles, storageSchemaVersion: 1, appVersion: APP_VERSION });
}

function profileMetrics(profile) {
  const valid = profile.pages.filter((page) => page.status === 'valid').length;
  const invalid = profile.pages.filter((page) => page.status === 'invalid').length;
  return {
    valid,
    invalid,
    total: profile.pages.length
  };
}

function createTextElement(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  node.textContent = text;
  return node;
}

function statusLabel(page) {
  if (page.status === 'valid') return { icon: '🟢', text: 'Acceso correcto' };
  if (page.status === 'invalid') return { icon: '🔴', text: page.reason || 'Acceso fallido' };
  return { icon: '⚪', text: 'Sin comprobar' };
}

function normalizeSearchValue(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
}

function accountMatchesSearch(account, query) {
  const credentials = account.credentials || {};
  const validation = account.validation || {};
  const text = [
    account.name, account.displayName, account.originalName, account.sourceUrl,
    credentials.email, credentials.username,
    validation.type, ...(Array.isArray(validation.methods) ? validation.methods : [])
  ].join(' ');
  return normalizeSearchValue(text).includes(query);
}

function filterProfileForSearch(profile, query) {
  if (!query) return profile;
  if (normalizeSearchValue(profile.name).includes(query)) return profile;

  const pages = [];
  for (const page of profile.pages || []) {
    const pageText = normalizeSearchValue(`${page.name || ''} ${page.domain || ''} ${page.url || ''}`);
    const pageMatches = pageText.includes(query);
    const matchingAccounts = (page.accounts || []).filter((account) => accountMatchesSearch(account, query));
    if (pageMatches || matchingAccounts.length) {
      pages.push(pageMatches ? page : { ...page, accounts: matchingAccounts });
    }
  }
  return pages.length ? { ...profile, pages } : null;
}

function render() {
  const container = $('profiles');
  const empty = $('emptyState');
  const query = normalizeSearchValue($('search').value);
  activeSearchQuery = query;
  container.replaceChildren();

  const filtered = profiles
    .map((profile) => filterProfileForSearch(profile, query))
    .filter(Boolean);

  $('profileTotal').textContent = `${filtered.length}/${profiles.length}`;
  container.hidden = filtered.length === 0;
  empty.hidden = filtered.length !== 0;
  empty.textContent = profiles.length ? 'No hay resultados.' : 'No hay perfiles guardados.';

  for (const profile of filtered) {
    const expanded = Boolean(query) || expandedProfiles.has(profile.id);
    const metrics = profileMetrics(profile);
    const article = document.createElement('article');
    article.className = 'profile';
    article.dataset.profileId = profile.id;

    const summary = document.createElement('div');
    summary.className = 'profile-summary';

    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'delete-profile';
    remove.textContent = '❌';
    remove.title = `Eliminar ${profile.name}`;
    remove.setAttribute('aria-label', `Eliminar perfil ${profile.name}`);
    remove.addEventListener('click', () => deleteProfile(profile.id));

    const toggle = document.createElement('button');
    toggle.type = 'button';
    toggle.className = 'profile-toggle';
    toggle.setAttribute('aria-expanded', String(expanded));
    toggle.setAttribute('aria-label', `${expanded ? 'Cerrar' : 'Abrir'} perfil ${profile.name}`);
    toggle.addEventListener('click', () => toggleProfile(profile.id));

    const name = createTextElement('span', 'profile-name', `👤 ${profile.name}`);
    name.title = profile.name;
    const valid = createTextElement('span', 'metric', `🟢${metrics.valid}`);
    valid.title = 'Páginas válidas';
    const invalid = createTextElement('span', 'metric', `🔴${metrics.invalid}`);
    invalid.title = 'Páginas no válidas';
    const cookies = createTextElement('span', 'metric', `🍪${metrics.total}`);
    cookies.title = 'Cantidad total de páginas';
    const arrow = createTextElement('span', 'arrow', expanded ? '▲' : '▼');

    toggle.append(name, valid, invalid, cookies, arrow);
    summary.append(remove, toggle);
    article.append(summary);

    if (expanded) article.append(createProfileDetails(profile));
    container.append(article);
  }
}

function accountStatusLabel(account) {
  const totpVerification = normalizeValidationInfo(account).factors
    .filter((factor) => factor.type === 'totp')
    .map((factor) => normalizeTotpVerification(factor.totpVerification))
    .find((verification) => verification.serverStatus !== 'unknown' && verification.serverStatus !== 'pending');
  if (totpVerification) {
    if (totpVerification.serverStatus === 'valid') return { icon: '🟢', text: 'Acceso comprobado con la semilla TOTP de esta cuenta' };
    if (totpVerification.serverStatus === 'invalid') return { icon: '🔴', text: 'El servicio rechazó el TOTP generado por esta semilla' };
    if (totpVerification.serverStatus === 'credentials_invalid') return { icon: '🔴', text: 'Credenciales rechazadas; la semilla TOTP no fue comprobada' };
    if (totpVerification.serverStatus === 'submitted') return { icon: '🟡', text: 'Código TOTP enviado; resultado pendiente' };
  }
  if (account.status === 'valid') return { icon: '🟢', text: 'Estado heredado de una página con acceso correcto' };
  if (account.status === 'invalid') return { icon: '🔴', text: account.reason || 'Estado heredado de una página con acceso fallido' };
  return { icon: '⚪', text: 'Cuenta sin comprobación independiente' };
}

function accountViewKey(pageId, accountId) {
  return `${pageId}::${accountId}`;
}

function accountDetailValue(value, fallback = 'No disponible') {
  const text = optionalText(value, 1000);
  return text || fallback;
}

function validationDisplay(account) {
  const validation = normalizeValidationInfo(account);
  if (!validation.enabled) return 'No registrada';
  const methods = validation.factors.length
    ? validation.factors.map((factor) => factor.label).join(' + ')
    : (validation.type || 'No especificada');
  const status = validation.status ? ` · ${validation.status}` : '';
  return `${methods}${status}`;
}

function createReadOnlyField(label, value, className = '') {
  const row = document.createElement('div');
  row.className = `account-detail-row ${className}`.trim();
  const key = createTextElement('span', 'account-detail-label', label);
  const content = createTextElement('span', 'account-detail-value', value);
  content.title = value;
  row.append(key, content);
  return row;
}


function base32ToBytes(secret) {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  const normalized = normalizeTotpSecret(secret);
  if (!normalized) throw new Error('La semilla TOTP no es Base32 válida');
  let bits = 0;
  let value = 0;
  const output = [];
  for (const character of normalized) {
    const index = alphabet.indexOf(character);
    if (index < 0) throw new Error('La semilla TOTP contiene caracteres no válidos');
    value = (value << 5) | index;
    bits += 5;
    if (bits >= 8) {
      output.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  if (!output.length) throw new Error('La semilla TOTP está vacía');
  return new Uint8Array(output);
}

function counterToBytes(counter) {
  let value = BigInt(counter);
  const output = new Uint8Array(8);
  for (let index = 7; index >= 0; index -= 1) {
    output[index] = Number(value & 255n);
    value >>= 8n;
  }
  return output;
}

function formatTotpCode(code) {
  const text = String(code || '');
  if (text.length === 6) return `${text.slice(0, 3)} ${text.slice(3)}`;
  if (text.length === 8) return `${text.slice(0, 4)} ${text.slice(4)}`;
  return text;
}

async function generateTotpCode(config, now = Date.now()) {
  const normalized = normalizeTotpConfig(config);
  if (!normalized) throw new Error('Esta cuenta no contiene una semilla TOTP válida');
  const counter = Math.floor(now / 1000 / normalized.period);
  const key = await crypto.subtle.importKey(
    'raw',
    base32ToBytes(normalized.secret),
    { name: 'HMAC', hash: normalized.algorithm },
    false,
    ['sign']
  );
  const signature = new Uint8Array(await crypto.subtle.sign('HMAC', key, counterToBytes(counter)));
  const offset = signature[signature.length - 1] & 15;
  const binary = (((signature[offset] & 127) << 24)
    | ((signature[offset + 1] & 255) << 16)
    | ((signature[offset + 2] & 255) << 8)
    | (signature[offset + 3] & 255)) >>> 0;
  const code = String(binary % (10 ** normalized.digits)).padStart(normalized.digits, '0');
  return {
    code,
    period: normalized.period,
    expiresAt: (counter + 1) * normalized.period * 1000
  };
}

function factorViewKey(pageId, accountId, factorId, role = 'factor') {
  return `${pageId}::${accountId}::${factorId || 'factor'}::${role}`;
}

function clearTotpCode(key) {
  generatedTotpCodes.delete(key);
  const timer = totpCountdownTimers.get(key);
  if (timer) clearInterval(timer);
  totpCountdownTimers.delete(key);
}

function updateTotpNodes(key) {
  const state = generatedTotpCodes.get(key);
  const now = Date.now();
  const visibleRemaining = state ? Math.max(0, Math.ceil((state.visibleUntil - now) / 1000)) : 0;
  const windowRemaining = state ? Math.max(0, Math.ceil((state.actualExpiresAt - now) / 1000)) : 0;
  for (const node of document.querySelectorAll('[data-totp-key]')) {
    if (node.dataset.totpKey !== key) continue;
    if (node.dataset.totpRole === 'code') node.textContent = state ? formatTotpCode(state.code) : 'Código oculto';
    if (node.dataset.totpRole === 'countdown') {
      node.textContent = state ? `ocultar ${visibleRemaining}s · ventana ${windowRemaining}s` : '';
    }
  }
  if (state && (visibleRemaining <= 0 || windowRemaining <= 0)) {
    clearTotpCode(key);
    updateTotpNodes(key);
  }
}

function startTotpCountdown(key) {
  const oldTimer = totpCountdownTimers.get(key);
  if (oldTimer) clearInterval(oldTimer);
  const timer = setInterval(() => updateTotpNodes(key), 200);
  totpCountdownTimers.set(key, timer);
}

async function generateAccountTotp(pageId, account, factor, button) {
  const normalizedFactor = normalizeValidationFactor(factor);
  const config = normalizedFactor && normalizeTotpConfig(normalizedFactor.totp);
  const key = factorViewKey(pageId, account.id, normalizedFactor && normalizedFactor.id, 'totp');
  try {
    button.disabled = true;
    const result = await generateTotpCode(config);
    clearTotpCode(key);
    generatedTotpCodes.set(key, {
      ...result,
      actualExpiresAt: result.expiresAt,
      visibleUntil: Math.min(result.expiresAt, Date.now() + SECRET_DISPLAY_MS)
    });
    startTotpCountdown(key);
    updateTotpNodes(key);
    setStatus(`Código TOTP generado localmente para ${account.name}; se ocultará en 3 segundos.`);
  } catch (error) {
    setStatus(`No se pudo generar el código: ${error.message}`, true);
  } finally {
    button.disabled = false;
  }
}

function findPageAccountFactor(pageId, accountId, factorId) {
  for (const profile of profiles) {
    const page = (profile.pages || []).find((item) => item.id === pageId);
    if (!page) continue;
    const account = (page.accounts || []).find((item) => item.id === accountId);
    if (!account) return { profile, page, account: null, factor: null };
    const validation = normalizeValidationInfo(account);
    const factor = validation.factors.find((item) => item.id === factorId) || null;
    return { profile, page, account, factor };
  }
  return { profile: null, page: null, account: null, factor: null };
}

function autofillValidationFields(payload) {
  const visible = (element) => {
    if (!element || element.disabled || element.readOnly) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.display !== 'none' && style.visibility !== 'hidden'
      && Number(style.opacity || 1) > 0 && rect.width > 2 && rect.height > 2;
  };
  const descriptorText = (element) => {
    const labelText = element.labels ? Array.from(element.labels).map((label) => label.textContent || '').join(' ') : '';
    return [element.type, element.name, element.id, element.placeholder, element.autocomplete,
      element.getAttribute('aria-label'), labelText]
      .filter(Boolean).join(' ').toLowerCase();
  };
  const setValue = (element, value) => {
    if (!element || !value) return false;
    const prototype = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value');
    if (descriptor && descriptor.set) descriptor.set.call(element, value);
    else element.value = value;
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  };
  const inputs = Array.from(document.querySelectorAll('input, textarea')).filter(visible);
  const otpPattern = /(one[- ]?time|otp|totp|2fa|mfa|authenticator|verification|verify|security.?code|codigo|código|token|pin)/i;
  const identityPattern = /(email|e-mail|correo|username|user.?name|usuario|login|account|cuenta)/i;
  const newPasswordPattern = /(new.?password|confirm|repeat|nueva|confirmar|repetir)/i;
  const otpInputs = inputs.filter((input) => {
    const text = descriptorText(input);
    const max = Number(input.maxLength);
    return input.autocomplete === 'one-time-code' || otpPattern.test(text)
      || ((input.inputMode === 'numeric' || input.type === 'tel' || input.type === 'number') && (max === 6 || max === 8));
  });
  const splitOtpInputs = inputs.filter((input) => {
    const max = Number(input.maxLength);
    const text = descriptorText(input);
    return max === 1 && (input.inputMode === 'numeric' || input.type === 'tel' || input.type === 'number' || otpPattern.test(text));
  });
  const usableSplitOtp = otpInputs.length === 0 && (splitOtpInputs.length === 6 || splitOtpInputs.length === 8)
    ? splitOtpInputs : [];
  const passwordInputs = inputs.filter((input) => input.type === 'password'
    && input.autocomplete !== 'new-password' && !newPasswordPattern.test(descriptorText(input)));
  const identityInputs = inputs.filter((input) => {
    if (input.type === 'password' || otpInputs.includes(input) || usableSplitOtp.includes(input)) return false;
    const text = descriptorText(input);
    return input.type === 'email' || input.autocomplete === 'username' || identityPattern.test(text);
  });

  let identityFilled = 0;
  let passwordFilled = 0;
  let otpFilled = 0;
  const identityValue = payload.email || payload.username || '';
  if (identityValue && identityInputs[0] && setValue(identityInputs[0], identityValue)) identityFilled = 1;
  if (payload.password && passwordInputs[0] && setValue(passwordInputs[0], payload.password)) passwordFilled = 1;
  if (payload.otp && otpInputs[0] && setValue(otpInputs[0], payload.otp)) otpFilled = 1;
  if (!otpFilled && payload.otp && usableSplitOtp.length === payload.otp.length) {
    usableSplitOtp.forEach((input, index) => setValue(input, payload.otp[index]));
    otpFilled = usableSplitOtp.length;
  }

  const primary = otpInputs[0] || usableSplitOtp[0] || passwordInputs[0] || identityInputs[0] || null;
  let submitted = false;
  if (payload.autoSubmit && primary && (identityFilled || passwordFilled || otpFilled)) {
    const form = primary.form || primary.closest('form');
    const buttons = Array.from((form || document).querySelectorAll('button, input[type="submit"]')).filter(visible);
    const actionPattern = /(next|continue|login|log in|sign in|verify|confirm|submit|entrar|acceder|iniciar|continuar|verificar|confirmar|validar)/i;
    const action = buttons.find((button) => actionPattern.test([
      button.textContent, button.value, button.name, button.id, button.getAttribute('aria-label')
    ].filter(Boolean).join(' '))) || buttons.find((button) => button.type === 'submit');
    try {
      if (action) {
        action.click();
        submitted = true;
      } else if (form && typeof form.requestSubmit === 'function') {
        form.requestSubmit();
        submitted = true;
      }
    } catch (_) {
      submitted = false;
    }
  }

  return {
    identityFilled,
    passwordFilled,
    otpFilled,
    submitted,
    stage: (otpInputs.length || usableSplitOtp.length) ? 'totp' : (passwordInputs.length || identityInputs.length ? 'credentials' : 'none'),
    hostname: location.hostname,
    path: location.pathname
  };
}

function inspectValidationPage(payload) {
  const visible = (element) => {
    if (!element || element.disabled) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.display !== 'none' && style.visibility !== 'hidden'
      && Number(style.opacity || 1) > 0 && rect.width > 2 && rect.height > 2;
  };
  const descriptorText = (element) => [element.type, element.name, element.id, element.placeholder,
    element.autocomplete, element.getAttribute('aria-label')].filter(Boolean).join(' ').toLowerCase();
  const inputs = Array.from(document.querySelectorAll('input, textarea')).filter(visible);
  const otpPattern = /(one[- ]?time|otp|totp|2fa|mfa|authenticator|verification|verify|security.?code|codigo|código|token|pin)/i;
  const credentialPattern = /(email|e-mail|correo|username|user.?name|usuario|login|account|cuenta)/i;
  const directOtpVisible = inputs.some((input) => input.autocomplete === 'one-time-code' || otpPattern.test(descriptorText(input)));
  const splitOtpCount = inputs.filter((input) => Number(input.maxLength) === 1
    && (input.inputMode === 'numeric' || input.type === 'tel' || input.type === 'number' || otpPattern.test(descriptorText(input)))).length;
  const otpVisible = directOtpVisible || splitOtpCount === 6 || splitOtpCount === 8;
  const passwordVisible = inputs.some((input) => input.type === 'password' && input.autocomplete !== 'new-password');
  const identityVisible = inputs.some((input) => input.type === 'email' || input.autocomplete === 'username'
    || credentialPattern.test(descriptorText(input)));
  const errorNodes = Array.from(document.querySelectorAll('[role="alert"], [aria-live="assertive"], .error, .errors, .invalid, .alert-danger, [data-error]'))
    .filter(visible).slice(0, 30);
  const errorText = errorNodes.map((node) => node.textContent || '').join(' ').replace(/\s+/g, ' ').trim().slice(0, 2000);
  const totpError = /(invalid|incorrect|wrong|expired|not valid|incorrecto|inválido|invalido|erróneo|erroneo|expirado).{0,40}(code|codigo|código|otp|token|verific)/i.test(errorText)
    || /(code|codigo|código|otp|token|verific).{0,40}(invalid|incorrect|wrong|expired|inválido|invalido|erróneo|erroneo|expirado)/i.test(errorText);
  const credentialError = /(invalid|incorrect|wrong|not match|incorrecto|inválido|invalido|erróneo|erroneo).{0,50}(password|contraseña|contrasena|email|correo|username|usuario|credential|credencial)/i.test(errorText)
    || /(password|contraseña|contrasena|email|correo|username|usuario|credential|credencial).{0,50}(invalid|incorrect|wrong|not match|inválido|invalido|erróneo|erroneo)/i.test(errorText);
  const authPath = /(^|\/)(login|signin|sign-in|auth|verify|verification|challenge|mfa|2fa)(\/|$)/i.test(location.pathname);
  let result = 'unknown';
  let confidence = 'low';
  if (totpError) {
    result = 'totp_invalid';
    confidence = 'high';
  } else if (credentialError) {
    result = 'credentials_invalid';
    confidence = 'high';
  } else if (otpVisible) {
    result = 'totp_required';
    confidence = 'medium';
  } else if (passwordVisible || identityVisible) {
    result = 'credentials_required';
    confidence = 'medium';
  } else if (!authPath && payload.expectedSite
    && (location.hostname === payload.expectedSite || location.hostname.endsWith(`.${payload.expectedSite}`))) {
    result = 'valid';
    confidence = 'medium';
  }
  return {
    result,
    confidence,
    errorText: errorText.slice(0, 300),
    hostname: location.hostname,
    path: location.pathname
  };
}

async function persistTotpVerification(pageId, accountId, factorId, patch) {
  const located = findPageAccountFactor(pageId, accountId, factorId);
  if (!located.account || !located.factor) throw new Error('No se encontró la cuenta o su método TOTP');
  const validation = normalizeValidationInfo(located.account);
  const index = validation.factors.findIndex((factor) => factor.id === factorId);
  if (index < 0) throw new Error('No se encontró la semilla TOTP');
  const factor = validation.factors[index];
  const current = normalizeTotpVerification(factor.totpVerification);
  factor.totpVerification = normalizeTotpVerification({ ...current, ...patch });
  const serverStatus = factor.totpVerification.serverStatus;
  if (serverStatus === 'valid') {
    factor.status = 'Verificada en el sitio';
    validation.status = 'Semilla TOTP validada por acceso aceptado';
    validation.lastVerified = patch.checkedAt || new Date().toISOString();
    located.account.status = 'valid';
    located.account.reason = '';
  } else if (serverStatus === 'invalid') {
    factor.status = 'Rechazada por el sitio';
    validation.status = 'La semilla TOTP ya no es válida para esta cuenta';
    located.account.status = 'invalid';
    located.account.reason = 'El servicio rechazó el código TOTP generado con la semilla guardada';
  } else if (serverStatus === 'credentials_invalid') {
    factor.status = 'Pendiente: credenciales rechazadas';
    validation.status = 'No se pudo comprobar la semilla porque las credenciales fueron rechazadas';
    located.account.status = 'invalid';
    located.account.reason = 'Correo, usuario o contraseña rechazados; la semilla TOTP no fue comprobada';
  } else if (serverStatus === 'submitted') {
    factor.status = 'Código generado; comprobación pendiente';
    validation.status = 'Código TOTP pendiente de comprobación manual';
  } else if (serverStatus === 'pending') {
    factor.status = 'Pendiente de comprobación manual';
    validation.status = factor.totpVerification.credentialsSubmitted
      ? 'Credenciales registradas; falta comprobar TOTP manualmente'
      : 'TOTP pendiente de comprobación manual';
  }
  validation.factors[index] = factor;
  validation.totp = factor.totp ? { ...factor.totp } : validation.totp;
  located.account.validation = validation;
  located.account.lastChecked = patch.checkedAt || new Date().toISOString();
  located.profile.updatedAt = located.account.lastChecked;
  await saveProfiles();
  render();
}

function totpVerificationDisplay(factor) {
  const verification = normalizeTotpVerification(factor && factor.totpVerification);
  if (verification.serverStatus === 'valid') return '✅ Aceptada por el servicio para esta cuenta';
  if (verification.serverStatus === 'invalid') return '❌ Rechazada por el servicio';
  if (verification.serverStatus === 'credentials_invalid') return '⚠️ No comprobada: las credenciales fueron rechazadas';
  if (verification.serverStatus === 'submitted') return '⏳ Código generado; comprobación pendiente';
  if (verification.localStatus === 'invalid_format') return '❌ Formato de semilla inválido';
  if (verification.localStatus === 'metadata_match') return '🟡 Formato válido y asociación probable; falta probar acceso';
  if (verification.localStatus === 'metadata_warning') return '⚠️ Formato válido, pero la asociación con la cuenta no coincide claramente';
  return '🟡 Formato válido; pendiente de comprobación manual';
}

function createTotpControls(pageId, account, factor) {
  const normalizedFactor = normalizeValidationFactor(factor);
  const config = normalizedFactor && normalizeTotpConfig(normalizedFactor.totp);
  if (!config) return null;
  const key = factorViewKey(pageId, account.id, normalizedFactor.id, 'totp');

  const box = document.createElement('div');
  box.className = 'totp-box';
  const heading = createTextElement('div', 'totp-heading', '🔐 Código TOTP actual');
  const meta = createTextElement(
    'div',
    'totp-meta',
    `${config.digits} dígitos · ${config.algorithm} · ventana real de ${config.period} segundos`
  );
  const output = document.createElement('div');
  output.className = 'totp-output';
  const code = createTextElement('span', 'totp-code', 'Código oculto');
  code.dataset.totpKey = key;
  code.dataset.totpRole = 'code';
  const countdown = createTextElement('span', 'totp-countdown', '');
  countdown.dataset.totpKey = key;
  countdown.dataset.totpRole = 'countdown';
  output.append(code, countdown);

  const generate = document.createElement('button');
  generate.type = 'button';
  generate.className = 'totp-generate';
  generate.textContent = 'Generar código';
  generate.title = 'Generar un código nuevo desde la semilla guardada; el servicio controla su duración';
  generate.addEventListener('click', () => generateAccountTotp(pageId, account, normalizedFactor, generate));

  const warning = createTextElement(
    'div',
    'totp-warning',
    'Se genera solo al pulsar. Se muestra 3 segundos, pero su validez real depende de la ventana configurada por el sitio.'
  );
  box.append(heading, meta, output, generate, warning);
  updateTotpNodes(key);
  return box;
}

function clearTemporaryFactorValue(key) {
  temporaryFactorValues.delete(key);
  const timer = temporaryFactorTimers.get(key);
  if (timer) clearInterval(timer);
  temporaryFactorTimers.delete(key);
}

function updateTemporaryFactorNodes(key) {
  const state = temporaryFactorValues.get(key);
  const remaining = state ? Math.max(0, Math.ceil((state.expiresAt - Date.now()) / 1000)) : 0;
  for (const node of document.querySelectorAll('[data-secret-key]')) {
    if (node.dataset.secretKey !== key) continue;
    if (node.dataset.secretRole === 'value') node.textContent = state ? state.value : 'Oculto';
    if (node.dataset.secretRole === 'countdown') node.textContent = state ? `${remaining} s` : '';
  }
  if (state && remaining <= 0) {
    clearTemporaryFactorValue(key);
    updateTemporaryFactorNodes(key);
  }
}

function showTemporaryFactorValue(key, value, label) {
  const text = optionalSecretText(value, 4000);
  if (!text) {
    setStatus(`${label}: no hay un dato guardado para mostrar.`, true);
    return;
  }
  clearTemporaryFactorValue(key);
  temporaryFactorValues.set(key, { value: text, expiresAt: Date.now() + SECRET_DISPLAY_MS });
  const timer = setInterval(() => updateTemporaryFactorNodes(key), 200);
  temporaryFactorTimers.set(key, timer);
  updateTemporaryFactorNodes(key);
  setStatus(`${label} visible durante 3 segundos.`);
}

function createTemporarySecretControl(key, buttonLabel, valueProvider, statusLabel, note = '') {
  const box = document.createElement('div');
  box.className = 'temporary-secret-box';
  const output = document.createElement('div');
  output.className = 'temporary-secret-output';
  const value = createTextElement('span', 'temporary-secret-value', 'Oculto');
  value.dataset.secretKey = key;
  value.dataset.secretRole = 'value';
  const countdown = createTextElement('span', 'temporary-secret-countdown', '');
  countdown.dataset.secretKey = key;
  countdown.dataset.secretRole = 'countdown';
  output.append(value, countdown);

  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'temporary-secret-button';
  button.textContent = buttonLabel;
  button.addEventListener('click', () => {
    const resolved = typeof valueProvider === 'function' ? valueProvider() : valueProvider;
    showTemporaryFactorValue(key, resolved, statusLabel);
  });
  box.append(output, button);
  if (note) box.append(createTextElement('div', 'temporary-secret-note', note));
  updateTemporaryFactorNodes(key);
  return box;
}

function openValidationPage(pageId, account, label) {
  const page = profiles.flatMap((profile) => profile.pages || []).find((item) => item.id === pageId);
  const target = safeUrl(account.sourceUrl) || (page && safeUrl(page.url));
  if (!target) {
    setStatus(`No hay una URL válida para ${label}.`, true);
    return;
  }
  tabsCreate(target.href)
    .then(() => setStatus(`${label}: página abierta para completar la validación.`))
    .catch((error) => setStatus(`No se pudo abrir la página: ${error.message}`, true));
}

function createOpenValidationControl(pageId, account, buttonLabel, note) {
  const box = document.createElement('div');
  box.className = 'validation-action-box';
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'validation-action-button';
  button.textContent = buttonLabel;
  button.addEventListener('click', () => openValidationPage(pageId, account, buttonLabel));
  box.append(button);
  if (note) box.append(createTextElement('div', 'temporary-secret-note', note));
  return box;
}

function clearAccountSensitiveState(pageId, accountId) {
  const prefix = `${pageId}::${accountId}::`;
  for (const key of Array.from(generatedTotpCodes.keys())) {
    if (key.startsWith(prefix)) clearTotpCode(key);
  }
  for (const key of Array.from(temporaryFactorValues.keys())) {
    if (key.startsWith(prefix)) clearTemporaryFactorValue(key);
  }
  for (const key of Array.from(recoveryCodeIndexes.keys())) {
    if (key.startsWith(prefix)) recoveryCodeIndexes.delete(key);
  }
}


function maskedIdentifier(value, visible = 8) {
  const text = optionalSecretText(value, 2000);
  if (!text) return 'No disponible';
  if (text.length <= visible * 2) return '••••••••';
  return `${text.slice(0, visible)}…${text.slice(-visible)}`;
}

function createValidationFactorDetails(pageId, account, factor, index) {
  const normalized = normalizeValidationFactor(factor, index);
  if (!normalized) return null;
  const box = document.createElement('div');
  box.className = 'validation-factor-box';
  box.append(
    createTextElement('div', 'validation-factor-title', `🔐 Método ${index + 1}: ${normalized.label}`),
    createReadOnlyField('Estado', normalized.status || (normalized.enabled ? 'Configurada' : 'Desactivada'))
  );
  if (normalized.provider) box.append(createReadOnlyField('Proveedor', normalized.provider));

  const actionKey = factorViewKey(pageId, account.id, normalized.id, normalized.type);

  if (normalized.type === 'sms') {
    box.append(
      createReadOnlyField('Teléfono / destino', normalized.phone || normalized.destination || 'No registrado'),
      createOpenValidationControl(
        pageId,
        account,
        'Abrir página y solicitar SMS',
        'El código SMS lo genera y envía el servicio. La extensión no puede inventar un código válido.'
      )
    );
    if (normalized.manualSecret) {
      box.append(createTemporarySecretControl(
        `${actionKey}::manual`,
        'Mostrar secreto manual 3 s',
        normalized.manualSecret,
        'Secreto manual SMS'
      ));
    }
  } else if (normalized.type === 'email') {
    box.append(
      createReadOnlyField('Correo de validación', normalized.email || normalized.destination || 'No registrado'),
      createOpenValidationControl(
        pageId,
        account,
        'Abrir página y solicitar correo',
        'El código lo envía el servicio al correo registrado; no existe una semilla TOTP para este método.'
      )
    );
    if (normalized.manualSecret) {
      box.append(createTemporarySecretControl(
        `${actionKey}::manual`,
        'Mostrar secreto manual 3 s',
        normalized.manualSecret,
        'Secreto manual de correo'
      ));
    }
  } else if (normalized.type === 'push') {
    box.append(
      createReadOnlyField('Aplicación', normalized.app || 'No registrada'),
      createReadOnlyField('Dispositivo', normalized.device || 'No registrado'),
      createOpenValidationControl(
        pageId,
        account,
        'Abrir página para aprobar push',
        'La aprobación se realiza en la aplicación o dispositivo registrado; no genera un código local.'
      )
    );
    if (normalized.manualSecret) {
      box.append(createTemporarySecretControl(
        `${actionKey}::manual`,
        'Mostrar secreto manual 3 s',
        normalized.manualSecret,
        'Secreto manual push'
      ));
    }
  } else if (normalized.type === 'totp') {
    const totp = normalizeTotpConfig(normalized.totp);
    box.append(
      createReadOnlyField('Semilla TOTP', totp ? '•••••••••••••••• · oculta' : 'No disponible', totp ? 'secret-row' : ''),
      createReadOnlyField('Periodo', totp ? `${totp.period} segundos` : 'No aplica'),
      createReadOnlyField('Dígitos / algoritmo', totp ? `${totp.digits} · ${totp.algorithm}` : 'No aplica'),
      createReadOnlyField('Emisor / etiqueta', totp ? [totp.issuer, totp.label].filter(Boolean).join(' · ') || 'No registrado' : 'No aplica'),
      createReadOnlyField('Comprobación de semilla', totpVerificationDisplay(normalized))
    );
    const controls = createTotpControls(pageId, account, normalized);
    if (controls) box.append(controls);
  } else if (normalized.type === 'passkey') {
    box.append(
      createReadOnlyField('RP ID', normalized.rpId || 'No registrado'),
      createReadOnlyField('ID de credencial', maskedIdentifier(normalized.credentialId), normalized.credentialId ? 'secret-row' : ''),
      createReadOnlyField('Dispositivo', normalized.device || 'No registrado'),
      createReadOnlyField('Transportes', normalized.transports.join(', ') || 'No registrados'),
      createReadOnlyField('Clave privada', 'No exportable por diseño'),
      createOpenValidationControl(
        pageId,
        account,
        'Abrir página y usar passkey',
        'La passkey firma el desafío dentro del sistema o dispositivo. No produce un código de acceso exportable.'
      )
    );
  } else if (normalized.type === 'security_key') {
    box.append(
      createReadOnlyField('Llave', [normalized.vendor, normalized.model].filter(Boolean).join(' · ') || 'No registrada'),
      createReadOnlyField('Serie', maskedIdentifier(normalized.serial), normalized.serial ? 'secret-row' : ''),
      createReadOnlyField('ID de credencial', maskedIdentifier(normalized.credentialId), normalized.credentialId ? 'secret-row' : ''),
      createReadOnlyField('Transportes', normalized.transports.join(', ') || 'No registrados'),
      createReadOnlyField('Clave privada', 'Permanece dentro de la llave física'),
      createOpenValidationControl(
        pageId,
        account,
        'Abrir página y usar llave física',
        'La llave responde físicamente al desafío del sitio. No genera un código que la extensión pueda copiar.'
      )
    );
  } else if (normalized.type === 'recovery_codes') {
    box.append(createReadOnlyField(
      'Códigos guardados',
      normalized.recoveryCodes.length ? `${normalized.recoveryCodes.length} · ocultos` : 'Ninguno',
      normalized.recoveryCodes.length ? 'secret-row' : ''
    ));
    if (normalized.recoveryCodes.length) {
      box.append(createTemporarySecretControl(
        `${actionKey}::recovery`,
        'Mostrar siguiente código 3 s',
        () => {
          const current = recoveryCodeIndexes.get(actionKey) || 0;
          const indexToShow = current % normalized.recoveryCodes.length;
          recoveryCodeIndexes.set(actionKey, current + 1);
          return `${normalized.recoveryCodes[indexToShow]}  (${indexToShow + 1}/${normalized.recoveryCodes.length})`;
        },
        'Código de recuperación',
        'Muestra un código ya guardado; no crea uno nuevo ni lo marca como utilizado.'
      ));
    }
  } else if (normalized.type === 'security_question') {
    box.append(
      createReadOnlyField('Pregunta', normalized.question || 'No registrada'),
      createReadOnlyField('Respuesta', normalized.answer ? '•••••••••••• · oculta' : 'No disponible', normalized.answer ? 'secret-row' : '')
    );
    if (normalized.answer) {
      box.append(createTemporarySecretControl(
        `${actionKey}::answer`,
        'Mostrar respuesta 3 s',
        normalized.answer,
        'Respuesta de seguridad'
      ));
    }
  } else if (normalized.type === 'password_only') {
    box.append(createReadOnlyField('Validación adicional', 'No utiliza un segundo factor'));
  } else {
    box.append(createReadOnlyField(
      'Secreto manual',
      normalized.manualSecret ? '•••••••••••• · oculto' : 'No disponible',
      normalized.manualSecret ? 'secret-row' : ''
    ));
    if (normalized.manualSecret) {
      box.append(createTemporarySecretControl(
        `${actionKey}::unknown`,
        'Mostrar secreto 3 s',
        normalized.manualSecret,
        'Secreto manual'
      ));
    }
  }

  if (normalized.manualSecret && !['sms', 'email', 'push', 'unknown'].includes(normalized.type)) {
    box.append(
      createReadOnlyField('Dato secreto adicional', '•••••••••••• · oculto', 'secret-row'),
      createTemporarySecretControl(
        `${actionKey}::additional`,
        'Mostrar dato adicional 3 s',
        normalized.manualSecret,
        'Dato secreto adicional'
      )
    );
  }
  if (normalized.detail) box.append(createReadOnlyField('Detalle', normalized.detail));
  return box;
}

function createAccountDetails(pageId, account) {
  const details = document.createElement('div');
  details.className = 'account-details';
  details.setAttribute('aria-label', `Datos de solo lectura de ${account.name}`);

  const credentials = account.credentials || {};
  const validation = normalizeValidationInfo(account);
  const hasCredentials = accountHasCredentialData(account);
  const hasValidation = accountHasValidationData(account);

  if (!hasCredentials && !hasValidation) {
    details.append(createTextElement(
      'div',
      'account-data-notice',
      'Esta fila representa una sesión detectada por cookies. No contiene correo, usuario, contraseña ni validación porque esos datos no estaban registrados en el perfil o fueron omitidos en una copia anterior.'
    ));
    details.append(
      createReadOnlyField('Origen de datos', accountSourceLabel(account)),
      createReadOnlyField('Credenciales', 'No registradas en este perfil'),
      createReadOnlyField('Validación', 'No registrada'),
      createReadOnlyField('Estado de acceso', accountStatusLabel(account).text)
    );
  } else {
    details.append(
      createReadOnlyField('Correo', accountDetailValue(credentials.email, 'No registrado en el perfil')),
      createReadOnlyField('Usuario', accountDetailValue(credentials.username, 'No registrado en el perfil')),
      createReadOnlyField('Contraseña', credentials.password ? '•••••••••••• · guardada' : 'No registrada en el perfil', 'secret-row'),
      createReadOnlyField('Validación', validation.enabled ? 'Sí' : 'No'),
      createReadOnlyField('Métodos guardados', validation.factors.length ? `${validation.factors.length} de ${MAX_VALIDATION_FACTORS}` : 'Ninguno'),
      createReadOnlyField('Estado de validación', accountDetailValue(validation.status, validation.enabled ? 'Configurada' : 'No registrada')),
      createReadOnlyField('Estado de acceso', accountStatusLabel(account).text),
      createReadOnlyField('Origen de datos', accountSourceLabel(account))
    );
    if (credentials.password) {
      details.append(createTemporarySecretControl(
        `${pageId}::${account.id}::password`,
        'Mostrar contraseña 3 s',
        credentials.password,
        'Contraseña'
      ));
    }
  }
  validation.factors.forEach((factor, index) => {
    const factorBox = createValidationFactorDetails(pageId, account, factor, index);
    if (factorBox) details.append(factorBox);
  });
  if (account.sourceUrl) details.append(createReadOnlyField('Página asociada', account.sourceUrl));
  if (validation.detail) details.append(createReadOnlyField('Detalle general', validation.detail));
  const note = createTextElement(
    'div',
    'account-readonly-note',
    'Solo lectura · secretos enmascarados · acciones sensibles visibles durante 3 segundos · la ficha completa se oculta automáticamente después de 30 segundos.'
  );
  details.append(note);
  return details;
}

function toggleAccountDetails(pageId, accountId) {
  const key = accountViewKey(pageId, accountId);
  const currentTimer = accountRevealTimers.get(key);
  if (currentTimer) clearTimeout(currentTimer);
  accountRevealTimers.delete(key);

  if (revealedAccounts.has(key)) {
    revealedAccounts.delete(key);
    clearAccountSensitiveState(pageId, accountId);
  } else {
    revealedAccounts.add(key);
    const timer = setTimeout(() => {
      revealedAccounts.delete(key);
      accountRevealTimers.delete(key);
      clearAccountSensitiveState(pageId, accountId);
      render();
    }, ACCOUNT_REVEAL_MS);
    accountRevealTimers.set(key, timer);
  }
  render();
}

function hideAccountDetailsForPage(pageId) {
  const prefix = `${pageId}::`;
  for (const key of Array.from(revealedAccounts)) {
    if (!key.startsWith(prefix)) continue;
    revealedAccounts.delete(key);
    const timer = accountRevealTimers.get(key);
    if (timer) clearTimeout(timer);
    accountRevealTimers.delete(key);
    const accountId = key.slice(prefix.length);
    clearAccountSensitiveState(pageId, accountId);
  }
}


function findProfilePageAccount(pageId, accountId) {
  for (const profile of profiles) {
    const page = (profile.pages || []).find((item) => item.id === pageId);
    if (!page) continue;
    const account = (page.accounts || []).find((item) => item.id === accountId);
    if (account) return { profile, page, account };
  }
  return { profile: null, page: null, account: null };
}

function accountSessionCookies(account) {
  return Array.isArray(account && account.sessionCookies)
    ? account.sessionCookies.filter(Boolean)
    : [];
}

async function applyAccountSession(pageId, accountId) {
  const located = findProfilePageAccount(pageId, accountId);
  if (!located.account || !located.page) return;
  const snapshot = accountSessionCookies(located.account);
  if (!snapshot.length) {
    setStatus('Esta cuenta no contiene una sesión exportada disponible.', true);
    return;
  }

  const label = located.account.displayName || located.account.name;
  try {
    setStatus(`Cambiando a ${label}…`);
    let ok = 0;
    let failed = 0;
    for (const cookie of snapshot) {
      const result = await setCookieWithVerification(cookie);
      if (result.ok) ok += 1;
      else failed += 1;
    }
    located.account.lastChecked = new Date().toISOString();
    located.account.status = ok ? 'valid' : 'invalid';
    located.account.reason = failed ? `${failed} cookies no pudieron restaurarse` : '';
    await saveProfiles();
    await openPage(located.account.sourceUrl || located.page.url);
    render();
    setStatus(`${label}: ${ok} cookies aplicadas, ${failed} errores.`, failed > 0);
  } catch (error) {
    setStatus(`No se pudo abrir la cuenta: ${error.message}`, true);
  }
}

function createAccountList(page) {
  const list = document.createElement('div');
  list.className = 'account-list';

  if (!page.accounts.length) {
    list.append(createTextElement('div', 'no-accounts', 'Sin cuentas relacionadas detectadas.'));
    return list;
  }

  for (const account of page.accounts) {
    const item = document.createElement('div');
    item.className = 'account-item';
    const row = document.createElement('div');
    row.className = 'account-row';

    const name = createTextElement('span', 'account-name', `👤 ${account.displayName || account.name}`);
    name.title = account.cookieCount
      ? `${account.cookieCount} datos de sesión asociados`
      : (account.displayName || account.name);

    const label = accountStatusLabel(account);
    const state = createTextElement('span', `account-status ${account.status}`, label.icon);
    state.title = `${label.text}${account.lastChecked ? ` · ${new Date(account.lastChecked).toLocaleString()}` : ''}`;
    state.setAttribute('aria-label', label.text);

    const key = accountViewKey(page.id, account.id);
    const revealed = revealedAccounts.has(key);
    const reveal = document.createElement('button');
    reveal.type = 'button';
    reveal.className = 'account-reveal';
    reveal.textContent = revealed ? '🙈' : '👁';
    reveal.title = revealed ? 'Ocultar datos de la cuenta' : 'Ver datos de la cuenta';
    reveal.setAttribute('aria-expanded', String(revealed));
    reveal.setAttribute('aria-label', `${revealed ? 'Ocultar' : 'Ver'} datos de ${account.displayName || account.name}`);
    reveal.addEventListener('click', () => toggleAccountDetails(page.id, account.id));

    const openSession = document.createElement('button');
    openSession.type = 'button';
    openSession.className = 'account-session-open';
    openSession.textContent = '▶';
    openSession.title = accountSessionCookies(account).length
      ? 'Cambiar a esta cuenta y abrir la página'
      : 'Esta cuenta no tiene una sesión exportada disponible';
    openSession.disabled = accountSessionCookies(account).length === 0;
    openSession.setAttribute('aria-label', `Abrir ${account.displayName || account.name}`);
    openSession.addEventListener('click', () => startBackgroundAction('openAccount', { pageId: page.id, accountId: account.id }));

    row.append(name, state, openSession, reveal);
    item.append(row);
    if (revealed) item.append(createAccountDetails(page.id, account));
    list.append(item);
  }
  return list;
}

function createProfileDetails(profile) {
  const details = document.createElement('div');
  details.className = 'profile-details';

  const profileActions = document.createElement('div');
  profileActions.className = 'profile-tools profile-tools-top';

  const apply = document.createElement('button');
  apply.type = 'button';
  apply.textContent = '🍪 Aplicar perfil';
  apply.addEventListener('click', () => startBackgroundAction('applyProfile', { profileId: profile.id }));

  const validateAll = document.createElement('button');
  validateAll.type = 'button';
  validateAll.textContent = '🔄 Validar páginas';
  validateAll.addEventListener('click', () => startBackgroundAction('validateProfile', { profileId: profile.id }));

  profileActions.append(apply, validateAll);
  details.append(profileActions);

  if (!profile.pages.length) {
    details.append(createTextElement('div', 'no-pages', 'Sin páginas registradas.'));
  } else {
    const list = document.createElement('div');
    list.className = 'page-list';
    const statusPriority = { valid: 0, invalid: 1, unknown: 2 };
    const sortedPages = profile.pages
      .map((page, originalIndex) => ({ page, originalIndex }))
      .sort((left, right) => {
        const statusDifference = (statusPriority[left.page.status] ?? 2) - (statusPriority[right.page.status] ?? 2);
        if (statusDifference !== 0) return statusDifference;
        const leftChecked = Date.parse(left.page.lastChecked || '') || 0;
        const rightChecked = Date.parse(right.page.lastChecked || '') || 0;
        if (leftChecked !== rightChecked) return rightChecked - leftChecked;
        return left.originalIndex - right.originalIndex;
      })
      .map(({ page }) => page);
    for (const page of sortedPages) {
      const item = document.createElement('div');
      item.className = 'page-item';

      const row = document.createElement('div');
      row.className = 'page-row';

      const open = document.createElement('button');
      open.type = 'button';
      open.className = 'page-open';
      open.textContent = `🌐 ${page.name}`;
      open.title = `Abrir ${page.url}`;
      open.addEventListener('click', () => openPage(page.url));

      const accountMetric = createTextElement('span', 'page-account-count', `👤${page.accounts.length}`);
      accountMetric.title = `${page.accounts.length} cuenta${page.accounts.length === 1 ? '' : 's'} relacionada${page.accounts.length === 1 ? '' : 's'}`;

      const label = statusLabel(page);
      const state = createTextElement('span', `page-status ${page.status}`, label.icon);
      state.title = `${label.text}${page.lastChecked ? ` · ${new Date(page.lastChecked).toLocaleString()}` : ''}`;
      state.setAttribute('aria-label', label.text);

      const validatePageButton = document.createElement('button');
      validatePageButton.type = 'button';
      validatePageButton.className = 'page-validate';
      validatePageButton.textContent = '✅';
      validatePageButton.title = `Validar ${page.name}`;
      validatePageButton.setAttribute('aria-label', `Validar página ${page.name}`);
      validatePageButton.addEventListener('click', () => startBackgroundAction('validatePage', { profileId: profile.id, pageId: page.id }));

      const accountsExpanded = Boolean(activeSearchQuery) || expandedPages.has(page.id);
      const toggle = document.createElement('button');
      toggle.type = 'button';
      toggle.className = 'page-accounts-toggle';
      toggle.textContent = page.accounts.length ? (accountsExpanded ? '▲' : '▼') : '—';
      toggle.disabled = page.accounts.length === 0;
      toggle.setAttribute('aria-expanded', String(accountsExpanded));
      toggle.setAttribute('aria-label', `${accountsExpanded ? 'Ocultar' : 'Ver'} cuentas de ${page.name}`);
      toggle.title = page.accounts.length
        ? `${accountsExpanded ? 'Ocultar' : 'Ver'} cuentas relacionadas`
        : 'No hay cuentas relacionadas';
      toggle.addEventListener('click', () => togglePageAccounts(page.id));

      row.append(open, accountMetric, state, validatePageButton, toggle);
      item.append(row);
      if (accountsExpanded && page.accounts.length) item.append(createAccountList(page));
      list.append(item);
    }
    details.append(list);
  }

  return details;
}

function togglePageAccounts(pageId) {
  if (expandedPages.has(pageId)) {
    expandedPages.delete(pageId);
    hideAccountDetailsForPage(pageId);
  } else expandedPages.add(pageId);
  render();
}

function toggleProfile(profileId) {
  if (expandedProfiles.has(profileId)) {
    expandedProfiles.delete(profileId);
    const profile = profiles.find((item) => item.id === profileId);
    if (profile) for (const page of profile.pages) hideAccountDetailsForPage(page.id);
  } else expandedProfiles.add(profileId);
  render();
}

async function deleteProfile(profileId) {
  const profile = profiles.find((item) => item.id === profileId);
  if (!profile) return;
  if (!confirm(`¿Eliminar el perfil “${profile.name}”?`)) return;
  await new Promise((resolve) => {
    chrome.runtime.sendMessage({ channel: 'cookies-pro-background', type: 'cancelProfile', profileId }, () => resolve());
  });
  profiles = profiles.filter((item) => item.id !== profileId);
  expandedProfiles.delete(profileId);
  for (const page of profile.pages) {
    expandedPages.delete(page.id);
    hideAccountDetailsForPage(page.id);
  }
  await saveProfiles();
  render();
  setStatus(`Perfil eliminado: ${profile.name}`);
}

function makeCookieLocallyPersistent(cookie) {
  if (!cookie || typeof cookie !== 'object') return cookie;
  return {
    ...cookie,
    session: false,
    expirationDate: Math.floor(Date.now() / 1000) + PERSISTENT_COOKIE_LIFETIME_SECONDS
  };
}

function buildCookieSetDetails(cookie, overrideUrl = null, omitStoreId = false) {
  const persistentCookie = makeCookieLocallyPersistent(cookie);
  const url = overrideUrl || cookieUrl(persistentCookie);
  if (!url || typeof persistentCookie.name !== 'string') return null;

  const details = {
    url,
    name: persistentCookie.name,
    value: String(persistentCookie.value ?? ''),
    path: normalizePath(persistentCookie.path),
    secure: Boolean(persistentCookie.secure),
    httpOnly: Boolean(persistentCookie.httpOnly)
  };

  if (!persistentCookie.hostOnly && persistentCookie.domain) details.domain = persistentCookie.domain;
  if (!omitStoreId && typeof persistentCookie.storeId === 'string' && persistentCookie.storeId) details.storeId = persistentCookie.storeId;
  if (['no_restriction', 'lax', 'strict'].includes(persistentCookie.sameSite)) details.sameSite = persistentCookie.sameSite;
  details.expirationDate = Number(persistentCookie.expirationDate);
  if (persistentCookie.partitionKey && typeof persistentCookie.partitionKey === 'object') details.partitionKey = { ...persistentCookie.partitionKey };
  return details;
}

function cookieIdentity(cookie) {
  const partition = cookie && cookie.partitionKey && typeof cookie.partitionKey === 'object'
    ? `${cookie.partitionKey.topLevelSite || ''}|${cookie.partitionKey.hasCrossSiteAncestor === true ? '1' : cookie.partitionKey.hasCrossSiteAncestor === false ? '0' : ''}`
    : '';
  return [
    String(cookie && cookie.storeId || ''),
    partition,
    String(cookie && cookie.domain || '').toLowerCase(),
    normalizePath(cookie && cookie.path),
    String(cookie && cookie.name || '')
  ].join('\u001f');
}

function cookieUrlCandidates(cookie) {
  const host = cookieDomain(cookie);
  if (!host) return [];
  const path = normalizePath(cookie.path);
  const protocols = cookie.secure ? ['https'] : ['https', 'http'];
  return protocols.map((protocol) => `${protocol}://${host}${path}`);
}

function partitionKeysEqual(expected, actual) {
  const left = expected && typeof expected === 'object' ? expected : null;
  const right = actual && typeof actual === 'object' ? actual : null;
  if (!left && !right) return true;
  if (!left || !right) return false;
  if (typeof left.topLevelSite === 'string'
      && String(left.topLevelSite) !== String(right.topLevelSite || '')) return false;
  if (typeof left.hasCrossSiteAncestor === 'boolean'
      && left.hasCrossSiteAncestor !== right.hasCrossSiteAncestor) return false;
  return true;
}

function restoredCookieMatches(expected, actual) {
  if (!actual) return false;
  if (String(actual.name) !== String(expected.name)) return false;
  if (String(actual.value) !== String(expected.value ?? '')) return false;
  if (cookieDomain(actual) !== cookieDomain(expected)) return false;
  if (normalizePath(actual.path) !== normalizePath(expected.path)) return false;
  if (Boolean(actual.secure) !== Boolean(expected.secure)) return false;
  if (Boolean(actual.httpOnly) !== Boolean(expected.httpOnly)) return false;
  if (Boolean(actual.hostOnly) !== Boolean(expected.hostOnly)) return false;
  if (Boolean(actual.session) !== Boolean(expected.session)) return false;
  if (['no_restriction', 'lax', 'strict'].includes(expected.sameSite)
      && actual.sameSite !== expected.sameSite) return false;
  if (!partitionKeysEqual(expected.partitionKey, actual.partitionKey)) return false;
  if (!expected.session && Number.isFinite(Number(expected.expirationDate))) {
    if (!Number.isFinite(Number(actual.expirationDate))) return false;
    if (Math.abs(Number(actual.expirationDate) - Number(expected.expirationDate)) > 2) return false;
  }
  return true;
}

async function setCookieWithVerification(cookie) {
  if (!cookie || typeof cookie !== 'object') return { ok: false, reason: 'registro inválido' };
  const persistentCookie = makeCookieLocallyPersistent(cookie);

  const urls = cookieUrlCandidates(persistentCookie);
  if (!urls.length) return { ok: false, reason: 'dominio inválido' };
  let lastError = 'no se pudo guardar';

  const storeModes = typeof persistentCookie.storeId === 'string' && persistentCookie.storeId ? [false, true] : [false];
  for (const omitStoreId of storeModes) {
    for (const url of urls) {
      for (let attempt = 0; attempt < COOKIE_SET_RETRIES; attempt += 1) {
        const details = buildCookieSetDetails(persistentCookie, url, omitStoreId);
        if (!details) return { ok: false, reason: 'datos incompletos' };
        try {
          const saved = await cookiesSet(details);
          let verified = saved;
          if (!restoredCookieMatches(persistentCookie, verified)) {
            const lookup = { url, name: persistentCookie.name };
            if (!omitStoreId && details.storeId) lookup.storeId = details.storeId;
            if (details.partitionKey) lookup.partitionKey = details.partitionKey;
            verified = await cookiesGet(lookup);
          }
          if (restoredCookieMatches(persistentCookie, verified)) {
            return { ok: true, storeFallback: omitStoreId };
          }
          lastError = 'la comprobación posterior no coincide';
        } catch (error) {
          lastError = error.message || String(error);
        }
      }
    }
  }
  return { ok: false, reason: lastError };
}

async function applyProfile(profileId, options = {}) {
  const profile = profiles.find((item) => item.id === profileId);
  if (!profile) return;

  const sensitive = profile.cookies.filter((cookie) => isSensitive(cookieDomain(cookie))).length;
  const requireConfirmation = options.requireConfirmation !== false;
  if (requireConfirmation && sensitive && !confirm(`Este perfil contiene ${sensitive} cookies de dominios sensibles. Úsalo solo en tu propio navegador. ¿Continuar?`)) {
    return { cancelled: true, ok: 0, failed: 0, fallbackStores: 0 };
  }

  const manageStatus = options.manageStatus !== false;
  const validateAfter = options.validateAfter !== false;
  if (manageStatus) setStatus(`Aplicando y verificando ${profile.name}…`);
  let ok = 0;
  let failed = 0;
  let fallbackStores = 0;
  const failureReasons = new Map();

  const ordered = profile.cookies.slice().sort((a, b) => {
    const domainDiff = cookieDomain(a).length - cookieDomain(b).length;
    if (domainDiff) return domainDiff;
    return normalizePath(a.path).length - normalizePath(b.path).length;
  });

  for (const cookie of ordered) {
    const result = await setCookieWithVerification(cookie);
    if (result.ok) {
      ok += 1;
      if (result.storeFallback) fallbackStores += 1;
    } else {
      failed += 1;
      const reason = result.reason || 'error desconocido';
      failureReasons.set(reason, (failureReasons.get(reason) || 0) + 1);
    }
  }

  profile.history.push({
    date: new Date().toISOString(),
    count: ok,
    failed,
    storeFallbacks: fallbackStores,
    errors: Object.fromEntries(failureReasons),
    action: 'apply_verified'
  });
  profile.updatedAt = new Date().toISOString();
  await saveProfiles();

  let pageSummary = '';
  if (validateAfter && ok > 0 && profile.pages.length) {
    await validateProfiles([profile], { applyBeforeValidation: false });
    const valid = profile.pages.filter((page) => page.status === 'valid').length;
    const invalid = profile.pages.filter((page) => page.status === 'invalid').length;
    pageSummary = ` · páginas: ${valid} válidas, ${invalid} fallidas`;
  }

  const fallbackSummary = fallbackStores ? ` · ${fallbackStores} adaptadas al almacén actual` : '';
  if (manageStatus) setStatus(`Aplicado y verificado: ${ok} cookies, ${failed} errores${fallbackSummary}${pageSummary}.`, failed > 0);
  return { cancelled: false, ok, failed, fallbackStores, pageSummary };
}

async function openPage(url) {
  const parsed = safeUrl(url);
  if (!parsed) return setStatus('La página guardada no tiene una URL válida.', true);
  try {
    await tabsCreate(parsed.href);
  } catch (error) {
    setStatus(`No se pudo abrir la página: ${error.message}`, true);
  }
}

function looksLikeAuthRedirect(url) {
  try {
    const parsed = new URL(url);
    return /(^|\/)(login|signin|sign-in|auth|account\/login)(\/|$)/i.test(parsed.pathname)
      || /accounts\.google\.com$/i.test(parsed.hostname);
  } catch (_) {
    return false;
  }
}

async function probePage(page) {
  const target = page.validation && safeUrl(page.validation.requestedUrl)
    ? page.validation.requestedUrl
    : page.url;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    const response = await fetch(target, {
      method: 'GET',
      credentials: 'include',
      redirect: 'follow',
      cache: 'no-store',
      signal: controller.signal
    });
    const authRedirect = looksLikeAuthRedirect(response.url)
      || (response.redirected && looksLikeAuthRedirect(response.url));
    if (response.body) response.body.cancel().catch(() => {});
    if (authRedirect) {
      return { status: 'invalid', reason: 'Redirigida al inicio de sesión', retryable: false };
    }
    if (response.status === 401 || response.status === 403) {
      return { status: 'invalid', reason: `Sesión rechazada (HTTP ${response.status})`, retryable: false };
    }
    if (response.ok) {
      return {
        status: 'valid',
        reason: '',
        retryable: false,
        finalUrl: response.url,
        httpStatus: response.status
      };
    }
    return {
      status: 'invalid',
      reason: `HTTP ${response.status}`,
      retryable: response.status >= 500,
      finalUrl: response.url,
      httpStatus: response.status
    };
  } catch (error) {
    return {
      status: 'invalid',
      reason: error.name === 'AbortError' ? 'Tiempo agotado' : 'No disponible',
      retryable: true
    };
  } finally {
    clearTimeout(timeout);
  }
}

async function checkPage(page) {
  if (page.protected) {
    return { status: 'invalid', reason: page.reason || 'Cookies protegidas' };
  }

  let result = null;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    result = await probePage(page);
    if (!result.retryable) break;
  }

  page.validation = {
    ...(page.validation || {}),
    requestedUrl: page.validation && page.validation.requestedUrl ? page.validation.requestedUrl : page.url,
    finalUrl: result.finalUrl || null,
    httpStatus: Number.isFinite(result.httpStatus) ? result.httpStatus : null,
    checkedAt: new Date().toISOString()
  };
  return { status: result.status, reason: result.reason };
}

async function runPool(items, worker, concurrency = 4) {
  const queue = items.slice();
  const runners = Array.from({ length: Math.min(concurrency, queue.length) }, async () => {
    while (queue.length) {
      const item = queue.shift();
      await worker(item);
    }
  });
  await Promise.all(runners);
}

async function reloadOpenTabsForProfiles(targetProfiles) {
  const hostnames = new Set();
  for (const profile of targetProfiles) {
    for (const page of profile.pages || []) {
      const parsed = safeUrl(page.url);
      if (parsed) hostnames.add(parsed.hostname.toLowerCase());
    }
  }
  if (!hostnames.size) return { reloaded: 0, failed: 0 };

  const tabs = await tabsQuery({});
  let reloaded = 0;
  let failed = 0;
  for (const tab of tabs) {
    if (!tab || !Number.isInteger(tab.id)) continue;
    const parsed = safeUrl(tab.url);
    if (!parsed) continue;
    const hostname = parsed.hostname.toLowerCase();
    const matches = [...hostnames].some((saved) => hostname === saved || hostname.endsWith(`.${saved}`) || saved.endsWith(`.${hostname}`));
    if (!matches) continue;
    try {
      await tabsReload(tab.id);
      reloaded += 1;
    } catch (_) {
      failed += 1;
    }
  }
  return { reloaded, failed };
}

async function validateProfiles(targetProfiles, options = {}) {
  const applyBeforeValidation = options.applyBeforeValidation !== false;
  let restoredOk = 0;
  let restoredFailed = 0;
  if (applyBeforeValidation) {
    setStatus(`Preparando ${targetProfiles.length} perfil(es) para validar…`);
    for (const profile of targetProfiles) {
      const result = await applyProfile(profile.id, {
        requireConfirmation: false,
        validateAfter: false,
        manageStatus: false
      });
      if (result) {
        restoredOk += result.ok || 0;
        restoredFailed += result.failed || 0;
      }
    }
  }

  let reloadSummary = { reloaded: 0, failed: 0 };
  if (applyBeforeValidation && restoredOk > 0) {
    reloadSummary = await reloadOpenTabsForProfiles(targetProfiles);
  }

  const pages = targetProfiles.flatMap((profile) => profile.pages.map((page) => ({ profile, page })));
  if (!pages.length) {
    setStatus('No hay páginas para validar.');
    return;
  }

  let done = 0;
  setStatus(`Actualizando páginas: 0/${pages.length}…`);
  await runPool(pages, async ({ profile, page }) => {
    const result = await checkPage(page);
    page.status = result.status;
    page.reason = result.reason;
    page.lastChecked = new Date().toISOString();
    for (const account of page.accounts) {
      const independent = normalizeValidationInfo(account).factors
        .filter((factor) => factor.type === 'totp')
        .map((factor) => normalizeTotpVerification(factor.totpVerification))
        .find((verification) => ['valid', 'invalid', 'credentials_invalid', 'submitted'].includes(verification.serverStatus));
      if (!independent || independent.serverStatus === 'submitted') {
        account.status = result.status;
        account.reason = result.reason;
      }
      account.lastChecked = page.lastChecked;
    }
    profile.updatedAt = page.lastChecked;
    done += 1;
    setStatus(`Actualizando páginas: ${done}/${pages.length}…`);
  });

  await saveProfiles();
  render();
  const valid = pages.filter(({ page }) => page.status === 'valid').length;
  const invalid = pages.length - valid;
  const restored = applyBeforeValidation
    ? ` Cookies aplicadas: ${restoredOk}; errores: ${restoredFailed}. Pestañas recargadas: ${reloadSummary.reloaded}${reloadSummary.failed ? `; errores de recarga: ${reloadSummary.failed}` : ''}.`
    : '';
  setStatus(`Validación terminada: ${valid} correctas, ${invalid} fallidas.${restored}`, invalid > 0 || restoredFailed > 0 || reloadSummary.failed > 0);
}

function cookieBelongsToPage(cookie, page) {
  const parsed = safeUrl(page && page.url);
  if (!parsed) return false;
  const host = parsed.hostname.toLowerCase();
  const domain = cookieDomain(cookie).replace(/^\./, '').toLowerCase();
  return Boolean(domain) && (host === domain || host.endsWith(`.${domain}`) || domain.endsWith(`.${host}`));
}

async function reloadOpenTabsForPage(page) {
  const parsed = safeUrl(page && page.url);
  if (!parsed) return { reloaded: 0, failed: 0 };
  const target = parsed.hostname.toLowerCase();
  const tabs = await tabsQuery({});
  let reloaded = 0;
  let failed = 0;
  for (const tab of tabs) {
    if (!tab || !Number.isInteger(tab.id)) continue;
    const current = safeUrl(tab.url);
    if (!current) continue;
    const host = current.hostname.toLowerCase();
    if (!(host === target || host.endsWith(`.${target}`) || target.endsWith(`.${host}`))) continue;
    try {
      await tabsReload(tab.id);
      reloaded += 1;
    } catch (_) {
      failed += 1;
    }
  }
  return { reloaded, failed };
}

async function validateSinglePage(profileId, pageId) {
  const profile = profiles.find((item) => item.id === profileId);
  const page = profile && profile.pages.find((item) => item.id === pageId);
  if (!profile || !page) return;

  const cookies = profile.cookies.filter((cookie) => cookieBelongsToPage(cookie, page));
  let restoredOk = 0;
  let restoredFailed = 0;
  setStatus(`Validando ${page.name}…`);
  for (const cookie of cookies) {
    const result = await setCookieWithVerification(cookie);
    if (result.ok) restoredOk += 1;
    else restoredFailed += 1;
  }

  const reload = restoredOk ? await reloadOpenTabsForPage(page) : { reloaded: 0, failed: 0 };
  const result = await checkPage(page);
  page.status = result.status;
  page.reason = result.reason;
  page.lastChecked = new Date().toISOString();
  for (const account of page.accounts || []) {
    const independent = normalizeValidationInfo(account).factors
      .filter((factor) => factor.type === 'totp')
      .map((factor) => normalizeTotpVerification(factor.totpVerification))
      .find((verification) => ['valid', 'invalid', 'credentials_invalid', 'submitted'].includes(verification.serverStatus));
    if (!independent || independent.serverStatus === 'submitted') {
      account.status = result.status;
      account.reason = result.reason;
    }
    account.lastChecked = page.lastChecked;
  }
  profile.updatedAt = page.lastChecked;
  await saveProfiles();
  render();
  const label = result.status === 'valid' ? 'válida' : 'no válida';
  setStatus(`${page.name}: ${label}. Cookies aplicadas: ${restoredOk}; errores: ${restoredFailed}; pestañas recargadas: ${reload.reloaded}.`, result.status !== 'valid' || restoredFailed > 0 || reload.failed > 0);
}

async function validateProfile(profileId) {
  const profile = profiles.find((item) => item.id === profileId);
  if (!profile) return;
  await validateProfiles([profile]);
}

async function activeHttpTab() {
  const tabs = await tabsQuery({ active: true, currentWindow: true });
  const tab = tabs[0];
  const url = tab && safeUrl(tab.url);
  if (!url) throw new Error('No hay una página web válida en la pestaña actual');
  return { tab, url };
}

async function openHttpTabs() {
  const tabs = await tabsQuery({});
  const seen = new Set();
  const pages = [];
  for (const tab of tabs) {
    const url = tab && safeUrl(tab.url);
    if (!url) continue;
    const key = `${String(tab.cookieStoreId || '')}::${url.hostname.toLowerCase()}`;
    if (seen.has(key)) continue;
    seen.add(key);
    pages.push({ tab, url });
  }
  return pages;
}

function cookieIsUsable(cookie) {
  if (!cookie) return false;
  if (cookie.session) return true;
  const expiration = Number(cookie.expirationDate);
  return Number.isFinite(expiration) && expiration > (Date.now() / 1000);
}

function cookiesForOpenPages(cookies, openPages) {
  const pages = Array.isArray(openPages) ? openPages : [];
  return cookies.filter((cookie) => cookieIsUsable(cookie) && pages.some(({ url }) => cookieMatchesHost(cookie, url.hostname)));
}

function cookieDomainsInventory(cookies) {
  const inventory = new Map();
  for (const cookie of Array.isArray(cookies) ? cookies : []) {
    const domain = cookieDomain(cookie);
    if (!domain) continue;
    const current = inventory.get(domain) || { domain, cookies: [], stores: new Set(), partitions: new Set() };
    current.cookies.push(cookie);
    current.stores.add(String(cookie.storeId || 'default'));
    current.partitions.add(partitionSignature(cookie.partitionKey));
    inventory.set(domain, current);
  }
  return Array.from(inventory.values()).sort((left, right) => left.domain.localeCompare(right.domain));
}

function removalDetails(cookie) {
  const url = cookieUrl(cookie);
  if (!url) return null;
  const details = { url, name: cookie.name };
  if (typeof cookie.storeId === 'string') details.storeId = cookie.storeId;
  if (cookie.partitionKey && typeof cookie.partitionKey === 'object') details.partitionKey = cookie.partitionKey;
  return details;
}

async function removeCookieList(items) {
  let removed = 0;
  await runPool(items, async (cookie) => {
    const details = removalDetails(cookie);
    if (details && await cookiesRemove(details)) removed += 1;
  }, 8);
  return removed;
}

function cookieValueMatches(left, right) {
  return String(left && left.value || '') === String(right && right.value || '');
}

function isLikelySessionCookie(cookie) {
  const name = String(cookie && cookie.name || '').toLowerCase();
  return /(?:^|_)(?:sid|ssid|hsid|apisid|sapisid|session|sess|auth|token|login|account|secure|identity|oauth|jwt)(?:$|_)/i.test(name)
    || /^(?:sid|ssid|hsid|apisid|sapisid|__secure-|__host-)/i.test(name);
}

function savedCookiesForHostname(hostname) {
  const host = String(hostname || '').toLowerCase();
  const map = new Map();
  for (const profile of profiles) {
    for (const cookie of profile.cookies || []) {
      const domain = cookieDomain(cookie);
      if (!domain || !(host === domain || host.endsWith(`.${domain}`) || domain.endsWith(`.${host}`))) continue;
      map.set(cookieIdentity(cookie), cookie);
    }
  }
  return Array.from(map.values());
}

async function repairHostname(hostname, options = {}) {
  const host = String(hostname || '').toLowerCase();
  const saved = savedCookiesForHostname(host);
  if (!saved.length) return { host, saved: 0, removed: 0, restored: 0, failed: 0, skipped: true };

  const current = await cookiesGetAll({ domain: host });
  const savedByIdentity = new Map(saved.map((cookie) => [cookieIdentity(cookie), cookie]));
  const savedNames = new Set(saved.map((cookie) => String(cookie.name || '').toLowerCase()));
  const mismatchMode = options.mismatchMode === true;
  const now = Date.now() / 1000;
  const conflicting = current.filter((cookie) => {
    const expiration = Number(cookie.expirationDate);
    if (!cookie.session && Number.isFinite(expiration) && expiration <= now) return true;
    const expected = savedByIdentity.get(cookieIdentity(cookie));
    if (expected && !cookieValueMatches(cookie, expected)) return true;
    const name = String(cookie.name || '').toLowerCase();
    return mismatchMode && isLikelySessionCookie(cookie) && (savedNames.has(name) || cookieDomain(cookie).endsWith('google.com'));
  });

  const removed = await removeCookieList(conflicting);
  let restored = 0;
  let failed = 0;
  for (const cookie of saved) {
    const result = await setCookieWithVerification(cookie);
    if (result.ok) restored += 1;
    else failed += 1;
  }
  return { host, saved: saved.length, removed, restored, failed, skipped: false };
}

async function clearCurrentPage() {
  try {
    const { tab, url } = await activeHttpTab();
    const saved = savedCookiesForHostname(url.hostname);
    if (!saved.length) {
      setStatus(`No hay una sesión guardada para reparar ${url.hostname}.`, true);
      return;
    }
    if (!confirm(`¿Reparar la sesión guardada de ${url.hostname}? Solo se reemplazarán cookies vencidas o conflictivas.`)) return;
    setStatus(`Reparando ${url.hostname}…`);
    const mismatchMode = /\/cookiemismatch(?:[/?#]|$)/i.test(url.pathname) || /CookieMismatch/i.test(url.href);
    const result = await repairHostname(url.hostname, { mismatchMode });
    if (tab && Number.isInteger(tab.id)) await tabsReload(tab.id);
    setStatus(`Página reparada: ${result.removed} conflictos retirados, ${result.restored} cookies restauradas, ${result.failed} errores.`, result.failed > 0);
  } catch (error) {
    setStatus(`No se pudo reparar la página: ${error.message}`, true);
  }
}

async function clearBrowser() {
  const hostnames = new Set();
  for (const profile of profiles) {
    for (const page of profile.pages || []) {
      const parsed = safeUrl(page.url);
      if (parsed) hostnames.add(parsed.hostname.toLowerCase());
      else if (page.domain) hostnames.add(String(page.domain).replace(/^\./, '').toLowerCase());
    }
  }
  if (!hostnames.size) {
    setStatus('No hay páginas guardadas para reparar.', true);
    return;
  }
  if (!confirm(`¿Reparar las cookies de ${hostnames.size} páginas guardadas? No se borrarán cookies de sitios ajenos.`)) return;
  try {
    setStatus(`Reparando páginas: 0/${hostnames.size}…`);
    let done = 0;
    let removed = 0;
    let restored = 0;
    let failed = 0;
    for (const hostname of hostnames) {
      const result = await repairHostname(hostname);
      removed += result.removed || 0;
      restored += result.restored || 0;
      failed += result.failed || 0;
      done += 1;
      setStatus(`Reparando páginas: ${done}/${hostnames.size}…`);
    }
    const reload = await reloadOpenTabsForProfiles(profiles);
    setStatus(`Reparación terminada: ${removed} conflictos retirados, ${restored} cookies restauradas, ${failed} errores; ${reload.reloaded} pestañas recargadas.`, failed > 0 || reload.failed > 0);
  } catch (error) {
    setStatus(`No se pudieron reparar las páginas: ${error.message}`, true);
  }
}

async function clearExtensionData() {
  if (!confirm('¿Eliminar todos los perfiles y datos de Cookies Pro?')) return;
  try {
    await storageClear();
    profiles = [];
    expandedProfiles.clear();
    expandedPages.clear();
    for (const timer of accountRevealTimers.values()) clearTimeout(timer);
    accountRevealTimers.clear();
    revealedAccounts.clear();
    for (const timer of totpCountdownTimers.values()) clearInterval(timer);
    for (const timer of temporaryFactorTimers.values()) clearInterval(timer);
    totpCountdownTimers.clear();
    temporaryFactorTimers.clear();
    generatedTotpCodes.clear();
    temporaryFactorValues.clear();
    recoveryCodeIndexes.clear();
    render();
    setStatus('Datos de la extensión eliminados.');
  } catch (error) {
    setStatus(`No se pudieron limpiar los datos: ${error.message}`, true);
  }
}

function sanitizeFilename(value, fallback) {
  const cleaned = String(value || '')
    .trim()
    .replace(/\.json$/i, '')
    .replace(/[\\/:*?"<>|]+/g, '_')
    .replace(/\s+/g, ' ')
    .replace(/^\.+|\.+$/g, '')
    .slice(0, 120);
  return `${cleaned || fallback}.json`;
}

function dateStamp() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

function stableClone(value) {
  if (Array.isArray(value)) return value.map(stableClone);
  if (!value || typeof value !== 'object') return value;
  const result = {};
  for (const key of Object.keys(value).sort()) {
    if (typeof value[key] !== 'undefined') result[key] = stableClone(value[key]);
  }
  return result;
}

function stableStringify(value) {
  return JSON.stringify(stableClone(value));
}

async function sha256Hex(text) {
  const data = new TextEncoder().encode(text);
  const hash = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hash), (byte) => byte.toString(16).padStart(2, '0')).join('');
}

function bytesToBase64(bytes) {
  const data = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let binary = '';
  const chunkSize = 0x8000;
  for (let index = 0; index < data.length; index += chunkSize) {
    binary += String.fromCharCode(...data.subarray(index, index + chunkSize));
  }
  return btoa(binary);
}

function base64ToBytes(value, label = 'dato cifrado') {
  if (typeof value !== 'string' || !value) throw new Error(`Falta ${label}`);
  try {
    const binary = atob(value);
    const result = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) result[index] = binary.charCodeAt(index);
    return result;
  } catch (_) {
    throw new Error(`${label} no contiene Base64 válido`);
  }
}

async function derivePrivateKey(passphrase, salt, iterations, usages) {
  const material = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(passphrase), 'PBKDF2', false, ['deriveKey']
  );
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    usages
  );
}

function privateBackupHeader(parsed) {
  return {
    format: parsed.format,
    schemaVersion: parsed.schemaVersion,
    app: parsed.app,
    encryptedAt: parsed.encryptedAt,
    fileId: parsed.fileId,
    encryption: parsed.encryption
  };
}

function isPrivateEncryptedBackup(parsed) {
  return Boolean(parsed && parsed.format === PRIVATE_EXPORT_FORMAT);
}

async function encryptPrivateBackup(envelope, passphrase) {
  if (typeof passphrase !== 'string' || passphrase.length < MIN_EXPORT_PASSPHRASE_LENGTH) {
    throw new Error(`La clave privada debe tener al menos ${MIN_EXPORT_PASSPHRASE_LENGTH} caracteres`);
  }
  if (passphrase.length > MAX_EXPORT_PASSPHRASE_LENGTH) {
    throw new Error(`La clave privada no puede superar ${MAX_EXPORT_PASSPHRASE_LENGTH} caracteres`);
  }
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await derivePrivateKey(passphrase, salt, PRIVATE_PBKDF2_ITERATIONS, ['encrypt']);
  const header = {
    format: PRIVATE_EXPORT_FORMAT,
    schemaVersion: PRIVATE_EXPORT_SCHEMA_VERSION,
    app: { name: 'Cookies Pro Privada', version: APP_VERSION },
    encryptedAt: new Date().toISOString(),
    fileId: makeId('private-backup'),
    encryption: {
      algorithm: 'AES-256-GCM',
      keyDerivation: 'PBKDF2',
      hash: 'SHA-256',
      iterations: PRIVATE_PBKDF2_ITERATIONS,
      salt: bytesToBase64(salt),
      iv: bytesToBase64(iv),
      tagLength: 128,
      additionalData: 'stable private header'
    }
  };
  const aad = new TextEncoder().encode(stableStringify(header));
  const plaintext = new TextEncoder().encode(JSON.stringify(envelope));
  const ciphertext = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: aad, tagLength: 128 }, key, plaintext
  );
  return { ...header, ciphertext: bytesToBase64(ciphertext) };
}

async function decryptPrivateBackup(parsed, passphrase) {
  if (!isPrivateEncryptedBackup(parsed)) return parsed;
  if (Number(parsed.schemaVersion) > PRIVATE_EXPORT_SCHEMA_VERSION) {
    throw new Error(`El archivo privado usa un esquema más nuevo (${parsed.schemaVersion})`);
  }
  const encryption = parsed.encryption;
  if (!encryption || encryption.algorithm !== 'AES-256-GCM' || encryption.keyDerivation !== 'PBKDF2') {
    throw new Error('El archivo no usa un cifrado privado compatible');
  }
  const iterations = Number(encryption.iterations);
  if (!Number.isInteger(iterations) || iterations < 100000 || iterations > 1000000) {
    throw new Error('El número de iteraciones PBKDF2 no es válido');
  }
  if (typeof passphrase !== 'string' || !passphrase) throw new Error('Escribe la clave privada del archivo');
  if (passphrase.length > MAX_IMPORT_PASSPHRASE_LENGTH) {
    throw new Error(`La clave privada no puede superar ${MAX_IMPORT_PASSPHRASE_LENGTH} caracteres`);
  }
  const salt = base64ToBytes(encryption.salt, 'la sal de cifrado');
  const iv = base64ToBytes(encryption.iv, 'el vector de cifrado');
  const ciphertext = base64ToBytes(parsed.ciphertext, 'el contenido cifrado');
  if (salt.length < 16 || iv.length !== 12 || ciphertext.length < 17) {
    throw new Error('El archivo cifrado está incompleto');
  }
  const key = await derivePrivateKey(passphrase, salt, iterations, ['decrypt']);
  const header = privateBackupHeader(parsed);
  const aad = new TextEncoder().encode(stableStringify(header));
  let plaintext;
  try {
    plaintext = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv, additionalData: aad, tagLength: 128 }, key, ciphertext
    );
  } catch (_) {
    throw new Error('Clave incorrecta o archivo privado modificado');
  }
  try {
    return JSON.parse(new TextDecoder().decode(plaintext));
  } catch (_) {
    throw new Error('El contenido descifrado no contiene JSON válido');
  }
}

function copyPartitionKey(value) {
  if (!value || typeof value !== 'object') return null;
  const result = {};
  if (typeof value.topLevelSite === 'string' && value.topLevelSite) {
    const parsed = safeUrl(value.topLevelSite);
    if (parsed) result.topLevelSite = parsed.origin;
  }
  if (typeof value.hasCrossSiteAncestor === 'boolean') result.hasCrossSiteAncestor = value.hasCrossSiteAncestor;
  return Object.keys(result).length ? result : null;
}

function normalizeCookieRecord(source, index = 0) {
  if (!source || typeof source !== 'object') {
    return { cookie: null, error: `Cookie ${index + 1}: no es un objeto` };
  }
  if (typeof source.name !== 'string') {
    return { cookie: null, error: `Cookie ${index + 1}: falta el nombre` };
  }
  const originalDomain = typeof source.domain === 'string' ? source.domain.trim().toLowerCase() : '';
  if (!cookieDomain({ domain: originalDomain })) {
    return { cookie: null, error: `Cookie ${index + 1}: falta el dominio` };
  }

  const expiration = Number(source.expirationDate);
  const hasExpiration = Number.isFinite(expiration);
  const session = Boolean(source.session) || !hasExpiration;
  const sameSite = ['no_restriction', 'lax', 'strict', 'unspecified'].includes(source.sameSite)
    ? source.sameSite
    : 'unspecified';

  const cookie = {
    name: source.name,
    value: String(source.value ?? ''),
    domain: originalDomain,
    hostOnly: typeof source.hostOnly === 'boolean' ? source.hostOnly : !originalDomain.startsWith('.'),
    path: normalizePath(source.path),
    secure: Boolean(source.secure),
    httpOnly: Boolean(source.httpOnly),
    sameSite,
    session
  };
  if (!session) cookie.expirationDate = expiration;
  if (typeof source.storeId === 'string' && source.storeId) cookie.storeId = source.storeId;
  const partitionKey = copyPartitionKey(source.partitionKey);
  if (partitionKey) cookie.partitionKey = partitionKey;

  const known = new Set([
    'name', 'value', 'domain', 'hostOnly', 'path', 'secure', 'httpOnly',
    'sameSite', 'session', 'expirationDate', 'storeId', 'partitionKey', 'extensions'
  ]);
  const extensions = source.extensions && typeof source.extensions === 'object'
    ? { ...source.extensions }
    : {};
  for (const [key, value] of Object.entries(source)) {
    if (!known.has(key) && typeof value !== 'undefined') extensions[key] = value;
  }
  if (Object.keys(extensions).length) cookie.extensions = extensions;

  const warnings = [];
  if (!Boolean(source.session) && !hasExpiration) warnings.push(`Cookie ${index + 1}: convertida a sesión por falta de expiración`);
  if (sameSite === 'no_restriction' && !cookie.secure) warnings.push(`Cookie ${index + 1}: SameSite=None sin Secure puede ser rechazada por Chrome`);
  return { cookie, warnings };
}

function prepareCookieCollection(items) {
  const map = new Map();
  const rejected = [];
  const warnings = [];
  let duplicates = 0;

  for (let index = 0; index < items.length; index += 1) {
    const normalized = normalizeCookieRecord(items[index], index);
    if (!normalized.cookie) {
      rejected.push(normalized.error);
      continue;
    }
    warnings.push(...(normalized.warnings || []));
    const key = cookieIdentity(normalized.cookie);
    if (map.has(key)) duplicates += 1;
    map.set(key, normalized.cookie);
  }

  return { cookies: Array.from(map.values()), rejected, warnings, duplicates };
}

function cookieMatchesHost(cookie, hostname) {
  const domain = cookieDomain(cookie);
  const host = String(hostname || '').toLowerCase();
  return Boolean(domain && host && (host === domain || host.endsWith(`.${domain}`)));
}

async function collectCookiesAcrossStores() {
  const warnings = [];
  let stores = [];
  try {
    stores = await cookieStoresGetAll();
  } catch (error) {
    warnings.push(`No se pudo enumerar los almacenes: ${error.message}`);
  }

  if (!stores.length) {
    const cookies = await cookiesGetAll({});
    return { cookies, stores: [], warnings };
  }

  const collected = [];
  await runPool(stores, async (store) => {
    try {
      const items = await cookiesGetAll({ storeId: store.id });
      collected.push(...items);
    } catch (error) {
      warnings.push(`Almacén ${store.id}: ${error.message}`);
    }
  }, 3);
  return { cookies: collected, stores, warnings };
}

function partitionSignature(value) {
  return value && typeof value === 'object' ? stableStringify(value) : '';
}

function accountMetadataForDomain(domain) {
  const clean = String(domain || '').replace(/^\./, '').toLowerCase();
  const matches = [];
  for (const profile of profiles) {
    for (const page of profile.pages || []) {
      const pageDomain = String(page.domain || '').replace(/^\./, '').toLowerCase();
      if (!pageDomain || (pageDomain !== clean && !pageDomain.endsWith(`.${clean}`) && !clean.endsWith(`.${pageDomain}`))) continue;
      for (const account of page.accounts || []) matches.push(normalizeAccount(account));
    }
  }
  return matches.sort((left, right) => accountDataScore(right) - accountDataScore(left));
}

function accountMetadataMatch(derived, candidates, used) {
  const partition = partitionSignature(derived.partitionKey);
  const available = candidates
    .map((candidate, index) => ({ candidate, index }))
    .filter((item) => !used.has(item.index));
  if (!available.length) return null;

  const exact = available.filter(({ candidate }) =>
    String(candidate.storeId || '') === String(derived.storeId || '')
    && partitionSignature(candidate.partitionKey) === partition
  );
  const pool = exact.length ? exact : available;
  pool.sort((left, right) => accountDataScore(right.candidate) - accountDataScore(left.candidate));
  const selected = pool[0];
  used.add(selected.index);
  return selected.candidate;
}

function accountForExport(derived, metadata, includeSecrets) {
  const source = metadata || derived;
  const sourceCredentials = source.credentials || {};
  const sourceNameIsSensitive = source.name && [sourceCredentials.email, sourceCredentials.username]
    .filter(Boolean).includes(source.name);
  const exportName = !includeSecrets && sourceNameIsSensitive ? derived.name : (source.name || derived.name);
  const normalized = normalizeAccount({
    ...derived,
    id: source.id || derived.id,
    name: exportName,
    status: derived.status,
    storeId: source.storeId || derived.storeId,
    partitionKey: source.partitionKey || derived.partitionKey,
    sourceUrl: source.sourceUrl || derived.sourceUrl,
    dataSource: source.dataSource || derived.dataSource || (metadata ? 'profile' : 'cookies'),
    credentials: includeSecrets ? source.credentials : {},
    validation: validationForExport(source.validation || derived.validation, includeSecrets),
    lastChecked: source.lastChecked || derived.lastChecked,
    reason: source.reason || derived.reason
  });
  return {
    ...normalized,
    credentials: includeSecrets
      ? { ...normalized.credentials }
      : { email: '', username: '', password: '' },
    sensitiveCredentialsIncluded: Boolean(includeSecrets && (
      normalized.credentials.email || normalized.credentials.username || normalized.credentials.password
    ))
  };
}

function labelAccountsForPage(page, accounts) {
  const list = Array.isArray(accounts) ? accounts : [];
  if (!list.length) return list;
  const pageLabel = String(page && page.name ? page.name : titleFromDomain(page && page.domain || ''))
    .replace(/\s+[—-]\s+Cuenta\s+\d+$/i, '')
    .trim() || 'Página';
  return list.map((account, index) => ({
    ...account,
    displayName: list.length === 1
      ? `${pageLabel} — Cuenta 1`
      : `${pageLabel} — Cuenta ${index + 1}`,
    accountNumber: index + 1
  }));
}

function mergeAccountMetadata(page, derivedAccounts, includeSecrets) {
  const candidates = accountMetadataForDomain(page.domain);
  const used = new Set();
  const merged = derivedAccounts.map((derived) => accountForExport(
    derived,
    accountMetadataMatch(derived, candidates, used),
    includeSecrets
  ));
  for (let index = 0; index < candidates.length; index += 1) {
    if (used.has(index)) continue;
    merged.push(accountForExport(normalizeAccount({
      ...candidates[index],
      status: 'unknown',
      cookieCount: 0
    }), candidates[index], includeSecrets));
  }
  return labelAccountsForPage(page, merged);
}

function storedAccountRecordsForExport(scope, active, detectedDomains = []) {
  const activeHost = active && active.url ? active.url.hostname : '';
  const domains = Array.isArray(detectedDomains)
    ? detectedDomains.map((item) => typeof item === 'string' ? item : (item && item.domain) || (item && item.url && item.url.hostname) || '').filter(Boolean)
    : [];
  const records = new Map();
  for (const profile of profiles) {
    for (const rawPage of profile.pages || []) {
      const page = normalizePage(rawPage);
      if (scope === 'current' && activeHost && !domainsRelated(page.domain, activeHost)) continue;
      if (scope === 'all' && domains.length && !domains.some((domain) => domainsRelated(page.domain, domain))) continue;
      for (const rawAccount of page.accounts || []) {
        const account = normalizeAccount(rawAccount, 0, page.status);
        if (!accountHasMeaningfulData(account)) continue;
        const key = `${page.domain}|${account.id}`;
        const existing = records.get(key);
        if (!existing || accountDataScore(account) > accountDataScore(existing.account)) {
          records.set(key, { domain: page.domain, pageUrl: page.url, account });
        }
      }
    }
  }
  return Array.from(records.values());
}

function exportedAccountRecords(pages) {
  const records = [];
  for (const rawPage of pages || []) {
    const page = normalizePage(rawPage);
    for (const rawAccount of page.accounts || []) {
      records.push({ domain: page.domain, pageUrl: page.url, account: normalizeAccount(rawAccount, 0, page.status) });
    }
  }
  return records;
}

function accountAuditCounts(records) {
  const list = Array.isArray(records) ? records : [];
  const accounts = list.map((record) => normalizeAccount(record.account));
  return {
    registeredAccounts: accounts.filter(accountHasMeaningfulData).length,
    emails: accounts.filter((account) => account.credentials.email).length,
    usernames: accounts.filter((account) => account.credentials.username).length,
    passwords: accounts.filter((account) => account.credentials.password).length,
    validations: accounts.filter(accountHasValidationData).length,
    validationFactors: accounts.reduce((sum, account) => sum + normalizeValidationInfo(account).factors.length, 0),
    totpSeeds: accounts.filter((account) => normalizeValidationInfo(account).factors.some((factor) => factor.type === 'totp' && factor.totp && factor.totp.secret)).length,
    recoveryCodeSets: accounts.filter((account) => normalizeValidationInfo(account).factors.some((factor) => factor.type === 'recovery_codes' && factor.recoveryCodes.length)).length,
    securityAnswers: accounts.filter((account) => normalizeValidationInfo(account).factors.some((factor) => factor.type === 'security_question' && factor.answer)).length,
    manualSecrets: accounts.filter((account) => normalizeValidationInfo(account).factors.some((factor) => factor.manualSecret)).length
  };
}

function accountAuditSnapshot(record, includeSecrets) {
  const account = normalizeAccount(record.account);
  const preparedValidation = validationForExport(account.validation, includeSecrets);
  const canonicalValidation = validationForExport(
    normalizeValidationInfo({ validation: preparedValidation }),
    includeSecrets
  );
  return {
    domain: String(record.domain || '').toLowerCase(),
    id: account.id,
    name: includeSecrets ? account.name : '',
    sourceUrl: account.sourceUrl,
    credentials: includeSecrets
      ? { ...account.credentials }
      : { email: '', username: '', password: '' },
    validation: canonicalValidation
  };
}

function accountAuditMatch(sourceRecord, exportedRecordsList, used) {
  const source = normalizeAccount(sourceRecord.account);
  const domainMatches = exportedRecordsList
    .map((record, index) => ({ record, index }))
    .filter(({ record, index }) => !used.has(index) && domainsRelated(record.domain, sourceRecord.domain));
  let selected = domainMatches.find(({ record }) => normalizeAccount(record.account).id === source.id);
  if (!selected && source.credentials.email) {
    const email = source.credentials.email.toLowerCase();
    selected = domainMatches.find(({ record }) => normalizeAccount(record.account).credentials.email.toLowerCase() === email);
  }
  if (!selected && source.credentials.username) {
    const username = source.credentials.username.toLowerCase();
    selected = domainMatches.find(({ record }) => normalizeAccount(record.account).credentials.username.toLowerCase() === username);
  }
  if (!selected) selected = domainMatches.find(({ record }) => normalizeAccount(record.account).name === source.name);
  if (!selected) return null;
  used.add(selected.index);
  return selected.record;
}

function verifyExportedAccountData(scope, active, pages, includeSecrets, openPages = []) {
  const sourceRecords = storedAccountRecordsForExport(scope, active, openPages);
  const exportedRecordsList = exportedAccountRecords(pages);
  const used = new Set();
  const missing = [];
  const mismatched = [];

  for (const sourceRecord of sourceRecords) {
    const match = accountAuditMatch(sourceRecord, exportedRecordsList, used);
    if (!match) {
      missing.push(`${sourceRecord.domain} · ${sourceRecord.account.name}`);
      continue;
    }
    const expected = accountAuditSnapshot(sourceRecord, includeSecrets);
    const actual = accountAuditSnapshot(match, includeSecrets);
    if (stableStringify(expected) !== stableStringify(actual)) {
      mismatched.push(`${sourceRecord.domain} · ${sourceRecord.account.name}`);
    }
  }

  const source = accountAuditCounts(sourceRecords);
  const exported = accountAuditCounts(exportedRecordsList.filter((record) => accountHasMeaningfulData(record.account)));
  return {
    version: 1,
    verified: missing.length === 0 && mismatched.length === 0,
    includeSecrets: Boolean(includeSecrets),
    source,
    exported,
    checkedAccounts: sourceRecords.length,
    missing: missing.slice(0, 20),
    mismatched: mismatched.slice(0, 20)
  };
}

function storedPagesForExport(scope, active) {
  const matches = [];
  const activeHost = active && active.url ? active.url.hostname : '';
  for (const profile of profiles) {
    for (const rawPage of profile.pages || []) {
      const page = normalizePage(rawPage);
      if (scope === 'current' && activeHost && !domainsRelated(page.domain, activeHost)) continue;
      matches.push(page);
    }
  }
  return matches;
}

function cookiesForExportedAccount(account, relatedCookies) {
  const normalized = normalizeAccount(account);
  const storeId = String(normalized.storeId || '');
  const partition = partitionSignature(normalized.partitionKey);
  const exact = relatedCookies.filter((cookie) => {
    const cookieStore = cookie && cookie.storeId != null ? String(cookie.storeId) : '';
    const cookiePartition = partitionSignature(cookie && cookie.partitionKey);
    return cookieStore === storeId && cookiePartition === partition;
  });
  if (exact.length) return exact.map((cookie) => ({ ...cookie }));
  if (!storeId && !partition && relatedCookies.length) {
    return relatedCookies.map((cookie) => ({ ...cookie }));
  }
  return [];
}

function exportPages(cookies, scope, active, includeSecrets = false, detectedDomains = []) {
  let pages;
  if (scope === 'current' && active && active.url) {
    pages = [normalizePage({
      id: makeId('page'),
      name: active.tab && active.tab.title ? active.tab.title : titleFromDomain(active.url.hostname),
      url: active.url.href,
      domain: active.url.hostname,
      status: 'active-session',
      cookieCount: cookies.length,
      validation: {
        requestedUrl: active.url.href,
        expectedHost: active.url.hostname,
        capturedAt: new Date().toISOString(),
        source: 'active-tab'
      }
    })];
  } else {
    const inventory = cookieDomainsInventory(cookies);
    pages = inventory.map((entry) => normalizePage({
      id: makeId('page'),
      name: titleFromDomain(entry.domain),
      url: `https://${entry.domain}/`,
      domain: entry.domain,
      status: 'stored-cookie-data',
      cookieCount: entry.cookies.length,
      validation: {
        requestedUrl: `https://${entry.domain}/`,
        expectedHost: entry.domain,
        capturedAt: new Date().toISOString(),
        source: 'browser-cookie-store',
        storeIds: Array.from(entry.stores),
        partitionCount: entry.partitions.size
      }
    }));
  }

  // Añade metadatos guardados únicamente a dominios que realmente tienen cookies en la copia.
  for (const stored of storedPagesForExport(scope, active)) {
    const target = pages.find((page) => domainsRelated(page.domain, stored.domain));
    if (!target) continue;
    if ((!target.name || target.name === titleFromDomain(target.domain)) && stored.name) target.name = stored.name;
    if (stored.url && safeUrl(stored.url)) target.url = stored.url;
    target.accounts = Array.isArray(stored.accounts) ? stored.accounts : target.accounts;
  }

  return pages.map((page) => {
    const relatedCookies = cookies.filter((cookie) => cookieMatchesHost(cookie, page.domain));
    const derivedAccounts = deriveAccountsForPage(page, relatedCookies, []);
    const accounts = mergeAccountMetadata(page, derivedAccounts, includeSecrets).map((account) => {
      const sessionCookies = cookiesForExportedAccount(account, relatedCookies);
      return {
        ...account,
        sessionCookies,
        sessionCapturedAt: sessionCookies.length ? new Date().toISOString() : null,
        cookieCount: sessionCookies.length || account.cookieCount
      };
    });
    return {
      ...page,
      cookieCount: relatedCookies.length,
      accounts
    };
  });
}

function validationSnapshot(page, account, includeSecrets) {
  const normalizedPage = normalizePage(page);
  const normalizedAccount = normalizeAccount(account, 0, normalizedPage.status);
  const validation = validationForExport(normalizedAccount.validation, includeSecrets);
  return {
    page: {
      id: normalizedPage.id,
      domain: normalizedPage.domain,
      url: normalizedPage.url
    },
    account: {
      id: normalizedAccount.id,
      name: normalizedAccount.name,
      sourceUrl: normalizedAccount.sourceUrl,
      credentials: includeSecrets
        ? { ...normalizedAccount.credentials }
        : { email: '', username: '', password: '' },
      validation
    }
  };
}

function validationSecretFlags(validation) {
  const normalized = normalizeValidationInfo({ validation });
  return {
    totpSeed: normalized.factors.some((factor) => factor.type === 'totp' && factor.totp && factor.totp.secret),
    recoveryCodes: normalized.factors.some((factor) => factor.type === 'recovery_codes' && factor.recoveryCodes.length),
    securityAnswer: normalized.factors.some((factor) => factor.type === 'security_question' && factor.answer),
    manualSecret: normalized.factors.some((factor) => factor.manualSecret)
  };
}

async function createValidationManifest(pages, includeSecrets) {
  const records = [];
  for (const page of pages) {
    for (const account of page.accounts || []) {
      const snapshot = validationSnapshot(page, account, includeSecrets);
      const validation = snapshot.account.validation;
      const secretFlags = validationSecretFlags(validation);
      records.push({
        key: `${snapshot.page.id}::${snapshot.account.id}`,
        pageId: snapshot.page.id,
        pageDomain: snapshot.page.domain,
        accountId: snapshot.account.id,
        accountName: snapshot.account.name,
        validationEnabled: Boolean(validation.enabled),
        factorCount: validation.factors.length,
        factorTypes: validation.factors.map((factor) => factor.type),
        secretFlags,
        digest: await sha256Hex(stableStringify(snapshot))
      });
    }
  }
  const summary = {
    accounts: records.length,
    accountsWithValidation: records.filter((record) => record.validationEnabled).length,
    factors: records.reduce((sum, record) => sum + record.factorCount, 0),
    totpSeeds: records.filter((record) => record.secretFlags.totpSeed).length,
    recoveryCodeSets: records.filter((record) => record.secretFlags.recoveryCodes).length,
    securityAnswers: records.filter((record) => record.secretFlags.securityAnswer).length,
    manualSecrets: records.filter((record) => record.secretFlags.manualSecret).length
  };
  return {
    schemaVersion: 1,
    sourcePath: 'pages[].accounts[].validation',
    includesSensitiveSecrets: Boolean(includeSecrets),
    digestAlgorithm: 'SHA-256',
    records,
    summary
  };
}

async function verifyValidationManifest(envelope, pages) {
  const manifest = envelope && envelope.validationManifest;
  if (!manifest) {
    if (envelope && Number(envelope.schemaVersion) >= 10) {
      throw new Error('La copia no contiene el manifiesto de validaciones requerido');
    }
    return { verified: false, legacy: true, summary: null };
  }
  if (manifest.digestAlgorithm !== 'SHA-256' || !Array.isArray(manifest.records)) {
    throw new Error('El manifiesto de validaciones no es compatible');
  }
  const current = await createValidationManifest(
    Array.isArray(pages) ? pages : [],
    Boolean(manifest.includesSensitiveSecrets)
  );
  if (current.records.length !== manifest.records.length) {
    throw new Error(`Faltan cuentas de validación: se esperaban ${manifest.records.length} y se encontraron ${current.records.length}`);
  }
  const expected = new Map();
  for (const record of manifest.records) {
    if (!record || !record.key || expected.has(record.key)) throw new Error('El manifiesto contiene cuentas duplicadas o inválidas');
    expected.set(record.key, record);
  }
  for (const record of current.records) {
    const original = expected.get(record.key);
    if (!original) throw new Error(`La cuenta ${record.accountName} no coincide con el manifiesto exportado`);
    if (record.digest !== original.digest) {
      throw new Error(`Los datos de validación de ${record.accountName} están incompletos o modificados`);
    }
  }
  if (stableStringify(current.summary) !== stableStringify(manifest.summary || {})) {
    throw new Error('Los totales de validación no coinciden con la exportación');
  }
  return { verified: true, legacy: false, summary: current.summary };
}

function verifyImportedAccountDataAudit(envelope, pages) {
  const audit = envelope && envelope.accountDataAudit;
  if (!audit) {
    if (envelope && Number(envelope.schemaVersion) >= 11) {
      throw new Error('La copia no contiene la auditoría de cuentas requerida');
    }
    return { verified: false, legacy: true, summary: null };
  }
  if (!audit.verified || !audit.exported || typeof audit.exported !== 'object') {
    throw new Error('La auditoría de cuentas del archivo no es válida');
  }
  const records = exportedAccountRecords(Array.isArray(pages) ? pages : [])
    .filter((record) => accountHasMeaningfulData(record.account));
  const current = accountAuditCounts(records);
  if (stableStringify(current) !== stableStringify(audit.exported)) {
    throw new Error('Los campos de correo, usuario, contraseña o validación no coinciden con la exportación');
  }
  return { verified: true, legacy: false, summary: current, includeSecrets: Boolean(audit.includeSecrets) };
}

function exportStats(cookies, pages, prepared, stores) {
  const now = Date.now() / 1000;
  const accounts = pages.flatMap((page) => Array.isArray(page.accounts) ? page.accounts : []);
  return {
    totalCookies: cookies.length,
    totalPages: pages.length,
    totalAccounts: accounts.length,
    accountsWithEmail: accounts.filter((account) => account.credentials && account.credentials.email).length,
    accountsWithUsername: accounts.filter((account) => account.credentials && account.credentials.username).length,
    accountsWithPassword: accounts.filter((account) => account.credentials && account.credentials.password).length,
    accountsWithValidation: accounts.filter((account) => account.validation && account.validation.enabled).length,
    accountsWithTotpSeed: accounts.filter((account) => normalizeValidationInfo(account).factors.some((factor) => factor.type === 'totp' && factor.totp && factor.totp.secret)).length,
    totalValidationFactors: accounts.reduce((sum, account) => sum + normalizeValidationInfo(account).factors.length, 0),
    accountsWithRecoveryCodes: accounts.filter((account) => normalizeValidationInfo(account).factors.some((factor) => factor.type === 'recovery_codes' && factor.recoveryCodes.length)).length,
    accountsWithSecurityAnswers: accounts.filter((account) => normalizeValidationInfo(account).factors.some((factor) => factor.type === 'security_question' && factor.answer)).length,
    totalStores: stores.length || new Set(cookies.map((cookie) => cookie.storeId || 'default')).size,
    sessionCookies: cookies.filter((cookie) => cookie.session).length,
    persistentCookies: cookies.filter((cookie) => !cookie.session).length,
    secureCookies: cookies.filter((cookie) => cookie.secure).length,
    httpOnlyCookies: cookies.filter((cookie) => cookie.httpOnly).length,
    partitionedCookies: cookies.filter((cookie) => cookie.partitionKey).length,
    expiredCookies: cookies.filter((cookie) => !cookie.session && Number(cookie.expirationDate) <= now).length,
    duplicatesRemoved: prepared.duplicates,
    invalidRecordsRejected: prepared.rejected.length
  };
}

async function createExportEnvelope(scope, active, collected, includeSecrets = false, detectedDomains = []) {
  const rawCookies = scope === 'current'
    ? collected.cookies.filter((cookie) => cookieIsUsable(cookie) && cookieMatchesHost(cookie, active.url.hostname))
    : collected.cookies.slice();
  const prepared = prepareCookieCollection(rawCookies);
  const domainInventory = scope === 'all' ? cookieDomainsInventory(prepared.cookies) : detectedDomains;
  const pages = exportPages(prepared.cookies, scope, active, includeSecrets, domainInventory);
  const accountCount = pages.reduce((sum, page) => sum + (Array.isArray(page.accounts) ? page.accounts.length : 0), 0);
  if (!prepared.cookies.length && !accountCount) {
    throw new Error('No se encontraron cookies ni cuentas para exportar en el navegador');
  }
  const accountDataAudit = verifyExportedAccountData(scope, active, pages, includeSecrets, domainInventory);
  if (!accountDataAudit.verified) {
    const missing = accountDataAudit.missing.length ? ` faltantes: ${accountDataAudit.missing.join(', ')}` : '';
    const mismatched = accountDataAudit.mismatched.length ? ` diferentes: ${accountDataAudit.mismatched.join(', ')}` : '';
    throw new Error(`La auditoría bloqueó la exportación porque alguna cuenta registrada no se conservó.${missing}${mismatched}`);
  }
  const validationManifest = await createValidationManifest(pages, includeSecrets);
  const warnings = [
    ...collected.warnings,
    ...prepared.warnings.slice(0, 50),
    ...prepared.rejected.slice(0, 50)
  ];
  if (prepared.warnings.length > 50) warnings.push(`Hay ${prepared.warnings.length - 50} advertencias adicionales`);
  if (prepared.rejected.length > 50) warnings.push(`Hay ${prepared.rejected.length - 50} registros rechazados adicionales`);
  if (includeSecrets) warnings.push('El contenido descifrado incluye credenciales, semillas TOTP, códigos de recuperación, respuestas y secretos manuales proporcionados por el usuario.');

  const core = {
    format: EXPORT_FORMAT,
    schemaVersion: EXPORT_SCHEMA_VERSION,
    app: { name: 'Cookies Pro Privada', version: APP_VERSION },
    exportedAt: new Date().toISOString(),
    source: {
      scope,
      activeUrl: active && active.url ? active.url.href : null,
      activeTitle: active && active.tab ? active.tab.title || '' : '',
      userAgent: navigator.userAgent,
      storeIds: collected.stores.map((store) => store.id),
      accountSecretsIncluded: includeSecrets
    },
    stores: collected.stores.map((store) => ({
      id: String(store.id),
      tabIds: Array.isArray(store.tabIds) ? store.tabIds.slice() : []
    })),
    pages,
    validationManifest,
    accountDataAudit,
    stats: exportStats(prepared.cookies, pages, prepared, collected.stores),
    warnings,
    cookies: prepared.cookies
  };
  const digest = await sha256Hex(stableStringify(core));
  return {
    ...core,
    integrity: {
      algorithm: 'SHA-256',
      digest,
      scope: 'all fields except integrity'
    }
  };
}

async function verifyExportEnvelope(parsed) {
  if (!parsed || parsed.format !== EXPORT_FORMAT) return { verified: false, legacy: true };
  if (Number(parsed.schemaVersion) > EXPORT_SCHEMA_VERSION) {
    throw new Error(`El archivo usa un esquema más nuevo (${parsed.schemaVersion})`);
  }
  if (!parsed.integrity || parsed.integrity.algorithm !== 'SHA-256' || !parsed.integrity.digest) {
    throw new Error('El archivo robusto no contiene una huella de integridad válida');
  }
  const { integrity, ...core } = parsed;
  const digest = await sha256Hex(stableStringify(core));
  if (digest !== integrity.digest) {
    throw new Error('La integridad del archivo no coincide: puede estar incompleto o modificado');
  }
  return { verified: true, legacy: false };
}

function downloadJson(data, filename) {
  return new Promise((resolve, reject) => {
    const serialized = JSON.stringify(data, null, 2);
    const parsedAgain = JSON.parse(serialized);
    const validPrivate = isPrivateEncryptedBackup(parsedAgain)
      && typeof parsedAgain.ciphertext === 'string'
      && parsedAgain.ciphertext.length > 20;
    const validPlain = Array.isArray(parsedAgain.cookies)
      && (!data.cookies || parsedAgain.cookies.length === data.cookies.length);
    if (!validPrivate && !validPlain) {
      reject(new Error('La comprobación interna del archivo exportado falló'));
      return;
    }
    const blobUrl = URL.createObjectURL(new Blob([serialized], { type: 'application/json' }));
    chrome.downloads.download({ url: blobUrl, filename, saveAs: true, conflictAction: 'overwrite' }, () => {
      const error = getRuntimeError();
      setTimeout(() => URL.revokeObjectURL(blobUrl), 30000);
      if (error) reject(new Error(error));
      else resolve();
    });
  });
}

async function exportCookies() {
  const button = $('exportConfirm');
  button.disabled = true;
  try {
    const scope = document.querySelector('input[name="exportScope"]:checked').value;
    const active = scope === 'current' ? await activeHttpTab() : null;
    const includeSecrets = true;

    setStatus(scope === 'all'
      ? 'Buscando todas las cookies del navegador en cada almacén y dominio…'
      : 'Leyendo las cookies de la página actual…');
    const collected = await collectCookiesAcrossStores();
    const envelope = await createExportEnvelope(scope, active, collected, includeSecrets, []);
    const typedName = $('exportName').value.trim();
    if (!typedName) {
      setStatus('Escribe el nombre de cookies antes de exportar.', true);
      $('exportName').focus();
      return;
    }
    const filename = sanitizeFilename(typedName, 'cookies');
    await downloadJson(envelope, filename);
    closeModal();
    const stats = envelope.stats;
    const audit = envelope.accountDataAudit;
    setStatus(`Exportación completa: ${stats.totalPages} dominios y ${stats.totalCookies} cookies encontradas en el navegador.`);
  } catch (error) {
    setStatus(`No se pudo exportar: ${error.message}`, true);
  } finally {
    button.disabled = false;
  }
}


function normalizeHeaderName(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '');
}

function detectCsvDelimiter(text) {
  const sample = String(text || '').split(/\r?\n/).find((line) => line.trim()) || '';
  const counts = { ',': 0, ';': 0, '\t': 0 };
  let quoted = false;
  for (let index = 0; index < sample.length; index += 1) {
    const char = sample[index];
    if (char === '"') {
      if (quoted && sample[index + 1] === '"') index += 1;
      else quoted = !quoted;
    } else if (!quoted && Object.prototype.hasOwnProperty.call(counts, char)) counts[char] += 1;
  }
  return Object.entries(counts).sort((left, right) => right[1] - left[1])[0][0];
}

function parseCsvRows(text) {
  const input = String(text || '').replace(/^\uFEFF/, '');
  const delimiter = detectCsvDelimiter(input);
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;

  const pushRow = () => {
    row.push(field);
    field = '';
    if (row.some((item) => String(item).trim())) rows.push(row);
    row = [];
  };

  for (let index = 0; index < input.length; index += 1) {
    const char = input[index];
    if (quoted) {
      if (char === '"') {
        if (input[index + 1] === '"') {
          field += '"';
          index += 1;
        } else quoted = false;
      } else field += char;
      continue;
    }
    if (char === '"') quoted = true;
    else if (char === delimiter) {
      row.push(field);
      field = '';
    } else if (char === '\n') pushRow();
    else if (char === '\r') {
      if (input[index + 1] === '\n') continue;
      pushRow();
    } else field += char;
  }
  if (quoted) throw new Error('El CSV termina dentro de un campo entre comillas');
  if (field || row.length) pushRow();
  if (rows.length < 2) throw new Error('El CSV no contiene encabezados y registros suficientes');
  return rows;
}

function csvObjects(text) {
  const rows = parseCsvRows(text);
  const headers = rows[0].map((header, index) => normalizeHeaderName(header) || `columna${index + 1}`);
  return rows.slice(1, MAX_MANUAL_CREDENTIALS + 1).map((values) => {
    const record = {};
    headers.forEach((header, index) => { record[header] = values[index] == null ? '' : values[index]; });
    return record;
  });
}

function objectField(source, aliases) {
  if (!source || typeof source !== 'object') return '';
  const normalized = new Map(Object.entries(source).map(([key, value]) => [normalizeHeaderName(key), value]));
  for (const alias of aliases) {
    const value = normalized.get(normalizeHeaderName(alias));
    if (value != null && String(value).trim()) return value;
  }
  return '';
}

function credentialUrl(value) {
  const raw = optionalText(value, 2048);
  if (!raw) return null;
  return safeUrl(raw) || safeUrl(`https://${raw.replace(/^\/+/, '')}`);
}

function manualCredentialRecordsFromJson(parsed) {
  if (Array.isArray(parsed)) return parsed;
  if (!parsed || typeof parsed !== 'object') throw new Error('El JSON de cuentas no contiene datos válidos');
  const candidates = [
    parsed.credentials, parsed.credenciales, parsed.accounts, parsed.cuentas, parsed.items,
    parsed.logins, parsed.passwords, parsed.contrasenas, parsed.entries, parsed.registros
  ];
  for (const candidate of candidates) if (Array.isArray(candidate)) return candidate;
  const looksLikeSingleRecord = Boolean(
    parsed.login || parsed.credentials || parsed.credenciales || parsed.username || parsed.usuario
      || parsed.password || parsed.contrasena || parsed['contraseña'] || parsed.email || parsed.correo
      || parsed.url || parsed.sourceUrl || parsed.uri || parsed.domain || parsed.sitio
  );
  if (looksLikeSingleRecord) return [parsed];
  throw new Error('No se encontró una lista de cuentas en el JSON seleccionado');
}

function isBooleanLike(value) {
  if (typeof value === 'boolean' || typeof value === 'number') return true;
  const normalized = String(value == null ? '' : value).trim().toLowerCase();
  return [
    'true', 'false', 'sí', 'si', 'no', '1', '0', 'on', 'off', 'enabled', 'disabled',
    'activada', 'activado', 'desactivada', 'desactivado'
  ].includes(normalized);
}

function manualFactorField(source, slot, names) {
  const aliases = [];
  for (const name of names) {
    aliases.push(
      `factor${slot}${name}`,
      `metodo${slot}${name}`,
      `validation${slot}${name}`,
      `validacion${slot}${name}`,
      `${name}${slot}`
    );
  }
  return objectField(source, aliases);
}

function manualValidationFactorFromColumns(source, slot) {
  const type = manualFactorField(source, slot, ['type', 'tipo', 'method', 'metodo']);
  const status = manualFactorField(source, slot, ['status', 'estado']);
  const detail = manualFactorField(source, slot, ['detail', 'detalle', 'description', 'descripcion']);
  const enabledRaw = manualFactorField(source, slot, ['enabled', 'activada', 'activo']);
  const totpSecret = manualFactorField(source, slot, ['totpsecret', 'semillatotp', 'otpauth', 'totp']);
  const recoveryCodes = manualFactorField(source, slot, ['recoverycodes', 'codigosrecuperacion', 'backupcodes']);
  const question = manualFactorField(source, slot, ['question', 'pregunta']);
  const answer = manualFactorField(source, slot, ['answer', 'respuesta']);
  const manualSecret = manualFactorField(source, slot, ['secret', 'secreto', 'semilla', 'manualsecret']);
  const phone = manualFactorField(source, slot, ['phone', 'telefono', 'destination', 'destino']);
  const email = manualFactorField(source, slot, ['email', 'correo']);
  const app = manualFactorField(source, slot, ['app', 'aplicacion']);
  const device = manualFactorField(source, slot, ['device', 'dispositivo']);
  const rpId = manualFactorField(source, slot, ['rpid', 'relyingpartyid']);
  const credentialId = manualFactorField(source, slot, ['credentialid', 'idcredencial']);
  const transports = manualFactorField(source, slot, ['transports', 'transportes']);
  const provider = manualFactorField(source, slot, ['provider', 'proveedor']);
  const vendor = manualFactorField(source, slot, ['vendor', 'fabricante']);
  const model = manualFactorField(source, slot, ['model', 'modelo']);
  const serial = manualFactorField(source, slot, ['serial', 'serie']);
  const period = manualFactorField(source, slot, ['period', 'periodo', 'totpperiod']);
  const digits = manualFactorField(source, slot, ['digits', 'digitos', 'totpdigits']);
  const algorithm = manualFactorField(source, slot, ['algorithm', 'algoritmo', 'totpalgorithm']);
  const issuer = manualFactorField(source, slot, ['issuer', 'emisor']);
  const label = manualFactorField(source, slot, ['label', 'etiqueta']);
  const hasAny = [type, status, detail, enabledRaw, totpSecret, recoveryCodes, question, answer, manualSecret,
    phone, email, app, device, rpId, credentialId, transports, provider, vendor, model, serial,
    period, digits, algorithm, issuer, label].some((value) => value !== '' && value != null);
  if (!hasAny) return null;
  return normalizeValidationFactor({
    type: type || (totpSecret ? 'totp' : (recoveryCodes ? 'recovery_codes' : (question || answer ? 'security_question' : 'unknown'))),
    enabled: enabledRaw === '' ? true : booleanValue(enabledRaw),
    status,
    detail,
    phone,
    email,
    destination: phone || email,
    app,
    device,
    rpId,
    credentialId,
    transports,
    provider,
    vendor,
    model,
    serial,
    recoveryCodes,
    question,
    answer,
    manualSecret,
    totp: totpSecret ? { secret: totpSecret, period, digits, algorithm, issuer, label } : null
  }, slot - 1);
}

function normalizeManualCredentialRecord(source, index = 0) {
  if (!source || typeof source !== 'object') return null;
  const login = source.login && typeof source.login === 'object' ? source.login : {};
  const credentials = source.credentials && typeof source.credentials === 'object' ? source.credentials : {};
  const uriEntry = Array.isArray(login.uris) && login.uris.length
    ? (login.uris.find((item) => item && item.uri) || login.uris[0])
    : null;
  const rawUrl = objectField(source, ['url', 'sourceurl', 'website', 'web site', 'pagina', 'sitio', 'direccion', 'origin', 'site', 'domain', 'hostname', 'login_uri', 'loginuri', 'uri'])
    || (uriEntry && uriEntry.uri) || login.uri || '';
  const parsedUrl = credentialUrl(rawUrl);
  if (!parsedUrl) return null;

  let email = optionalText(objectField(source, ['email', 'correo', 'mail', 'login_email']) || credentials.email, 254);
  const username = optionalText(
    objectField(source, ['username', 'user', 'usuario', 'login name', 'loginname', 'login_username', 'loginusername'])
      || login.username || credentials.username,
    320
  );
  if (!email && username.includes('@')) email = username.slice(0, 254);
  const password = optionalSecretText(
    objectField(source, ['password', 'contrasena', 'contraseña', 'clave', 'login_password', 'loginpassword'])
      || login.password || credentials.password,
    4000
  );
  const name = optionalText(
    objectField(source, ['name', 'title', 'nombre', 'account', 'cuenta']) || source.name,
    200
  ) || email || username || `${titleFromDomain(parsedUrl.hostname)} · Cuenta ${index + 1}`;

  const explicitValidation = normalizeValidationInfo(source);
  const columnFactors = [1, 2]
    .map((slot) => manualValidationFactorFromColumns(source, slot))
    .filter(Boolean)
    .slice(0, MAX_VALIDATION_FACTORS);
  const rawValidationGeneral = objectField(source, [
    'validation', 'validacion', '2fa', 'mfa', 'twofactor', 'verification', 'tienevalidacion', 'hasvalidation'
  ]);
  const rawValidationEnabled = objectField(source, [
    'validationenabled', 'validacionactivada', 'validacionhabilitada', 'tienevalidacion',
    'hasvalidation', 'mfaenabled', '2faenabled', 'requierevalidacion'
  ]);
  const rawValidationType = objectField(source, [
    'validationtype', 'tipovalidacion', 'tipo de validacion', 'tipo', '2fatype', 'mfatype',
    'validationmethod', 'metodovalidacion', 'verificationtype'
  ]);
  const generalIsObject = rawValidationGeneral && typeof rawValidationGeneral === 'object';
  const generalIsBoolean = !generalIsObject && rawValidationGeneral !== '' && isBooleanLike(rawValidationGeneral);
  const enabledDeclared = rawValidationEnabled !== ''
    ? booleanValue(rawValidationEnabled)
    : (generalIsBoolean ? booleanValue(rawValidationGeneral) : explicitValidation.enabled);
  const explicitValidationType = isBooleanLike(explicitValidation.type) ? '' : explicitValidation.type;
  const rawValidation = optionalText(
    rawValidationType || (!generalIsBoolean && !generalIsObject ? rawValidationGeneral : '') || explicitValidationType,
    300
  );

  const rawTotp = objectField(source, [
    'totp', 'otp', 'otpauth', 'otp secret', 'otpsecret', 'otp seed', 'otpseed', 'otp key', 'otpkey',
    'totp secret', 'totpsecret', 'totp seed', 'totpseed', 'semillatotp', 'semilla totp',
    'timeotpsecretbase32', 'timeotpsecret', 'login_totp', 'logintotp'
  ]) || login.totp || explicitValidation.totp;
  const rawTotpPeriod = objectField(source, [
    'totpperiod', 'periodototp', 'periodo totp', 'period', 'periodo', 'interval', 'intervalo', 'step'
  ]);
  const rawTotpDigits = objectField(source, ['totpdigits', 'digitostotp', 'digitos', 'digits']);
  const rawTotpAlgorithm = objectField(source, ['totpalgorithm', 'algoritmototp', 'algoritmo', 'algorithm', 'hash']);
  const rawTotpIssuer = objectField(source, ['totpissuer', 'emisortotp', 'issuer', 'emisor']);
  const rawTotpLabel = objectField(source, ['totplabel', 'etiquetatotp', 'label', 'etiqueta']);
  let totp = null;
  if (rawTotp && typeof rawTotp === 'object') {
    totp = normalizeTotpConfig({
      ...rawTotp,
      period: rawTotpPeriod || rawTotp.period,
      digits: rawTotpDigits || rawTotp.digits,
      algorithm: rawTotpAlgorithm || rawTotp.algorithm,
      issuer: rawTotpIssuer || rawTotp.issuer,
      label: rawTotpLabel || rawTotp.label
    });
  } else if (rawTotp) {
    const uriConfig = parseOtpAuthUri(rawTotp);
    totp = uriConfig || normalizeTotpConfig({
      secret: rawTotp,
      period: rawTotpPeriod,
      digits: rawTotpDigits,
      algorithm: rawTotpAlgorithm,
      issuer: rawTotpIssuer,
      label: rawTotpLabel
    });
  }

  const rawValidationStatus = optionalText(objectField(source, [
    'validationstatus', 'estadovalidacion', 'estado validacion', 'validationstate', 'estadomfa',
    'estado2fa', 'statusvalidacion', 'estado'
  ]), 160);
  const rawValidationDetail = optionalText(objectField(source, [
    'validationdetail', 'detallevalidacion', 'detalle validacion', 'validationdescription', 'descripcionvalidacion'
  ]), 500);
  const rawPasskey = objectField(source, ['passkey', 'webauthn', 'securitykey', 'llavedeseguridad']);
  const factors = columnFactors.length ? columnFactors.slice() : explicitValidation.factors.slice(0, MAX_VALIDATION_FACTORS);
  if (totp && !factors.some((factor) => factor.type === 'totp') && factors.length < MAX_VALIDATION_FACTORS) {
    factors.push(normalizeValidationFactor({
      type: 'totp',
      label: 'Aplicación autenticadora',
      totp,
      status: rawValidationStatus || 'Disponible para respaldo cifrado',
      detail: rawValidationDetail || 'Semilla TOTP proporcionada manualmente; permanece oculta y se usa solo para generación local.'
    }, factors.length));
  }

  const passkeyText = String(rawPasskey == null ? '' : rawPasskey).trim().toLowerCase();
  const passkeyDeclared = Boolean(passkeyText)
    && !['false', 'no', '0', 'off', 'disabled', 'desactivada', 'desactivado'].includes(passkeyText);
  if (passkeyDeclared && !factors.some((factor) => ['passkey', 'security_key'].includes(factor.type)) && factors.length < MAX_VALIDATION_FACTORS) {
    factors.push(normalizeValidationFactor({ type: 'passkey', label: 'Passkey', status: rawValidationStatus || 'Declarada en archivo manual' }, factors.length));
  }

  const legacyMethodNames = [];
  if (rawValidation) legacyMethodNames.push(...rawValidation.split(/[,;|+]+/).map((item) => item.trim()).filter(Boolean));
  for (const method of legacyMethodNames) {
    if (factors.length >= MAX_VALIDATION_FACTORS) break;
    const candidate = normalizeValidationFactor({ type: method, label: method, status: rawValidationStatus }, factors.length);
    if (candidate && !factors.some((factor) => factor.type === candidate.type)) factors.push(candidate);
  }

  const methods = factors.map((factor) => factor.label);
  const validationType = methods.join(' + ') || rawValidation || explicitValidation.type || '';
  const onlyPasswordFactor = factors.length > 0 && factors.every((factor) => factor.type === 'password_only');
  const validationEnabled = onlyPasswordFactor
    ? false
    : Boolean(enabledDeclared || factors.some((factor) => factor.enabled) || totp);
  const useExplicitValidationStatus = generalIsObject || Boolean(rawValidationType) || (!generalIsBoolean && explicitValidation.enabled);
  const validationStatus = rawValidationStatus
    || (useExplicitValidationStatus && explicitValidation.status ? explicitValidation.status : '')
    || (totp ? 'Disponible para respaldo cifrado' : (validationEnabled ? 'Declarada en archivo manual' : 'No registrada'));
  const validationDetail = rawValidationDetail
    || (totp
      ? 'Semilla TOTP proporcionada manualmente; permanece oculta y se usa solo para generación local.'
      : (rawTotp ? 'Se detectó un valor TOTP no válido; no fue almacenado.' : optionalText(explicitValidation.detail, 500)));
  const validationProvided = Boolean(
    source.validation || source.validacion || rawValidationGeneral !== '' || rawValidationEnabled !== ''
      || rawValidationType !== '' || rawValidationStatus || rawValidationDetail || rawTotp || rawPasskey || columnFactors.length
  );


  return {
    id: makeId(`manual-account-${index}`),
    name,
    url: parsedUrl.href,
    domain: parsedUrl.hostname.toLowerCase(),
    credentials: { email, username, password },
    validation: {
      enabled: validationEnabled,
      type: validationType || '',
      methods: methods.slice(0, MAX_VALIDATION_FACTORS),
      factors: factors.slice(0, MAX_VALIDATION_FACTORS),
      factorCount: factors.length,
      status: validationStatus,
      detail: validationDetail,
      lastVerified: explicitValidation.lastVerified || null,
      totp: (factors.find((factor) => factor.type === 'totp' && factor.totp) || {}).totp || null,
      provided: validationProvided
    }
  };
}

function prepareManualCredentialRecords(items) {
  const records = [];
  const rejected = [];
  const seen = new Set();
  let duplicates = 0;
  const limited = items.slice(0, MAX_MANUAL_CREDENTIALS);
  limited.forEach((item, index) => {
    const record = normalizeManualCredentialRecord(item, index);
    if (!record) {
      rejected.push(`Cuenta ${index + 1}: falta una URL o dominio válido`);
      return;
    }
    const key = [record.domain, record.credentials.email, record.credentials.username, record.name]
      .map((value) => String(value || '').toLowerCase()).join('\u001f');
    if (seen.has(key)) {
      duplicates += 1;
      return;
    }
    seen.add(key);
    records.push(record);
  });
  if (items.length > MAX_MANUAL_CREDENTIALS) rejected.push(`Se omitieron ${items.length - MAX_MANUAL_CREDENTIALS} registros por superar el límite`);
  return { records, rejected, duplicates };
}

async function readManualCredentialFile(file) {
  if (!file) return { records: [], rejected: [], duplicates: 0 };
  if (file.size > MAX_CREDENTIAL_IMPORT_BYTES) throw new Error('El archivo de cuentas supera el límite seguro de 25 MB');
  const text = await file.text();
  if (!text.trim()) throw new Error('El archivo de cuentas está vacío');
  let items;
  const looksJson = /\.json$/i.test(file.name) || /^[\s\uFEFF]*[\[{]/.test(text);
  if (looksJson) {
    let parsed;
    try { parsed = JSON.parse(text.replace(/^\uFEFF/, '')); }
    catch (_) { throw new Error('El archivo JSON de cuentas no es válido'); }
    items = manualCredentialRecordsFromJson(parsed);
  } else items = csvObjects(text);
  return prepareManualCredentialRecords(items);
}

function domainsRelated(left, right) {
  const a = String(left || '').replace(/^\./, '').toLowerCase();
  const b = String(right || '').replace(/^\./, '').toLowerCase();
  return Boolean(a && b && (a === b || a.endsWith(`.${b}`) || b.endsWith(`.${a}`)));
}

function registrableDomainHint(hostname) {
  const labels = String(hostname || '').replace(/^\./, '').toLowerCase().split('.').filter(Boolean);
  if (labels.length <= 2) return labels.join('.');
  const secondLevelCountrySuffixes = new Set(['co.uk', 'org.uk', 'com.au', 'net.au', 'co.jp', 'com.br', 'com.mx', 'com.pe']);
  const lastTwo = labels.slice(-2).join('.');
  return secondLevelCountrySuffixes.has(lastTwo) && labels.length >= 3
    ? labels.slice(-3).join('.')
    : lastTwo;
}

function validationDomainsRelated(left, right) {
  if (domainsRelated(left, right)) return true;
  const a = registrableDomainHint(left);
  const b = registrableDomainHint(right);
  return Boolean(a && b && a === b);
}

function accountHasCredentialData(account) {
  const credentials = account && account.credentials ? account.credentials : {};
  return Boolean(credentials.email || credentials.username || credentials.password);
}

function manualCredentialFieldStats(records) {
  const list = Array.isArray(records) ? records : [];
  return {
    emails: list.filter((record) => record.credentials && record.credentials.email).length,
    usernames: list.filter((record) => record.credentials && record.credentials.username).length,
    passwords: list.filter((record) => record.credentials && record.credentials.password).length,
    validations: list.filter((record) => record.validation && record.validation.provided).length,
    validationsEnabled: list.filter((record) => record.validation && record.validation.enabled).length,
    validationTypes: list.filter((record) => record.validation && record.validation.type).length,
    validationStatuses: list.filter((record) => record.validation && record.validation.status).length,
    totpSeeds: list.filter((record) => normalizeValidationInfo(record).factors.some((factor) => factor.type === 'totp' && factor.totp && factor.totp.secret)).length,
    totpPeriods: list.filter((record) => normalizeValidationInfo(record).factors.some((factor) => factor.type === 'totp' && factor.totp && factor.totp.period)).length,
    validationFactors: list.reduce((sum, record) => sum + normalizeValidationInfo(record).factors.length, 0),
    recoveryCodeSets: list.filter((record) => normalizeValidationInfo(record).factors.some((factor) => factor.type === 'recovery_codes' && factor.recoveryCodes.length)).length,
    securityAnswers: list.filter((record) => normalizeValidationInfo(record).factors.some((factor) => factor.type === 'security_question' && factor.answer)).length,
    passkeys: list.filter((record) => normalizeValidationInfo(record).factors.some((factor) => factor.type === 'passkey')).length,
    securityKeys: list.filter((record) => normalizeValidationInfo(record).factors.some((factor) => factor.type === 'security_key')).length
  };
}

function mergeManualCredentialRecords(pages, records) {
  const mergedPages = pages.map((page, index) => normalizePage(page, index));
  let imported = 0;
  let updated = 0;
  let createdPages = 0;

  for (const record of records) {
    let page = mergedPages.find((candidate) => candidate.domain === record.domain)
      || mergedPages.find((candidate) => domainsRelated(candidate.domain, record.domain));
    if (!page) {
      page = normalizePage({
        id: makeId('page'),
        name: titleFromDomain(record.domain),
        url: record.url,
        domain: record.domain,
        status: 'unknown',
        cookieCount: 0,
        accounts: []
      }, mergedPages.length);
      mergedPages.push(page);
      createdPages += 1;
    }

    const email = record.credentials.email.toLowerCase();
    const username = record.credentials.username.toLowerCase();
    let account = page.accounts.find((candidate) => {
      const current = candidate.credentials || {};
      return (email && String(current.email || '').toLowerCase() === email)
        || (username && String(current.username || '').toLowerCase() === username);
    });
    if (!account) {
      account = page.accounts.find((candidate) => !accountHasCredentialData(candidate));
    }

    if (account) {
      const current = normalizeAccount(account, 0, page.status);
      account.name = record.name || current.name;
      account.credentials = {
        email: record.credentials.email || current.credentials.email,
        username: record.credentials.username || current.credentials.username,
        password: record.credentials.password || current.credentials.password
      };
      account.sourceUrl = record.url || current.sourceUrl;
      if (record.validation.provided) account.validation = { ...record.validation };
      account.dataSource = 'manual-import';
      updated += 1;
    } else {
      page.accounts.push(normalizeAccount({
        id: record.id,
        name: record.name,
        status: page.status,
        cookieCount: 0,
        sourceUrl: record.url,
        credentials: record.credentials,
        validation: record.validation,
        dataSource: 'manual-import',
        reason: page.reason,
        lastChecked: page.lastChecked
      }, page.accounts.length, page.status));
    }
    imported += 1;
  }

  return { pages: mergedPages, imported, updated, createdPages };
}

function stripJsonExtension(filename) {
  return String(filename || '').replace(/\.(json|csv)$/i, '').trim();
}

function extractImportPayload(parsed) {
  if (Array.isArray(parsed)) return { cookies: parsed, pages: [], sourceName: '', envelope: null };
  if (!parsed || typeof parsed !== 'object') throw new Error('El archivo JSON no contiene datos válidos');

  if (parsed.format === EXPORT_FORMAT && Array.isArray(parsed.cookies)) {
    return {
      cookies: parsed.cookies,
      pages: Array.isArray(parsed.pages) ? parsed.pages : [],
      sourceName: parsed.source && typeof parsed.source.activeTitle === 'string' ? parsed.source.activeTitle : '',
      envelope: parsed
    };
  }

  if (Array.isArray(parsed.cookies)) {
    return {
      cookies: parsed.cookies,
      pages: Array.isArray(parsed.pages) ? parsed.pages : [],
      sourceName: typeof parsed.name === 'string' ? parsed.name : '',
      envelope: null
    };
  }

  if (Array.isArray(parsed.profiles) && parsed.profiles.length === 1) {
    const profile = parsed.profiles[0];
    if (profile && Array.isArray(profile.cookies)) {
      return {
        cookies: profile.cookies,
        pages: Array.isArray(profile.pages) ? profile.pages : [],
        sourceName: typeof profile.name === 'string' ? profile.name : '',
        envelope: null
      };
    }
  }

  throw new Error('Formato no compatible: se esperaba una copia de Cookies Pro, una lista de cookies o un perfil');
}

function profileNameFromImport(file, payload) {
  const mode = document.querySelector('input[name="importNaming"]:checked').value;
  if (mode === 'custom') {
    const custom = $('importName').value.trim();
    if (!custom) throw new Error('Escribe el nuevo nombre del perfil');
    return custom.slice(0, 80);
  }
  return (stripJsonExtension(file && file.name) || payload.sourceName || 'Perfil').slice(0, 80);
}

async function importProfile() {
  const button = $('importConfirm');
  const file = $('importFile').files[0];
  if (!file) return setStatus('Selecciona una copia JSON.', true);
  if (file && file.size > MAX_IMPORT_BYTES) return setStatus('La copia supera el límite seguro de 80 MB.', true);

  button.disabled = true;
  try {
    let parsed = null;
    let privateVerified = false;
    let payload = { cookies: [], pages: [], sourceName: '', envelope: null };
    let integrity = { verified: false, legacy: true };
    let validationIntegrity = { verified: false, legacy: true, summary: null };
    let accountDataIntegrity = { verified: false, legacy: true, summary: null };

    if (file) {
      const text = await file.text();
      try {
        parsed = JSON.parse(text);
      } catch (_) {
        throw new Error('La copia principal no contiene JSON válido');
      }

      if (isPrivateEncryptedBackup(parsed)) {
        const passphrase = window.prompt('Esta copia está cifrada. Escribe su clave privada:') || '';
        if (!passphrase) throw new Error('Se necesita la clave para importar esta copia cifrada');
        setStatus('Descifrando y autenticando la copia privada…');
        parsed = await decryptPrivateBackup(parsed, passphrase);
        privateVerified = true;
      }
      payload = extractImportPayload(parsed);
      integrity = await verifyExportEnvelope(payload.envelope || parsed);
      validationIntegrity = await verifyValidationManifest(payload.envelope || parsed, payload.pages);
      accountDataIntegrity = verifyImportedAccountDataAudit(payload.envelope || parsed, payload.pages);
    }

    setStatus('Validando la copia…');
    const name = profileNameFromImport(file, payload);
    const prepared = prepareCookieCollection(payload.cookies || []);
    const exportedAccountCount = Array.isArray(payload.pages)
      ? payload.pages.reduce((sum, page) => sum + (Array.isArray(page && page.accounts) ? page.accounts.length : 0), 0)
      : 0;
    if (!prepared.cookies.length && !exportedAccountCount) {
      throw new Error('No se encontraron cookies, cuentas ni validaciones compatibles');
    }

    const accepted = prepared.cookies;
    const legacyBlocked = parsed && Array.isArray(parsed.blocked)
      ? prepareCookieCollection(parsed.blocked).cookies
      : [];
    const sensitiveCount = accepted.filter((cookie) => isSensitive(cookieDomain(cookie))).length;

    let pages = Array.isArray(payload.pages) && payload.pages.length
      ? payload.pages.map((page, index) => normalizePage(page, index))
      : derivePages(accepted, legacyBlocked, null);
    if (file && validationIntegrity.verified) {
      validationIntegrity = await verifyValidationManifest(payload.envelope || parsed, pages);
    }
    if (file && accountDataIntegrity.verified) {
      accountDataIntegrity = verifyImportedAccountDataAudit(payload.envelope || parsed, pages);
    }
    const totpImportAudit = auditImportedTotpSeeds(pages);
    if (!pages.length && accepted.length) pages = derivePages(accepted, legacyBlocked, DEFAULT_PAGE);
    if (!pages.length) throw new Error('No fue posible crear páginas para el perfil');

    const now = new Date().toISOString();
    const profile = normalizeProfile({
      id: makeId('profile'),
      name,
      page: pages[0] ? pages[0].url : DEFAULT_PAGE,
      cookies: accepted,
      blocked: legacyBlocked,
      pages,
      history: [{
        date: now,
        count: accepted.length,
        blocked: legacyBlocked.length,
        rejected: prepared.rejected.length,
        duplicates: prepared.duplicates,
        totpImportAudit,
        integrityVerified: integrity.verified,
        validationManifestVerified: validationIntegrity.verified,
        validationAccountsVerified: validationIntegrity.summary ? validationIntegrity.summary.accounts : 0,
        validationFactorsVerified: validationIntegrity.summary ? validationIntegrity.summary.factors : 0,
        accountDataAuditVerified: accountDataIntegrity.verified,
        accountDataFieldsVerified: accountDataIntegrity.summary || null,
        privateEncryptionVerified: privateVerified,
        sensitive: sensitiveCount,
        action: 'import_validated_backup'
      }],
      createdAt: now,
      updatedAt: now
    }, profiles.length);

    profiles.push(profile);
    expandedProfiles.add(profile.id);
    await saveProfiles();
    render();
    closeModal();
    resetImportForm();

    const verified = file
      ? (integrity.verified ? ' · SHA-256 verificado' : ' · formato anterior compatible')
      : '';
    const privateLabel = file
      ? (privateVerified ? ' · AES-256-GCM autenticado' : ' · archivo principal sin cifrado privado')
      : '';
    const validationLabel = validationIntegrity.verified && validationIntegrity.summary
      ? ` · validaciones verificadas: ${validationIntegrity.summary.accounts} cuentas / ${validationIntegrity.summary.factors} métodos`
      : (file ? ' · validaciones de formato anterior' : '');
    const accountAuditLabel = accountDataIntegrity.verified && accountDataIntegrity.summary
      ? ` · auditoría de cuentas: ${accountDataIntegrity.summary.emails} correos, ${accountDataIntegrity.summary.passwords} contraseñas, ${accountDataIntegrity.summary.totpSeeds} TOTP`
      : (file ? ' · auditoría de cuentas de formato anterior' : '');
    const backupModeLabel = payload.envelope && payload.envelope.source
      ? (payload.envelope.source.accountSecretsIncluded
        ? ' · copia completa con secretos cifrados'
        : ' · copia limitada: credenciales y semillas no estaban incluidas')
      : '';
    const cookieWarnings = prepared.rejected.length || prepared.duplicates
      ? ` · cookies: ${prepared.rejected.length} rechazadas, ${prepared.duplicates} duplicadas`
      : '';
    const sensitive = sensitiveCount ? ` · ${sensitiveCount} cookies sensibles` : '';
    const accountTotal = pages.reduce((sum, page) => sum + page.accounts.length, 0);
    const totpAuditLabel = totpImportAudit.total
      ? ` · TOTP revisadas: ${totpImportAudit.formatValid} con formato válido, ${totpImportAudit.invalidFormat} inválidas, ${totpImportAudit.metadataWarnings} con asociación dudosa; asociación registrada pendiente de comprobación manual`
      : '';
    setStatus(`Perfil importado: ${accepted.length} cookies, ${pages.length} páginas, ${accountTotal} cuentas${totpAuditLabel}${privateLabel}${verified}${validationLabel}${accountAuditLabel}${backupModeLabel}${cookieWarnings}${sensitive}. Las sesiones de cada cuenta quedaron listas para abrirse automáticamente.`);
  } catch (error) {
    setStatus(`No se pudo importar: ${error.message}`, true);
  } finally {
    button.disabled = false;
  }
}

function openModal(type) {
  activeModal = type;
  $('modalBackdrop').hidden = false;
  $('exportModal').hidden = type !== 'export';
  $('importModal').hidden = type !== 'import';
  const first = type === 'export' ? $('exportName') : $('importFile');
  setTimeout(() => first.focus(), 0);
}

function closeModal() {
  activeModal = null;
  $('modalBackdrop').hidden = true;
  $('exportModal').hidden = true;
  $('importModal').hidden = true;
}

function resetImportForm() {
  $('importFile').value = '';
  $('importName').value = '';
  document.querySelector('input[name="importNaming"][value="filename"]').checked = true;
  $('customNameWrap').hidden = true;
}

function bindEvents() {
  $('clearCurrent').addEventListener('click', () => { if (confirm('¿Reparar la página actual? La tarea continuará aunque cierres la extensión.')) startBackgroundAction('repairCurrent'); });
  $('clearBrowser').addEventListener('click', () => { if (confirm('¿Reparar todas las páginas guardadas? La tarea continuará aunque cierres la extensión.')) startBackgroundAction('repairAll'); });
  $('clearData').addEventListener('click', () => {
    if (confirm('¿Eliminar todas las cookies del navegador? Se cerrarán las sesiones abiertas. Los perfiles guardados en Cookies Pro no se eliminarán.')) {
      startBackgroundAction('deleteBrowserCookies');
    }
  });
  $('refresh').addEventListener('click', () => { for (const profile of profiles) startBackgroundAction('validateProfile', { profileId: profile.id }); });

  $('searchToggle').addEventListener('click', () => {
    const panel = $('searchPanel');
    panel.hidden = !panel.hidden;
    if (!panel.hidden) $('search').focus();
  });
  $('searchClose').addEventListener('click', () => {
    $('search').value = '';
    $('searchPanel').hidden = true;
    render();
  });
  $('search').addEventListener('input', render);

  $('exportOpen').addEventListener('click', () => openModal('export'));
  $('importOpen').addEventListener('click', () => openModal('import'));
  $('exportConfirm').addEventListener('click', exportCookies);
  $('importConfirm').addEventListener('click', importProfile);
  for (const button of document.querySelectorAll('.modal-close')) button.addEventListener('click', closeModal);
  $('modalBackdrop').addEventListener('click', (event) => {
    if (event.target === $('modalBackdrop')) closeModal();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && activeModal) closeModal();
  });


  for (const radio of document.querySelectorAll('input[name="importNaming"]')) {
    radio.addEventListener('change', () => {
      const custom = document.querySelector('input[name="importNaming"]:checked').value === 'custom';
      $('customNameWrap').hidden = !custom;
      if (custom) $('importName').focus();
    });
  }
}

window.addEventListener('unload', () => {
  for (const timer of accountRevealTimers.values()) clearTimeout(timer);
  for (const timer of totpCountdownTimers.values()) clearInterval(timer);
  for (const timer of temporaryFactorTimers.values()) clearInterval(timer);
  accountRevealTimers.clear();
  totpCountdownTimers.clear();
  temporaryFactorTimers.clear();
  generatedTotpCodes.clear();
  temporaryFactorValues.clear();
  recoveryCodeIndexes.clear();
});

async function init() {
  bindEvents();
  const versionNode = $('appVersion');
  if (versionNode) versionNode.textContent = `v${APP_VERSION}`;
  document.title = `Cookies Pro Privada v${APP_VERSION}`;
  try {
    await storageSetTrustedAccess();
    const stored = await storageGet({ profiles: [] });
    profiles = Array.isArray(stored.profiles)
      ? stored.profiles.map((profile, index) => normalizeProfile(profile, index))
      : [];
    await saveProfiles();
    render();
    setStatus(`${profiles.length} perfil${profiles.length === 1 ? '' : 'es'} cargado${profiles.length === 1 ? '' : 's'}.`);
  } catch (error) {
    render();
    setStatus(`No se pudieron cargar los perfiles: ${error.message}`, true);
  }
}

init();
