'use strict';

const JOB_KEY = 'backgroundJob';
const QUEUE_KEY = 'backgroundJobQueue';
const JOB_ALARM = 'cookies-pro-run-job';
const COOKIE_DAYS = 399;
const CANCEL_KEY = 'backgroundCancelledProfiles';

const pStorageGet = (defaults) => chrome.storage.local.get(defaults);
const pStorageSet = (data) => chrome.storage.local.set(data);
const pCookiesGetAll = (details = {}) => chrome.cookies.getAll(details);
const pCookiesGet = (details) => chrome.cookies.get(details);
const pCookiesSet = (details) => chrome.cookies.set(details);
const pCookiesRemove = (details) => chrome.cookies.remove(details);
const pTabsQuery = (details = {}) => chrome.tabs.query(details);
const pTabsReload = (id) => chrome.tabs.reload(id);
const pTabsCreate = (details) => chrome.tabs.create(details);

function safeUrl(value) {
  try {
    const url = new URL(String(value || ''));
    return /^https?:$/.test(url.protocol) ? url : null;
  } catch (_) { return null; }
}

function cookieDomain(cookie) { return String(cookie && cookie.domain || '').replace(/^\./, '').toLowerCase(); }
function normalizePath(path) { return String(path || '/').startsWith('/') ? String(path || '/') : `/${path}`; }
function sameSite(value) {
  const v = String(value || '').toLowerCase();
  if (v === 'no_restriction' || v === 'none') return 'no_restriction';
  if (v === 'strict') return 'strict';
  if (v === 'lax') return 'lax';
  return 'unspecified';
}
function partitionKey(cookie) {
  const pk = cookie && cookie.partitionKey;
  if (!pk || typeof pk !== 'object') return undefined;
  const out = {};
  if (pk.topLevelSite) out.topLevelSite = pk.topLevelSite;
  if (typeof pk.hasCrossSiteAncestor === 'boolean') out.hasCrossSiteAncestor = pk.hasCrossSiteAncestor;
  return Object.keys(out).length ? out : undefined;
}
function cookieUrls(cookie) {
  const domain = cookieDomain(cookie);
  if (!domain) return [];
  const path = normalizePath(cookie.path);
  const schemes = cookie.secure ? ['https:'] : ['https:', 'http:'];
  return schemes.map((scheme) => `${scheme}//${domain}${path}`);
}
function setDetails(cookie, url, omitStore = false) {
  const details = {
    url,
    name: String(cookie.name || ''),
    value: String(cookie.value || ''),
    path: normalizePath(cookie.path),
    secure: Boolean(cookie.secure),
    httpOnly: Boolean(cookie.httpOnly),
    sameSite: sameSite(cookie.sameSite),
    expirationDate: Math.floor(Date.now() / 1000) + COOKIE_DAYS * 86400
  };
  const domain = String(cookie.domain || '');
  if (domain && domain.startsWith('.')) details.domain = domain;
  if (!omitStore && cookie.storeId) details.storeId = String(cookie.storeId);
  const pk = partitionKey(cookie);
  if (pk) details.partitionKey = pk;
  return details;
}
function cookieMatches(expected, actual) {
  return Boolean(actual && String(actual.name) === String(expected.name) && String(actual.value) === String(expected.value));
}
async function setCookie(cookie) {
  let reason = 'No se pudo guardar';
  for (const omitStore of cookie.storeId ? [false, true] : [false]) {
    for (const url of cookieUrls(cookie)) {
      try {
        const details = setDetails(cookie, url, omitStore);
        const saved = await pCookiesSet(details);
        if (cookieMatches(cookie, saved)) return { ok: true };
        const lookup = { url, name: details.name };
        if (!omitStore && details.storeId) lookup.storeId = details.storeId;
        if (details.partitionKey) lookup.partitionKey = details.partitionKey;
        if (cookieMatches(cookie, await pCookiesGet(lookup))) return { ok: true };
      } catch (error) { reason = error.message || String(error); }
    }
  }
  return { ok: false, reason };
}
function cookieBelongs(cookie, page) {
  const url = safeUrl(page && page.url);
  if (!url) return false;
  const d = cookieDomain(cookie), h = url.hostname.toLowerCase();
  return d && (h === d || h.endsWith(`.${d}`) || d.endsWith(`.${h}`));
}
async function reloadForPages(pages) {
  const hosts = (pages || []).map((p) => safeUrl(p.url)).filter(Boolean).map((u) => u.hostname.toLowerCase());
  let reloaded = 0;
  for (const tab of await pTabsQuery({})) {
    const u = safeUrl(tab.url);
    if (!u || !Number.isInteger(tab.id)) continue;
    const h = u.hostname.toLowerCase();
    if (!hosts.some((x) => h === x || h.endsWith(`.${x}`) || x.endsWith(`.${h}`))) continue;
    try { await pTabsReload(tab.id); reloaded += 1; } catch (_) {}
  }
  return reloaded;
}
function authRedirect(url) {
  const u = safeUrl(url);
  return Boolean(u && (/(^|\/)(login|signin|sign-in|auth)(\/|$)/i.test(u.pathname) || /accounts\.google\.com$/i.test(u.hostname)));
}
async function validatePage(page) {
  const target = page && page.validation && page.validation.requestedUrl || page.url;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const r = await fetch(target, { credentials: 'include', redirect: 'follow', cache: 'no-store', signal: controller.signal });
    if (r.body) r.body.cancel().catch(() => {});
    if (authRedirect(r.url) || r.status === 401 || r.status === 403) return { status: 'invalid', reason: 'La página solicita acceso' };
    return r.ok ? { status: 'valid', reason: '' } : { status: 'invalid', reason: `HTTP ${r.status}` };
  } catch (e) { return { status: 'invalid', reason: e.name === 'AbortError' ? 'Tiempo agotado' : 'No disponible' }; }
  finally { clearTimeout(timer); }
}
async function writeJob(job) { await pStorageSet({ [JOB_KEY]: { ...job, updatedAt: new Date().toISOString() } }); }
class CancelledError extends Error { constructor(message = 'Tarea cancelada') { super(message); this.name = 'CancelledError'; } }
async function cancelledProfiles() {
  const stored = await pStorageGet({ [CANCEL_KEY]: {} });
  return stored[CANCEL_KEY] && typeof stored[CANCEL_KEY] === 'object' ? stored[CANCEL_KEY] : {};
}
async function assertProfileActive(profileId) {
  if (!profileId) return;
  const cancelled = await cancelledProfiles();
  if (cancelled[profileId]) throw new CancelledError('Tarea cancelada porque el perfil fue eliminado');
  const profiles = await getProfiles();
  if (!findProfile(profiles, profileId)) throw new CancelledError('Tarea cancelada porque el perfil ya no existe');
}
async function saveExistingProfile(profileId, updatedProfile) {
  const latest = await getProfiles();
  const index = latest.findIndex((profile) => profile.id === profileId);
  if (index < 0) throw new CancelledError('Tarea cancelada porque el perfil fue eliminado');
  const cancelled = await cancelledProfiles();
  if (cancelled[profileId]) throw new CancelledError('Tarea cancelada porque el perfil fue eliminado');
  latest[index] = updatedProfile;
  await saveProfiles(latest);
}
async function cancelProfileJobs(profileId) {
  if (!profileId) return;
  const stored = await pStorageGet({ [CANCEL_KEY]: {}, [QUEUE_KEY]: null, [JOB_KEY]: null });
  const cancelled = stored[CANCEL_KEY] && typeof stored[CANCEL_KEY] === 'object' ? stored[CANCEL_KEY] : {};
  cancelled[profileId] = new Date().toISOString();
  const updates = { [CANCEL_KEY]: cancelled };
  const queued = stored[QUEUE_KEY];
  if (queued && queued.profileId === profileId) updates[QUEUE_KEY] = null;
  const job = stored[JOB_KEY];
  if (job && job.profileId === profileId && (job.status === 'running' || job.status === 'queued')) {
    updates[JOB_KEY] = { ...job, status: 'cancelled', message: 'Tarea cancelada: el perfil fue eliminado.', updatedAt: new Date().toISOString() };
  }
  await pStorageSet(updates);
}
async function getProfiles() { const s = await pStorageGet({ profiles: [] }); return Array.isArray(s.profiles) ? s.profiles : []; }
async function saveProfiles(profiles) { await pStorageSet({ profiles }); }
function findProfile(profiles, id) { return profiles.find((p) => p.id === id); }

async function applyCookies(cookies, progress, profileId = '') {
  let ok = 0, failed = 0, done = 0;
  for (const c of cookies || []) {
    if (profileId) await assertProfileActive(profileId);
    const r = await setCookie(c);
    r.ok ? ok++ : failed++;
    done++;
    if (progress && done % 20 === 0) await progress(done, cookies.length, ok, failed);
  }
  return { ok, failed };
}
async function doApplyProfile(payload) {
  const profiles = await getProfiles();
  const profile = findProfile(profiles, payload.profileId);
  if (!profile) throw new Error('Perfil no encontrado');
  await assertProfileActive(payload.profileId);
  const result = await applyCookies(profile.cookies || [], async (done, total) => writeJob({ id: payload.jobId, type: 'applyProfile', profileId: payload.profileId, status: 'running', message: `Aplicando cookies ${done}/${total}` }), payload.profileId);
  await reloadForPages(profile.pages || []);
  profile.updatedAt = new Date().toISOString();
  profile.history = Array.isArray(profile.history) ? profile.history : [];
  profile.history.push({ date: profile.updatedAt, action: 'background_apply', count: result.ok, failed: result.failed });
  await saveExistingProfile(payload.profileId, profile);
  return `Perfil aplicado: ${result.ok} cookies, ${result.failed} errores.`;
}
async function doValidate(payload, singlePage = false) {
  const profiles = await getProfiles();
  const profile = findProfile(profiles, payload.profileId);
  if (!profile) throw new Error('Perfil no encontrado');
  const pages = singlePage ? (profile.pages || []).filter((p) => p.id === payload.pageId) : (profile.pages || []);
  if (!pages.length) throw new Error('Página no encontrada');
  const cookies = (profile.cookies || []).filter((c) => pages.some((p) => cookieBelongs(c, p)));
  await assertProfileActive(payload.profileId);
  const applied = await applyCookies(cookies, null, payload.profileId);
  await reloadForPages(pages);
  let valid = 0, invalid = 0, done = 0;
  for (const page of pages) {
    await assertProfileActive(payload.profileId);
    const r = await validatePage(page);
    await assertProfileActive(payload.profileId);
    page.status = r.status; page.reason = r.reason; page.lastChecked = new Date().toISOString();
    for (const account of page.accounts || []) { account.status = r.status; account.reason = r.reason; account.lastChecked = page.lastChecked; }
    r.status === 'valid' ? valid++ : invalid++;
    done++;
    await writeJob({ id: payload.jobId, type: singlePage ? 'validatePage' : 'validateProfile', profileId: payload.profileId, pageId: payload.pageId || '', status: 'running', message: `Validando páginas ${done}/${pages.length}` });
  }
  profile.updatedAt = new Date().toISOString();
  await saveExistingProfile(payload.profileId, profile);
  return `Validación terminada: ${valid} válidas, ${invalid} no válidas. Cookies: ${applied.ok} aplicadas, ${applied.failed} errores.`;
}
async function doOpenAccount(payload) {
  const profiles = await getProfiles();
  for (const profile of profiles) for (const page of profile.pages || []) {
    if (page.id !== payload.pageId) continue;
    const account = (page.accounts || []).find((a) => a.id === payload.accountId);
    if (!account) continue;
    const cookies = Array.isArray(account.sessionCookies) ? account.sessionCookies : [];
    const result = await applyCookies(cookies);
    const url = safeUrl(account.sourceUrl || page.url);
    if (url) await pTabsCreate({ url: url.href });
    account.lastChecked = new Date().toISOString(); account.status = result.ok ? 'valid' : 'invalid';
    await saveProfiles(profiles);
    return `Cuenta abierta: ${result.ok} cookies aplicadas, ${result.failed} errores.`;
  }
  throw new Error('Cuenta no encontrada');
}
function identity(c) { return `${c.storeId || ''}|${cookieDomain(c)}|${normalizePath(c.path)}|${c.name || ''}|${JSON.stringify(partitionKey(c) || {})}`; }
function likelySession(c) { return /sid|ssid|session|auth|token|login|oauth|jwt|__secure-|__host-/i.test(String(c.name || '')); }
async function repairHost(host, saved, mismatchMode) {
  const current = await pCookiesGetAll({ domain: host });
  const map = new Map(saved.map((c) => [identity(c), c]));
  let removed = 0;
  for (const c of current) {
    const exp = Number(c.expirationDate);
    const expected = map.get(identity(c));
    const conflict = (!c.session && Number.isFinite(exp) && exp <= Date.now()/1000) || (expected && expected.value !== c.value) || (mismatchMode && likelySession(c));
    if (!conflict) continue;
    for (const url of cookieUrls(c)) {
      try { if (await pCookiesRemove({ url, name: c.name, storeId: c.storeId, ...(partitionKey(c) ? { partitionKey: partitionKey(c) } : {}) })) { removed++; break; } } catch (_) {}
    }
  }
  const restored = await applyCookies(saved);
  return { removed, ...restored };
}
async function doRepair(payload, all) {
  const profiles = await getProfiles();
  let targets = [];
  if (all) {
    const hosts = new Set();
    for (const p of profiles) for (const page of p.pages || []) { const u = safeUrl(page.url); if (u) hosts.add(u.hostname.toLowerCase()); }
    targets = [...hosts].map((host) => ({ host, mismatch: false }));
  } else {
    const tabs = await pTabsQuery({ active: true, currentWindow: true });
    const u = safeUrl(tabs[0] && tabs[0].url);
    if (!u) throw new Error('No hay una página web activa');
    targets = [{ host: u.hostname.toLowerCase(), mismatch: /cookiemismatch/i.test(u.href) }];
  }
  let removed = 0, ok = 0, failed = 0, done = 0;
  for (const t of targets) {
    const savedMap = new Map();
    for (const p of profiles) for (const c of p.cookies || []) if (cookieDomain(c) && (t.host === cookieDomain(c) || t.host.endsWith(`.${cookieDomain(c)}`) || cookieDomain(c).endsWith(`.${t.host}`))) savedMap.set(identity(c), c);
    const r = await repairHost(t.host, [...savedMap.values()], t.mismatch);
    removed += r.removed; ok += r.ok; failed += r.failed; done++;
    await writeJob({ id: payload.jobId, status: 'running', message: `Reparando páginas ${done}/${targets.length}` });
  }
  await reloadForPages(profiles.flatMap((p) => p.pages || []));
  return `Reparación terminada: ${removed} conflictos retirados, ${ok} cookies restauradas, ${failed} errores.`;
}


async function doDeleteBrowserCookies(payload) {
  const all = await pCookiesGetAll({});
  let removed = 0, failed = 0, done = 0;
  for (const cookie of all) {
    let deleted = false;
    for (const url of cookieUrls(cookie)) {
      const details = { url, name: String(cookie.name || '') };
      if (cookie.storeId) details.storeId = String(cookie.storeId);
      const pk = partitionKey(cookie);
      if (pk) details.partitionKey = pk;
      try {
        if (await pCookiesRemove(details)) { deleted = true; break; }
      } catch (_) {}
    }
    deleted ? removed++ : failed++;
    done++;
    if (done % 25 === 0 || done === all.length) {
      await writeJob({
        id: payload.jobId,
        type: 'deleteBrowserCookies',
        status: 'running',
        message: `Eliminando cookies ${done}/${all.length}`
      });
    }
  }
  return `Cookies del navegador eliminadas: ${removed}. No eliminadas: ${failed}. Los perfiles guardados permanecen intactos.`;
}

async function runJob(message) {
  const jobId = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const payload = { ...message, jobId };
  await writeJob({ id: jobId, type: message.type, profileId: message.profileId || '', pageId: message.pageId || '', status: 'running', message: 'Iniciando…' });
  try {
    let result;
    if (message.type === 'applyProfile') result = await doApplyProfile(payload);
    else if (message.type === 'validateProfile') result = await doValidate(payload, false);
    else if (message.type === 'validatePage') result = await doValidate(payload, true);
    else if (message.type === 'openAccount') result = await doOpenAccount(payload);
    else if (message.type === 'repairCurrent') result = await doRepair(payload, false);
    else if (message.type === 'repairAll') result = await doRepair(payload, true);
    else if (message.type === 'deleteBrowserCookies') result = await doDeleteBrowserCookies(payload);
    else throw new Error('Acción no compatible');
    await writeJob({ id: jobId, type: message.type, profileId: message.profileId || '', pageId: message.pageId || '', status: 'done', message: result });
  } catch (error) {
    const cancelled = error && error.name === 'CancelledError';
    await writeJob({ id: jobId, type: message.type, profileId: message.profileId || '', pageId: message.pageId || '', status: cancelled ? 'cancelled' : 'error', message: error.message || String(error) });
  }
}

async function enqueueJob(message) {
  const queued = { ...message, queuedAt: new Date().toISOString() };
  const stored = await pStorageGet({ [CANCEL_KEY]: {} });
  const cancelled = stored[CANCEL_KEY] && typeof stored[CANCEL_KEY] === 'object' ? stored[CANCEL_KEY] : {};
  if (message.profileId && cancelled[message.profileId]) delete cancelled[message.profileId];
  await pStorageSet({ [QUEUE_KEY]: queued, [CANCEL_KEY]: cancelled });
  await chrome.alarms.create(JOB_ALARM, { when: Date.now() + 50 });
  return queued;
}

async function processQueuedJob() {
  const stored = await pStorageGet({ [QUEUE_KEY]: null });
  const queued = stored[QUEUE_KEY];
  if (!queued || queued.channel !== 'cookies-pro-background') return;
  if (queued.profileId) {
    const cancelled = await cancelledProfiles();
    if (cancelled[queued.profileId]) { await pStorageSet({ [QUEUE_KEY]: null }); return; }
  }
  await pStorageSet({ [QUEUE_KEY]: null });
  await runJob(queued);
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.channel !== 'cookies-pro-background') return;
  if (message.type === 'cancelProfile') {
    cancelProfileJobs(message.profileId)
      .then(() => sendResponse({ accepted: true, cancelled: true }))
      .catch((error) => sendResponse({ accepted: false, error: error.message || String(error) }));
    return true;
  }
  enqueueJob(message)
    .then(() => sendResponse({ accepted: true }))
    .catch((error) => sendResponse({ accepted: false, error: error.message || String(error) }));
  return true;
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (!alarm || alarm.name !== JOB_ALARM) return;
  return processQueuedJob();
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(JOB_ALARM, { when: Date.now() + 250 });
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(JOB_ALARM, { when: Date.now() + 250 });
});
